# v3.4 优选库匹配与新物料准入 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 建立独立的“优选库治理”窗口，支持导入用户二三级优选库 Excel，对 BOM 输出优选库命中、历史新料、交期风险临时禁选/限选和替代建议。

**Architecture:** 后端新增 preferred_library 领域模型、Excel 导入器、匹配/审查服务和 API；前端新增独立路由 `/preferred-library`，与 BOM 风险页分开展示。审查服务读取优选库、历史 BOM 和已有风险字段，生成 BomSelectionReview 结果。

**Tech Stack:** FastAPI、SQLAlchemy、SQLite、openpyxl、pytest、Vue 3、Element Plus、Axios、Vitest、Playwright、PowerShell 部署脚本。

## Global Constraints

- 优选库治理必须独立窗口展示，不与 BOM 风险页混成一张表。
- BOM 风险页继续负责交期、涨价、缺货、行情依据链；优选库治理页负责优选库命中、非优选、新物料、待评审、禁用/限用、替代建议和优选率。
- 交期风险联动采用动态管控，不把所有交期异常一刀切禁选。
- 高置信度红色交期风险、确认缺货、超过 12 周长交期或涨价缺货同时发生时可进入临时禁选。
- 中等风险、低置信度传闻或替代料不足时进入限选或观察。
- v3.4 MVP 不做完整审批流，不自动改写研发 BOM，不做复杂参数等效计算，不做规格书 PDF 自动解析。
- 文件创建位置：最终代码和文档写入 `d:\1项目清单\交期风险排查\BOM-Risk-Analyzer-patch`。
- 过程脚本和临时分析文件写入 `c:\Users\HAIER\.trae-cn\work\6a3a1656122fe7f887f6ea50`。

---

## File Structure

### Backend

- Create `backend/app/models/preferred.py`
  - Defines `PreferredPart`, `HistoricalPartIndex`, `BomSelectionReview` SQLAlchemy models.
- Modify `backend/app/database.py`
  - Imports `app.models.preferred` in `init_db()` so SQLite tables are created.
- Create `backend/app/services/preferred_library/__init__.py`
  - Package marker.
- Create `backend/app/services/preferred_library/normalizer.py`
  - Normalizes brands, MPNs, packages, status text and category names.
- Create `backend/app/services/preferred_library/excel_importer.py`
  - Reads multi-Sheet Excel files and creates `PreferredPart` rows.
- Create `backend/app/services/preferred_library/history_indexer.py`
  - Builds/query historical material usage from `BomItem` rows.
- Create `backend/app/services/preferred_library/review_service.py`
  - Reviews a BOM project against preferred library, history index and delivery risk fields.
- Create `backend/app/api/preferred_library.py`
  - Exposes import, summary, parts, review create/get API.
- Modify `backend/app/main.py`
  - Includes `preferred_library.router`.

### Backend Tests

- Create `tests/test_preferred_library_importer.py`
  - Tests multi-Sheet Excel import and status mapping.
- Create `tests/test_preferred_library_review.py`
  - Tests exact match, historical new part, temporary blocked delivery risk and alternatives.
- Create `tests/test_preferred_library_api.py`
  - Tests API import/review summary round trip.

### Frontend

- Create `frontend/src/api/preferredLibrary.js`
  - API client for preferred library endpoints.
- Create `frontend/src/views/PreferredLibrary.vue`
  - Independent preferred library governance page.
- Modify `frontend/src/router/index.js`
  - Adds `/preferred-library` route.
- Modify `frontend/src/App.vue`
  - Adds menu item `优选库治理`.

### Frontend Tests and E2E

- Create `frontend/src/views/__tests__/PreferredLibrary.test.js`
  - Verifies independent page, import summary and review table rendering.
- Create `frontend/e2e/v34-preferred-library.spec.js`
  - Browser test for opening the independent page and reviewing a BOM.

### Deploy and Docs

- Modify `deploy-v3.2-mvp.ps1`
  - Copies v3.4 backend/frontend/test/E2E files and includes v3.4 tests.
- Modify `README-V3.2-MVP.md`
  - Adds v3.4 summary and verification commands.
- Modify `DEMO-V3.2.md`
  - Adds v3.4 demo flow.
- Modify `GIT-HANDOFF.md`
  - Adds v3.4 handoff notes.

---

### Task 1: Preferred library models and normalizer

**Files:**
- Create: `backend/app/models/preferred.py`
- Create: `backend/app/services/preferred_library/__init__.py`
- Create: `backend/app/services/preferred_library/normalizer.py`
- Modify: `backend/app/database.py`
- Test: `tests/test_preferred_library_importer.py`

**Interfaces:**
- Produces: `normalize_text(value: object) -> str`
- Produces: `normalize_mpn(value: object) -> str`
- Produces: `normalize_brand(value: object) -> str`
- Produces: `parse_preferred_level(status_text: str) -> tuple[str, str]`
- Produces: `PreferredPart`, `HistoricalPartIndex`, `BomSelectionReview`

- [ ] **Step 1: Write failing model/normalizer tests**

Create `tests/test_preferred_library_importer.py` with this initial content:

```python
from app.services.preferred_library.normalizer import (
    normalize_brand,
    normalize_mpn,
    parse_preferred_level,
)


def test_preferred_status_text_maps_to_level_and_control_status():
    assert parse_preferred_level("⭐强推入库(跨3+项目)") == ("strong_recommended", "preferred")
    assert parse_preferred_level("📌中推入库(跨2项目)") == ("medium_recommended", "preferred")
    assert parse_preferred_level("待评审") == ("unknown", "pending_review")
    assert parse_preferred_level("禁用") == ("unknown", "blocked")
    assert parse_preferred_level("限用") == ("unknown", "restricted")


def test_brand_and_mpn_normalization_removes_noise():
    assert normalize_brand(" TDK ") == "TDK"
    assert normalize_brand("国巨/YAGEO") == "YAGEO"
    assert normalize_mpn(" C3225X5R1A226M250AC ") == "C3225X5R1A226M250AC"
    assert normalize_mpn("SOT-23 / S8050") == "SOT23S8050"
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```powershell
py -3.11 -m pytest tests\test_preferred_library_importer.py -q
```

Expected: FAIL because `app.services.preferred_library.normalizer` does not exist.

- [ ] **Step 3: Create models**

Create `backend/app/models/preferred.py`:

```python
from datetime import datetime, timezone
from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, String, Text
from app.database import Base


class PreferredPart(Base):
    __tablename__ = "preferred_parts"

    id = Column(Integer, primary_key=True, autoincrement=True)
    source_file = Column(String(512), nullable=True)
    source_sheet = Column(String(256), nullable=True)
    source_row = Column(Integer, nullable=True)
    category_level_2 = Column(String(128), nullable=True)
    category_level_3 = Column(String(128), nullable=True)
    brand = Column(String(128), nullable=True)
    normalized_brand = Column(String(128), nullable=True)
    name = Column(String(256), nullable=True)
    part_number = Column(String(128), nullable=True)
    mpn = Column(String(256), nullable=True)
    normalized_mpn = Column(String(256), nullable=True)
    manufacturer_mpn = Column(String(256), nullable=True)
    package = Column(String(128), nullable=True)
    mounting_type = Column(String(128), nullable=True)
    size = Column(String(128), nullable=True)
    spec_text = Column(Text, nullable=True)
    key_params_json = Column(Text, nullable=True)
    application_scenarios = Column(Text, nullable=True)
    preferred_level = Column(String(64), default="unknown")
    control_status = Column(String(64), default="unknown")
    cost = Column(Float, nullable=True)
    cost_unit = Column(String(64), nullable=True)
    recommendation_reason = Column(Text, nullable=True)
    raw_row_json = Column(Text, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self):
        return {
            "id": self.id,
            "source_file": self.source_file,
            "source_sheet": self.source_sheet,
            "source_row": self.source_row,
            "category_level_2": self.category_level_2,
            "category_level_3": self.category_level_3,
            "brand": self.brand,
            "normalized_brand": self.normalized_brand,
            "name": self.name,
            "part_number": self.part_number,
            "mpn": self.mpn,
            "normalized_mpn": self.normalized_mpn,
            "manufacturer_mpn": self.manufacturer_mpn,
            "package": self.package,
            "mounting_type": self.mounting_type,
            "size": self.size,
            "spec_text": self.spec_text,
            "application_scenarios": self.application_scenarios,
            "preferred_level": self.preferred_level,
            "control_status": self.control_status,
            "cost": self.cost,
            "cost_unit": self.cost_unit,
            "recommendation_reason": self.recommendation_reason,
        }


class HistoricalPartIndex(Base):
    __tablename__ = "historical_part_indexes"

    id = Column(Integer, primary_key=True, autoincrement=True)
    normalized_brand = Column(String(128), nullable=True)
    normalized_mpn = Column(String(256), nullable=True)
    normalized_category = Column(String(128), nullable=True)
    first_seen_at = Column(DateTime, nullable=True)
    last_seen_at = Column(DateTime, nullable=True)
    project_count = Column(Integer, default=0)
    usage_count = Column(Integer, default=0)
    latest_project_names_json = Column(Text, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class BomSelectionReview(Base):
    __tablename__ = "bom_selection_reviews"

    id = Column(Integer, primary_key=True, autoincrement=True)
    bom_project_id = Column(Integer, nullable=False)
    bom_item_id = Column(Integer, ForeignKey("bom_items.id"), nullable=False)
    preferred_part_id = Column(Integer, ForeignKey("preferred_parts.id"), nullable=True)
    match_status = Column(String(64), default="not_found")
    match_score = Column(Float, default=0.0)
    preferred_level = Column(String(64), default="unknown")
    control_status = Column(String(64), default="unknown")
    is_new_part = Column(Integer, default=0)
    history_usage_count = Column(Integer, default=0)
    history_project_count = Column(Integer, default=0)
    delivery_control_status = Column(String(64), default="normal")
    delivery_control_reason = Column(Text, nullable=True)
    selection_risk_level = Column(String(32), default="info")
    selection_reason = Column(Text, nullable=True)
    selection_action = Column(Text, nullable=True)
    recommended_alternatives_json = Column(Text, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self):
        return {
            "id": self.id,
            "bom_project_id": self.bom_project_id,
            "bom_item_id": self.bom_item_id,
            "preferred_part_id": self.preferred_part_id,
            "match_status": self.match_status,
            "match_score": self.match_score,
            "preferred_level": self.preferred_level,
            "control_status": self.control_status,
            "is_new_part": bool(self.is_new_part),
            "history_usage_count": self.history_usage_count or 0,
            "history_project_count": self.history_project_count or 0,
            "delivery_control_status": self.delivery_control_status,
            "delivery_control_reason": self.delivery_control_reason,
            "selection_risk_level": self.selection_risk_level,
            "selection_reason": self.selection_reason,
            "selection_action": self.selection_action,
            "recommended_alternatives": [],
        }
```

- [ ] **Step 4: Create normalizer package and functions**

Create `backend/app/services/preferred_library/__init__.py` as an empty file.

Create `backend/app/services/preferred_library/normalizer.py`:

```python
import re

BRAND_ALIASES = {
    "国巨": "YAGEO",
    "村田": "MURATA",
    "三星": "SAMSUNG",
    "风华": "FH",
    "华新科": "WALSIN",
}


def normalize_text(value: object) -> str:
    if value is None:
        return ""
    return str(value).strip()


def normalize_brand(value: object) -> str:
    text = normalize_text(value)
    if not text:
        return ""
    if "/" in text:
        parts = [p.strip() for p in text.split("/") if p.strip()]
        for part in parts:
            upper = part.upper()
            if re.search(r"[A-Z]", upper):
                return BRAND_ALIASES.get(part, upper)
        text = parts[0] if parts else text
    return BRAND_ALIASES.get(text, text.upper())


def normalize_mpn(value: object) -> str:
    text = normalize_text(value).upper()
    return re.sub(r"[^A-Z0-9]", "", text)


def parse_preferred_level(status_text: str) -> tuple[str, str]:
    text = normalize_text(status_text)
    if "禁用" in text or "禁选" in text:
        return "unknown", "blocked"
    if "限用" in text or "限选" in text:
        return "unknown", "restricted"
    if "待评审" in text or "待确认" in text:
        return "unknown", "pending_review"
    if "强推" in text or "跨3" in text or "跨 3" in text:
        return "strong_recommended", "preferred"
    if "中推" in text or "跨2" in text or "跨 2" in text:
        return "medium_recommended", "preferred"
    if "通用" in text or "推荐" in text:
        return "recommended", "preferred"
    if text:
        return "normal", "general"
    return "unknown", "unknown"
```

- [ ] **Step 5: Import preferred models in database initialization**

Modify `backend/app/database.py` inside `init_db()` to include:

```python
def init_db():
    from app.models import bom  # noqa: F401
    from app.models import event  # noqa: F401
    from app.models import watch  # noqa: F401
    from app.models import preferred  # noqa: F401

    Base.metadata.create_all(bind=engine)
    _migrate_bom_item_supply_columns()
```

Keep existing migration code unchanged.

- [ ] **Step 6: Run tests**

Run:

```powershell
py -3.11 -m pytest tests\test_preferred_library_importer.py -q
```

Expected: `2 passed`.

- [ ] **Step 7: Commit**

```powershell
git add backend/app/models/preferred.py backend/app/services/preferred_library/__init__.py backend/app/services/preferred_library/normalizer.py backend/app/database.py tests/test_preferred_library_importer.py
git commit -m "feat: add preferred library data model"
```

---

### Task 2: Excel importer for multi-Sheet preferred library

**Files:**
- Modify: `tests/test_preferred_library_importer.py`
- Create: `backend/app/services/preferred_library/excel_importer.py`

**Interfaces:**
- Consumes: `PreferredPart`
- Consumes: `normalize_brand`, `normalize_mpn`, `parse_preferred_level`
- Produces: `PreferredLibraryImporter.import_file(file_path: str, source_file: str | None = None) -> dict`

- [ ] **Step 1: Extend failing importer test**

Append to `tests/test_preferred_library_importer.py`:

```python
from pathlib import Path
from openpyxl import Workbook
from app.database import SessionLocal, init_db
from app.models.preferred import PreferredPart
from app.services.preferred_library.excel_importer import PreferredLibraryImporter


def test_import_multi_sheet_preferred_library_maps_rows(tmp_path):
    init_db()
    db = SessionLocal()
    db.query(PreferredPart).delete()
    db.commit()
    file_path = tmp_path / "preferred.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "二极管"
    ws.append(["品牌", "名称", "通用化状态", "物料号", "型号", "封装形式", "应用方案", "成本"])
    ws.append(["YAGEO", "快恢复二极管", "⭐强推入库(跨3+项目)", "D-001", "US1M", "SMA", "电源整流", 0.12])
    ws2 = wb.create_sheet("压敏电阻")
    ws2.append(["品牌", "名称", "通用化状态", "物料号", "型号", "尺寸", "应用方案", "未税"])
    ws2.append(["TDK", "压敏电阻", "待评审", "RV-001", "B72214S", "14D", "浪涌保护", 0.31])
    wb.save(file_path)

    try:
        result = PreferredLibraryImporter(db).import_file(str(file_path), source_file="preferred.xlsx")
        assert result["sheets"] == 2
        assert result["imported_parts"] == 2
        assert result["strong_recommended_count"] == 1
        assert result["pending_review_count"] == 1
        diode = db.query(PreferredPart).filter(PreferredPart.part_number == "D-001").one()
        assert diode.source_sheet == "二极管"
        assert diode.category_level_3 == "二极管"
        assert diode.normalized_mpn == "US1M"
        assert diode.preferred_level == "strong_recommended"
        assert diode.control_status == "preferred"
    finally:
        db.close()
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```powershell
py -3.11 -m pytest tests\test_preferred_library_importer.py::test_import_multi_sheet_preferred_library_maps_rows -q
```

Expected: FAIL because `excel_importer.py` does not exist.

- [ ] **Step 3: Implement Excel importer**

Create `backend/app/services/preferred_library/excel_importer.py`:

```python
import json
from pathlib import Path
from typing import Any
from openpyxl import load_workbook
from sqlalchemy.orm import Session
from app.models.preferred import PreferredPart
from app.services.preferred_library.normalizer import normalize_brand, normalize_mpn, normalize_text, parse_preferred_level


class PreferredLibraryImporter:
    def __init__(self, db: Session):
        self.db = db

    def import_file(self, file_path: str, source_file: str | None = None) -> dict[str, Any]:
        wb = load_workbook(file_path, data_only=True)
        source_name = source_file or Path(file_path).name
        self.db.query(PreferredPart).filter(PreferredPart.source_file == source_name).delete()
        imported = 0
        strong = 0
        medium = 0
        pending = 0
        sheets = 0
        for ws in wb.worksheets:
            rows = list(ws.iter_rows(values_only=True))
            if len(rows) < 2:
                continue
            headers = [normalize_text(v) for v in rows[0]]
            if not any(headers):
                continue
            sheets += 1
            for idx, row in enumerate(rows[1:], start=2):
                data = self._row_to_dict(headers, row)
                if not self._has_part_identity(data):
                    continue
                part = self._build_part(data, source_name, ws.title, idx)
                self.db.add(part)
                imported += 1
                if part.preferred_level == "strong_recommended":
                    strong += 1
                if part.preferred_level == "medium_recommended":
                    medium += 1
                if part.control_status == "pending_review":
                    pending += 1
        self.db.commit()
        return {
            "source_file": source_name,
            "sheets": sheets,
            "imported_parts": imported,
            "strong_recommended_count": strong,
            "medium_recommended_count": medium,
            "pending_review_count": pending,
        }

    def _row_to_dict(self, headers: list[str], row: tuple[Any, ...]) -> dict[str, Any]:
        return {headers[i]: row[i] if i < len(row) else None for i in range(len(headers)) if headers[i]}

    def _get(self, data: dict[str, Any], names: list[str]) -> str:
        for name in names:
            if name in data and normalize_text(data[name]):
                return normalize_text(data[name])
        return ""

    def _has_part_identity(self, data: dict[str, Any]) -> bool:
        return bool(self._get(data, ["物料号", "型号", "厂家型号", "名称", "品牌"]))

    def _build_part(self, data: dict[str, Any], source_file: str, sheet: str, row: int) -> PreferredPart:
        brand = self._get(data, ["品牌", "厂家", "制造商"])
        mpn = self._get(data, ["型号", "规格型号", "厂家型号"])
        status = self._get(data, ["通用化状态", "状态", "推荐状态", "依据实际更改"])
        level, control = parse_preferred_level(status)
        spec_keys = [k for k in data.keys() if k not in {"品牌", "名称", "通用化状态", "物料号", "型号", "厂家型号", "封装形式", "应用方案", "成本", "未税", "含税"}]
        key_params = {k: normalize_text(data[k]) for k in spec_keys if normalize_text(data[k])}
        cost_text = self._get(data, ["成本", "未税", "含税"])
        return PreferredPart(
            source_file=source_file,
            source_sheet=sheet,
            source_row=row,
            category_level_2=sheet,
            category_level_3=sheet,
            brand=brand,
            normalized_brand=normalize_brand(brand),
            name=self._get(data, ["名称", "品名", "物料名称"]),
            part_number=self._get(data, ["物料号", "内部物料号"]),
            mpn=mpn,
            normalized_mpn=normalize_mpn(mpn),
            manufacturer_mpn=self._get(data, ["厂家型号"]),
            package=self._get(data, ["封装形式", "封装"]),
            mounting_type=self._get(data, ["加工方式"]),
            size=self._get(data, ["尺寸"]),
            spec_text=" ".join(v for v in [mpn, self._get(data, ["封装形式", "尺寸"]), self._get(data, ["电压", "容量", "电流", "电感量"])] if v),
            key_params_json=json.dumps(key_params, ensure_ascii=False),
            application_scenarios=self._get(data, ["应用方案", "应用", "方案"]),
            preferred_level=level,
            control_status=control,
            cost=float(cost_text) if cost_text and cost_text.replace(".", "", 1).isdigit() else None,
            cost_unit="CNY" if cost_text else None,
            recommendation_reason=status,
            raw_row_json=json.dumps({k: normalize_text(v) for k, v in data.items()}, ensure_ascii=False),
        )
```

- [ ] **Step 4: Run importer tests**

Run:

```powershell
py -3.11 -m pytest tests\test_preferred_library_importer.py -q
```

Expected: `3 passed`.

- [ ] **Step 5: Commit**

```powershell
git add backend/app/services/preferred_library/excel_importer.py tests/test_preferred_library_importer.py
git commit -m "feat: import preferred library workbook"
```

---

### Task 3: Review service with history and delivery risk control

**Files:**
- Create: `tests/test_preferred_library_review.py`
- Create: `backend/app/services/preferred_library/history_indexer.py`
- Create: `backend/app/services/preferred_library/review_service.py`

**Interfaces:**
- Consumes: `BomProject`, `BomItem`, `PreferredPart`, `BomSelectionReview`
- Produces: `HistoricalPartIndexer.get_usage(item: BomItem) -> dict`
- Produces: `PreferredLibraryReviewService.review_project(project_id: int) -> dict`
- Produces: `PreferredLibraryReviewService.get_latest_review(project_id: int) -> dict`

- [ ] **Step 1: Write failing review tests**

Create `tests/test_preferred_library_review.py`:

```python
from app.database import SessionLocal, init_db
from app.models.bom import BomItem, BomProject, RiskLevel
from app.models.preferred import BomSelectionReview, PreferredPart
from app.services.preferred_library.review_service import PreferredLibraryReviewService


def _clear(db):
    db.query(BomSelectionReview).delete()
    db.query(PreferredPart).delete()
    db.query(BomItem).delete()
    db.query(BomProject).delete()
    db.commit()


def test_review_exact_preferred_match_is_green():
    init_db()
    db = SessionLocal()
    _clear(db)
    try:
        project = BomProject(id=101, filename="new.csv", project_name="新项目", total_items=1)
        item = BomItem(bom_upload_id=101, row_number=1, raw_part_number="D-001", raw_brand="YAGEO", raw_category="二极管", raw_spec="US1M SMA", risk_level=RiskLevel.GREEN)
        preferred = PreferredPart(category_level_3="二极管", brand="YAGEO", normalized_brand="YAGEO", part_number="D-001", mpn="US1M", normalized_mpn="US1M", package="SMA", preferred_level="strong_recommended", control_status="preferred")
        db.add_all([project, item, preferred])
        db.commit()

        result = PreferredLibraryReviewService(db).review_project(101)
        detail = result["items"][0]
        assert result["summary"]["preferred_hit_count"] == 1
        assert detail["match_status"] == "exact_part_number"
        assert detail["selection_risk_level"] == "green"
        assert detail["preferred_level"] == "strong_recommended"
    finally:
        db.close()


def test_review_new_non_preferred_part_is_red_with_alternative():
    init_db()
    db = SessionLocal()
    _clear(db)
    try:
        project = BomProject(id=102, filename="new.csv", project_name="新项目", total_items=1)
        item = BomItem(bom_upload_id=102, row_number=1, raw_part_number="X-NEW", raw_brand="ABC", raw_category="二极管", raw_spec="US1M SMA", risk_level=RiskLevel.GREEN)
        preferred = PreferredPart(category_level_3="二极管", brand="YAGEO", normalized_brand="YAGEO", part_number="D-001", mpn="US1M", normalized_mpn="US1M", package="SMA", preferred_level="strong_recommended", control_status="preferred")
        db.add_all([project, item, preferred])
        db.commit()

        result = PreferredLibraryReviewService(db).review_project(102)
        detail = result["items"][0]
        assert detail["match_status"] == "not_found"
        assert detail["is_new_part"] is True
        assert detail["selection_risk_level"] == "red"
        assert detail["recommended_alternatives"]
    finally:
        db.close()


def test_review_confirmed_long_lead_time_is_temporary_blocked():
    init_db()
    db = SessionLocal()
    _clear(db)
    try:
        project = BomProject(id=103, filename="risk.csv", project_name="风险项目", total_items=1)
        item = BomItem(
            bom_upload_id=103,
            row_number=1,
            raw_part_number="C3225X5R1A226M250AC",
            raw_brand="TDK",
            raw_category="MLCC",
            raw_spec="高容MLCC 22uF 25V",
            risk_level=RiskLevel.RED,
            risk_reason="已确认缺货，交期延长至 16 周",
            lead_time_risk_weeks=16,
            supply_risk_tags="shortage,confirmed",
        )
        db.add_all([project, item])
        db.commit()

        result = PreferredLibraryReviewService(db).review_project(103)
        detail = result["items"][0]
        assert detail["delivery_control_status"] == "temporary_blocked"
        assert "16" in detail["delivery_control_reason"]
        assert detail["selection_risk_level"] == "red"
    finally:
        db.close()
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```powershell
py -3.11 -m pytest tests\test_preferred_library_review.py -q
```

Expected: FAIL because `review_service.py` does not exist.

- [ ] **Step 3: Implement history indexer**

Create `backend/app/services/preferred_library/history_indexer.py`:

```python
from sqlalchemy.orm import Session
from app.models.bom import BomItem, BomProject
from app.services.preferred_library.normalizer import normalize_brand, normalize_mpn


class HistoricalPartIndexer:
    def __init__(self, db: Session):
        self.db = db

    def get_usage(self, item: BomItem) -> dict:
        brand = normalize_brand(item.raw_brand or item.normalized_brand)
        mpn = normalize_mpn(item.raw_part_number or item.raw_spec)
        if not mpn:
            return {"usage_count": 0, "project_count": 0, "project_names": []}
        query = self.db.query(BomItem).filter(BomItem.id != item.id)
        candidates = query.all()
        matched = []
        project_ids = set()
        for candidate in candidates:
            c_brand = normalize_brand(candidate.raw_brand or candidate.normalized_brand)
            c_mpn = normalize_mpn(candidate.raw_part_number or candidate.raw_spec)
            if c_mpn == mpn and (not brand or not c_brand or brand == c_brand):
                matched.append(candidate)
                project_ids.add(candidate.bom_upload_id)
        projects = self.db.query(BomProject).filter(BomProject.id.in_(project_ids)).all() if project_ids else []
        return {
            "usage_count": len(matched),
            "project_count": len(project_ids),
            "project_names": [p.project_name or p.filename for p in projects],
        }
```

- [ ] **Step 4: Implement review service**

Create `backend/app/services/preferred_library/review_service.py`:

```python
import json
from sqlalchemy.orm import Session
from app.models.bom import BomItem, BomProject
from app.models.preferred import BomSelectionReview, PreferredPart
from app.services.preferred_library.history_indexer import HistoricalPartIndexer
from app.services.preferred_library.normalizer import normalize_brand, normalize_mpn


class PreferredLibraryReviewService:
    def __init__(self, db: Session):
        self.db = db
        self.history = HistoricalPartIndexer(db)

    def review_project(self, project_id: int) -> dict:
        project = self.db.query(BomProject).filter(BomProject.id == project_id).first()
        if not project:
            return {"error": "Project not found"}
        self.db.query(BomSelectionReview).filter(BomSelectionReview.bom_project_id == project_id).delete()
        items = self.db.query(BomItem).filter(BomItem.bom_upload_id == project_id).order_by(BomItem.row_number).all()
        reviews = []
        for item in items:
            review = self._review_item(project_id, item)
            self.db.add(review)
            reviews.append(review)
        self.db.commit()
        return self._build_response(project, reviews)

    def get_latest_review(self, project_id: int) -> dict:
        project = self.db.query(BomProject).filter(BomProject.id == project_id).first()
        if not project:
            return {"error": "Project not found"}
        reviews = self.db.query(BomSelectionReview).filter(BomSelectionReview.bom_project_id == project_id).order_by(BomSelectionReview.id).all()
        return self._build_response(project, reviews)

    def _review_item(self, project_id: int, item: BomItem) -> BomSelectionReview:
        match = self._match_preferred(item)
        usage = self.history.get_usage(item)
        alternatives = self._find_alternatives(item, exclude_id=match["preferred_part"].id if match["preferred_part"] else None)
        delivery_status, delivery_reason = self._delivery_control(item)
        is_new = usage["usage_count"] == 0
        risk, reason, action = self._selection_decision(match, is_new, delivery_status, alternatives)
        return BomSelectionReview(
            bom_project_id=project_id,
            bom_item_id=item.id,
            preferred_part_id=match["preferred_part"].id if match["preferred_part"] else None,
            match_status=match["status"],
            match_score=match["score"],
            preferred_level=match["preferred_part"].preferred_level if match["preferred_part"] else "unknown",
            control_status=match["preferred_part"].control_status if match["preferred_part"] else "unknown",
            is_new_part=1 if is_new else 0,
            history_usage_count=usage["usage_count"],
            history_project_count=usage["project_count"],
            delivery_control_status=delivery_status,
            delivery_control_reason=delivery_reason,
            selection_risk_level=risk,
            selection_reason=reason,
            selection_action=action,
            recommended_alternatives_json=json.dumps([p.to_dict() for p in alternatives[:5]], ensure_ascii=False),
        )

    def _match_preferred(self, item: BomItem) -> dict:
        part_number = (item.raw_part_number or "").strip()
        brand = normalize_brand(item.raw_brand or item.normalized_brand)
        mpn = normalize_mpn(item.raw_part_number or item.raw_spec)
        if part_number:
            part = self.db.query(PreferredPart).filter(PreferredPart.part_number == part_number).first()
            if part:
                return {"status": "exact_part_number", "score": 1.0, "preferred_part": part}
        if brand and mpn:
            parts = self.db.query(PreferredPart).filter(PreferredPart.normalized_brand == brand, PreferredPart.normalized_mpn == mpn).all()
            if parts:
                return {"status": "exact_brand_mpn", "score": 0.95, "preferred_part": parts[0]}
        if mpn:
            part = self.db.query(PreferredPart).filter(PreferredPart.normalized_mpn == mpn).first()
            if part:
                return {"status": "exact_mpn_package", "score": 0.85, "preferred_part": part}
        return {"status": "not_found", "score": 0.0, "preferred_part": None}

    def _find_alternatives(self, item: BomItem, exclude_id: int | None = None) -> list[PreferredPart]:
        category = (item.raw_category or item.normalized_category or "").strip()
        if not category:
            return []
        query = self.db.query(PreferredPart).filter(PreferredPart.category_level_3.contains(category[:4]))
        if exclude_id:
            query = query.filter(PreferredPart.id != exclude_id)
        return query.order_by(PreferredPart.preferred_level.asc()).limit(5).all()

    def _delivery_control(self, item: BomItem) -> tuple[str, str]:
        risk_level = item.risk_level.value if item.risk_level else "gray"
        reason = " ".join(str(v or "") for v in [item.risk_reason, item.supply_risk_reason, item.supply_risk_tags])
        weeks = item.lead_time_risk_weeks or 0
        confirmed = any(word in reason.lower() for word in ["confirmed", "已确认", "缺货", "shortage", "allocation"])
        if risk_level == "red" and (confirmed or weeks >= 12):
            detail = f"已确认缺货且交期 {weeks} 周，临时禁选。" if weeks else "红色交期风险且证据可信，临时禁选。"
            return "temporary_blocked", detail
        if risk_level == "yellow" or weeks >= 8:
            return "restricted", "存在中等交期风险，需补充供应确认或替代方案。"
        if any(word in reason for word in ["传闻", "可能", "关注"]):
            return "watch", "低置信度行情或交期传闻，仅观察。"
        return "normal", ""

    def _selection_decision(self, match: dict, is_new: bool, delivery_status: str, alternatives: list[PreferredPart]) -> tuple[str, str, str]:
        part = match["preferred_part"]
        if delivery_status == "temporary_blocked":
            return "red", "交期风险联动为临时禁选。", "需研发说明不可替代理由，并由采购/工程确认。"
        if part and part.control_status == "blocked":
            return "red", "命中禁用料。", "禁止选用，需替换为优选物料。"
        if is_new and not part:
            return "red", "不在优选库且历史 BOM 从未出现。", "优先替换为优选库物料；如必须使用需提交选型说明。"
        if delivery_status == "restricted":
            return "yellow", "交期风险联动为限选。", "补充供应确认、库存确认或替代方案。"
        if part and part.control_status in {"pending_review", "restricted"}:
            return "yellow", "命中待评审或限用状态。", "进入待确认清单。"
        if not part:
            return "yellow", "未命中优选库。", "建议从推荐替代料中选择。"
        return "green", "命中优选库。", "可优先使用。"

    def _build_response(self, project: BomProject, reviews: list[BomSelectionReview]) -> dict:
        items = []
        for review in reviews:
            data = review.to_dict()
            data["recommended_alternatives"] = json.loads(review.recommended_alternatives_json or "[]")
            items.append(data)
        total = len(items)
        preferred_hit = sum(1 for i in items if i["preferred_part_id"])
        summary = {
            "bom_project_id": project.id,
            "project_name": project.project_name or project.filename,
            "total_items": total,
            "preferred_hit_count": preferred_hit,
            "preferred_hit_rate": round(preferred_hit / total, 4) if total else 0,
            "non_preferred_count": sum(1 for i in items if not i["preferred_part_id"]),
            "new_part_count": sum(1 for i in items if i["is_new_part"]),
            "temporary_blocked_count": sum(1 for i in items if i["delivery_control_status"] == "temporary_blocked"),
            "restricted_count": sum(1 for i in items if i["delivery_control_status"] == "restricted"),
            "red_count": sum(1 for i in items if i["selection_risk_level"] == "red"),
            "yellow_count": sum(1 for i in items if i["selection_risk_level"] == "yellow"),
            "alternative_count": sum(1 for i in items if i["recommended_alternatives"]),
        }
        return {"summary": summary, "items": items}
```

- [ ] **Step 5: Run review tests**

Run:

```powershell
py -3.11 -m pytest tests\test_preferred_library_review.py -q
```

Expected: `3 passed`.

- [ ] **Step 6: Commit**

```powershell
git add backend/app/services/preferred_library/history_indexer.py backend/app/services/preferred_library/review_service.py tests/test_preferred_library_review.py
git commit -m "feat: review BOM against preferred library"
```

---

### Task 4: Preferred library API

**Files:**
- Create: `tests/test_preferred_library_api.py`
- Create: `backend/app/api/preferred_library.py`
- Modify: `backend/app/main.py`

**Interfaces:**
- Consumes: `PreferredLibraryImporter.import_file`
- Consumes: `PreferredLibraryReviewService.review_project`
- Produces: API prefix `/api/preferred-library`

- [ ] **Step 1: Write failing API test**

Create `tests/test_preferred_library_api.py`:

```python
from pathlib import Path
from openpyxl import Workbook
from fastapi.testclient import TestClient
from app.database import SessionLocal, init_db
from app.main import app
from app.models.bom import BomItem, BomProject, RiskLevel
from app.models.preferred import BomSelectionReview, PreferredPart

client = TestClient(app)


def _clear():
    init_db()
    db = SessionLocal()
    db.query(BomSelectionReview).delete()
    db.query(PreferredPart).delete()
    db.query(BomItem).delete()
    db.query(BomProject).delete()
    db.commit()
    db.close()


def test_preferred_library_import_summary_and_review_api(tmp_path):
    _clear()
    file_path = tmp_path / "preferred.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "二极管"
    ws.append(["品牌", "名称", "通用化状态", "物料号", "型号", "封装形式", "应用方案", "成本"])
    ws.append(["YAGEO", "快恢复二极管", "⭐强推入库(跨3+项目)", "D-001", "US1M", "SMA", "电源整流", 0.12])
    wb.save(file_path)

    with file_path.open("rb") as f:
        resp = client.post("/api/preferred-library/import", files={"file": ("preferred.xlsx", f, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")})
    assert resp.status_code == 200
    assert resp.json()["imported_parts"] == 1

    summary = client.get("/api/preferred-library/summary")
    assert summary.status_code == 200
    assert summary.json()["total_parts"] == 1
    assert summary.json()["strong_recommended_count"] == 1

    db = SessionLocal()
    db.add(BomProject(id=301, filename="new.csv", project_name="新项目", total_items=1))
    db.add(BomItem(bom_upload_id=301, row_number=1, raw_part_number="D-001", raw_brand="YAGEO", raw_category="二极管", raw_spec="US1M SMA", risk_level=RiskLevel.GREEN))
    db.commit()
    db.close()

    review = client.post("/api/preferred-library/review/301")
    assert review.status_code == 200
    data = review.json()
    assert data["summary"]["preferred_hit_count"] == 1
    assert data["items"][0]["selection_risk_level"] == "green"
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```powershell
py -3.11 -m pytest tests\test_preferred_library_api.py -q
```

Expected: FAIL because `/api/preferred-library/import` route does not exist.

- [ ] **Step 3: Implement API router**

Create `backend/app/api/preferred_library.py`:

```python
import os
import shutil
import tempfile
from fastapi import APIRouter, Depends, File, Query, UploadFile
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.preferred import PreferredPart
from app.services.preferred_library.excel_importer import PreferredLibraryImporter
from app.services.preferred_library.review_service import PreferredLibraryReviewService

router = APIRouter(prefix="/api/preferred-library", tags=["preferred-library"])


@router.post("/import")
def import_preferred_library(file: UploadFile = File(...), db: Session = Depends(get_db)):
    suffix = os.path.splitext(file.filename or "preferred.xlsx")[1] or ".xlsx"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        shutil.copyfileobj(file.file, tmp)
        tmp_path = tmp.name
    try:
        return PreferredLibraryImporter(db).import_file(tmp_path, source_file=file.filename or "preferred.xlsx")
    finally:
        try:
            os.remove(tmp_path)
        except OSError:
            pass


@router.get("/summary")
def preferred_summary(db: Session = Depends(get_db)):
    parts = db.query(PreferredPart).all()
    categories = {p.category_level_3 for p in parts if p.category_level_3}
    return {
        "total_parts": len(parts),
        "category_count": len(categories),
        "strong_recommended_count": sum(1 for p in parts if p.preferred_level == "strong_recommended"),
        "medium_recommended_count": sum(1 for p in parts if p.preferred_level == "medium_recommended"),
        "pending_review_count": sum(1 for p in parts if p.control_status == "pending_review"),
        "blocked_count": sum(1 for p in parts if p.control_status == "blocked"),
        "restricted_count": sum(1 for p in parts if p.control_status == "restricted"),
    }


@router.get("/parts")
def list_preferred_parts(
    category: str | None = Query(None),
    brand: str | None = Query(None),
    status: str | None = Query(None),
    db: Session = Depends(get_db),
):
    query = db.query(PreferredPart)
    if category:
        query = query.filter(PreferredPart.category_level_3.contains(category))
    if brand:
        query = query.filter(PreferredPart.normalized_brand.contains(brand.upper()))
    if status:
        query = query.filter(PreferredPart.control_status == status)
    parts = query.order_by(PreferredPart.id.desc()).limit(200).all()
    return {"parts": [p.to_dict() for p in parts]}


@router.post("/review/{bom_project_id}")
def review_project(bom_project_id: int, db: Session = Depends(get_db)):
    return PreferredLibraryReviewService(db).review_project(bom_project_id)


@router.get("/review/{bom_project_id}")
def get_review(bom_project_id: int, db: Session = Depends(get_db)):
    return PreferredLibraryReviewService(db).get_latest_review(bom_project_id)
```

- [ ] **Step 4: Register router in app main**

Modify `backend/app/main.py` imports:

```python
from app.api import events, bom_upload, risk_analysis, bom_project, intel_watch, market_inbox, preferred_library
```

Add after other include_router calls:

```python
app.include_router(preferred_library.router)
```

- [ ] **Step 5: Run API tests**

Run:

```powershell
py -3.11 -m pytest tests\test_preferred_library_api.py -q
```

Expected: `1 passed`.

- [ ] **Step 6: Run all v3.4 backend tests**

Run:

```powershell
py -3.11 -m pytest tests\test_preferred_library_importer.py tests\test_preferred_library_review.py tests\test_preferred_library_api.py -q
```

Expected: `6 passed`.

- [ ] **Step 7: Commit**

```powershell
git add backend/app/api/preferred_library.py backend/app/main.py tests/test_preferred_library_api.py
git commit -m "feat: add preferred library API"
```

---

### Task 5: Frontend independent preferred library window

**Files:**
- Create: `frontend/src/api/preferredLibrary.js`
- Create: `frontend/src/views/PreferredLibrary.vue`
- Create: `frontend/src/views/__tests__/PreferredLibrary.test.js`
- Modify: `frontend/src/router/index.js`
- Modify: `frontend/src/App.vue`

**Interfaces:**
- Consumes: API `/preferred-library/import`, `/preferred-library/summary`, `/preferred-library/review/{id}`
- Produces: route `/preferred-library`

- [ ] **Step 1: Write failing frontend test**

Create `frontend/src/views/__tests__/PreferredLibrary.test.js`:

```javascript
import { mount, flushPromises } from '@vue/test-utils'
import { describe, expect, it, vi } from 'vitest'
import PreferredLibrary from '../PreferredLibrary.vue'

vi.mock('../../api/preferredLibrary', () => ({
  getPreferredSummary: vi.fn(() => Promise.resolve({ data: { total_parts: 2, strong_recommended_count: 1, pending_review_count: 1 } })),
  reviewBomSelection: vi.fn(() => Promise.resolve({
    data: {
      summary: {
        total_items: 2,
        preferred_hit_count: 1,
        preferred_hit_rate: 0.5,
        non_preferred_count: 1,
        new_part_count: 1,
        temporary_blocked_count: 1,
        restricted_count: 0,
        red_count: 1,
        yellow_count: 0,
        alternative_count: 1
      },
      items: [
        {
          id: 1,
          match_status: 'not_found',
          is_new_part: true,
          delivery_control_status: 'temporary_blocked',
          selection_risk_level: 'red',
          selection_reason: '交期风险联动为临时禁选。',
          selection_action: '需研发说明不可替代理由，并由采购/工程确认。',
          recommended_alternatives: [{ brand: 'YAGEO', mpn: 'US1M' }]
        }
      ]
    }
  }))
}))

describe('PreferredLibrary', () => {
  it('renders independent governance page and review result', async () => {
    const wrapper = mount(PreferredLibrary, {
      global: {
        stubs: ['el-card', 'el-row', 'el-col', 'el-statistic', 'el-button', 'el-input-number', 'el-table', 'el-table-column', 'el-tag', 'el-upload'],
      }
    })
    await flushPromises()
    expect(wrapper.get('[data-testid="preferred-library-page"]').text()).toContain('优选库治理')
    await wrapper.get('[data-testid="bom-project-id"]').setValue('301')
    await wrapper.get('[data-testid="run-selection-review"]').trigger('click')
    await flushPromises()
    expect(wrapper.get('[data-testid="selection-review-result"]').text()).toContain('临时禁选')
    expect(wrapper.text()).toContain('US1M')
  })
})
```

- [ ] **Step 2: Run test to verify it fails**

Run from `frontend`:

```powershell
npm test -- --run src/views/__tests__/PreferredLibrary.test.js
```

Expected: FAIL because `PreferredLibrary.vue` does not exist.

- [ ] **Step 3: Create frontend API client**

Create `frontend/src/api/preferredLibrary.js`:

```javascript
import client from './client'

export function importPreferredLibrary(file) {
  const formData = new FormData()
  formData.append('file', file)
  return client.post('/preferred-library/import', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}

export function getPreferredSummary() {
  return client.get('/preferred-library/summary')
}

export function listPreferredParts(params = {}) {
  return client.get('/preferred-library/parts', { params })
}

export function reviewBomSelection(projectId) {
  return client.post(`/preferred-library/review/${projectId}`)
}

export function getBomSelectionReview(projectId) {
  return client.get(`/preferred-library/review/${projectId}`)
}
```

- [ ] **Step 4: Create independent page**

Create `frontend/src/views/PreferredLibrary.vue`:

```vue
<template>
  <div class="preferred-library" data-testid="preferred-library-page">
    <div class="page-header">
      <h1>优选库治理</h1>
      <p>独立识别非优选料、历史新料、交期风险禁选/限选和替代建议，不与 BOM 风险页混合展示。</p>
    </div>

    <el-card class="section-card">
      <template #header>优选库导入</template>
      <el-upload :auto-upload="false" :show-file-list="true" :on-change="onFileChange" data-testid="preferred-upload">
        <el-button>选择优选库 Excel</el-button>
      </el-upload>
      <el-button type="primary" :disabled="!selectedFile" :loading="importing" @click="submitImport">导入优选库</el-button>
      <pre v-if="importResult" class="result-json">{{ importResult }}</pre>
    </el-card>

    <el-row :gutter="12" class="summary-row">
      <el-col :span="6"><el-card><el-statistic title="优选物料" :value="summary.total_parts || 0" /></el-card></el-col>
      <el-col :span="6"><el-card><el-statistic title="强推" :value="summary.strong_recommended_count || 0" /></el-card></el-col>
      <el-col :span="6"><el-card><el-statistic title="待评审" :value="summary.pending_review_count || 0" /></el-card></el-col>
      <el-col :span="6"><el-card><el-statistic title="禁用/限用" :value="(summary.blocked_count || 0) + (summary.restricted_count || 0)" /></el-card></el-col>
    </el-row>

    <el-card class="section-card">
      <template #header>BOM 选型审查</template>
      <div class="review-actions">
        <label>项目 ID</label>
        <input v-model="projectId" data-testid="bom-project-id" class="project-input" />
        <el-button type="primary" :loading="reviewing" data-testid="run-selection-review" @click="runReview">执行选型审查</el-button>
      </div>
    </el-card>

    <el-card v-if="reviewResult" class="section-card" data-testid="selection-review-result">
      <template #header>审查结果</template>
      <el-row :gutter="12" class="summary-row">
        <el-col :span="4"><el-statistic title="BOM 行数" :value="reviewResult.summary.total_items || 0" /></el-col>
        <el-col :span="4"><el-statistic title="优选命中" :value="reviewResult.summary.preferred_hit_count || 0" /></el-col>
        <el-col :span="4"><el-statistic title="非优选" :value="reviewResult.summary.non_preferred_count || 0" /></el-col>
        <el-col :span="4"><el-statistic title="历史新料" :value="reviewResult.summary.new_part_count || 0" /></el-col>
        <el-col :span="4"><el-statistic title="临时禁选" :value="reviewResult.summary.temporary_blocked_count || 0" /></el-col>
        <el-col :span="4"><el-statistic title="替代建议" :value="reviewResult.summary.alternative_count || 0" /></el-col>
      </el-row>

      <el-table :data="reviewResult.items" stripe>
        <el-table-column prop="match_status" label="命中状态" />
        <el-table-column prop="is_new_part" label="历史新料">
          <template #default="scope">{{ scope.row.is_new_part ? '是' : '否' }}</template>
        </el-table-column>
        <el-table-column prop="delivery_control_status" label="交期联动">
          <template #default="scope">
            <el-tag :type="deliveryTagType(scope.row.delivery_control_status)">{{ deliveryStatusLabel(scope.row.delivery_control_status) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="selection_risk_level" label="选型风险" />
        <el-table-column prop="selection_reason" label="原因" min-width="220" />
        <el-table-column label="替代建议" min-width="180">
          <template #default="scope">
            <span v-for="part in scope.row.recommended_alternatives || []" :key="part.id || part.mpn" class="alt-part">
              {{ part.brand }} {{ part.mpn }}
            </span>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { getPreferredSummary, importPreferredLibrary, reviewBomSelection } from '../api/preferredLibrary'

const summary = reactive({})
const selectedFile = ref(null)
const importing = ref(false)
const reviewing = ref(false)
const importResult = ref(null)
const reviewResult = ref(null)
const projectId = ref('')

async function loadSummary() {
  const { data } = await getPreferredSummary()
  Object.assign(summary, data)
}

function onFileChange(file) {
  selectedFile.value = file.raw
}

async function submitImport() {
  if (!selectedFile.value) return
  importing.value = true
  try {
    const { data } = await importPreferredLibrary(selectedFile.value)
    importResult.value = data
    await loadSummary()
    ElMessage.success('优选库导入完成')
  } finally {
    importing.value = false
  }
}

async function runReview() {
  if (!projectId.value) {
    ElMessage.warning('请输入 BOM 项目 ID')
    return
  }
  reviewing.value = true
  try {
    const { data } = await reviewBomSelection(projectId.value)
    reviewResult.value = data
  } finally {
    reviewing.value = false
  }
}

function deliveryStatusLabel(status) {
  return {
    normal: '正常',
    watch: '观察',
    restricted: '限选',
    temporary_blocked: '临时禁选'
  }[status] || status
}

function deliveryTagType(status) {
  return {
    normal: 'success',
    watch: 'info',
    restricted: 'warning',
    temporary_blocked: 'danger'
  }[status] || 'info'
}

onMounted(loadSummary)
</script>

<style scoped>
.preferred-library { padding: 20px; }
.page-header { margin-bottom: 16px; }
.page-header h1 { margin: 0 0 8px; }
.page-header p { margin: 0; color: #667085; }
.section-card { margin-bottom: 16px; }
.summary-row { margin-bottom: 16px; }
.review-actions { display: flex; align-items: center; gap: 12px; }
.project-input { width: 160px; padding: 7px 10px; border: 1px solid #dcdfe6; border-radius: 4px; }
.result-json { background: #f7f9fc; padding: 12px; border-radius: 6px; white-space: pre-wrap; }
.alt-part { display: inline-block; margin-right: 8px; }
</style>
```

- [ ] **Step 5: Register route and menu**

Modify `frontend/src/router/index.js` by inserting before `/watch`:

```javascript
{
  path: '/preferred-library',
  name: 'preferred-library',
  component: () => import('../views/PreferredLibrary.vue')
},
```

Modify `frontend/src/App.vue` by adding a menu item near `行情收件箱`:

```vue
<el-menu-item index="/preferred-library">
  <el-icon><Star /></el-icon>
  <span>优选库治理</span>
</el-menu-item>
```

If `Star` is not imported from `@element-plus/icons-vue`, add it to the existing icon import list.

- [ ] **Step 6: Run frontend test**

Run from `frontend`:

```powershell
npm test -- --run src/views/__tests__/PreferredLibrary.test.js
```

Expected: `1 passed`.

- [ ] **Step 7: Commit**

```powershell
git add frontend/src/api/preferredLibrary.js frontend/src/views/PreferredLibrary.vue frontend/src/views/__tests__/PreferredLibrary.test.js frontend/src/router/index.js frontend/src/App.vue
git commit -m "feat: add preferred library governance page"
```

---

### Task 6: Deploy script, docs, E2E and final verification

**Files:**
- Create: `frontend/e2e/v34-preferred-library.spec.js`
- Modify: `deploy-v3.2-mvp.ps1`
- Modify: `README-V3.2-MVP.md`
- Modify: `DEMO-V3.2.md`
- Modify: `GIT-HANDOFF.md`

**Interfaces:**
- Consumes: v3.4 backend API and frontend route
- Produces: deployed WorkBuddy project with v3.4 tests and demo

- [ ] **Step 1: Create E2E spec**

Create `frontend/e2e/v34-preferred-library.spec.js`:

```javascript
import { expect, test } from '@playwright/test'

test('v3.4 preferred library page is independent and shows governance result', async ({ page }) => {
  await page.goto('/#/preferred-library')
  await expect(page.getByRole('heading', { name: '优选库治理' })).toBeVisible()
  await expect(page.getByText('不与 BOM 风险页混合展示')).toBeVisible()
  await page.getByTestId('bom-project-id').fill('1')
  await expect(page.getByTestId('run-selection-review')).toBeVisible()
})
```

- [ ] **Step 2: Update deploy script**

Modify `deploy-v3.2-mvp.ps1`:

Add backend files to copy/compile lists:

```powershell
Copy-Item (Join-Path $SRC "backend\app\api\preferred_library.py") $targetApi -Force
Copy-Item (Join-Path $SRC "backend\app\models\preferred.py") (Join-Path $DST "backend\app\models\preferred.py") -Force
Copy-Item (Join-Path $SRC "backend\app\services\preferred_library") (Join-Path $DST "backend\app\services") -Recurse -Force
```

Add tests:

```powershell
"test_preferred_library_importer.py",
"test_preferred_library_review.py",
"test_preferred_library_api.py"
```

Add frontend files:

```powershell
"src\views\PreferredLibrary.vue",
"src\views\__tests__\PreferredLibrary.test.js",
"src\api\preferredLibrary.js",
"e2e\v34-preferred-library.spec.js"
```

Add v3.4 pytest entries to both `py -3.11` and fallback `python` test commands:

```powershell
tests\test_preferred_library_importer.py tests\test_preferred_library_review.py tests\test_preferred_library_api.py
```

- [ ] **Step 3: Update docs**

Append concise v3.4 sections to `README-V3.2-MVP.md`, `DEMO-V3.2.md`, and `GIT-HANDOFF.md`:

```markdown
## v3.4 优选库治理

v3.4 新增独立“优选库治理”窗口，支持导入二三级优选库 Excel，并对 BOM 输出优选命中、非优选、历史新料、交期风险临时禁选/限选和替代建议。BOM 风险页与优选库治理页分开展示。

重点验证命令：

```powershell
py -3.11 -m pytest tests\test_preferred_library_importer.py tests\test_preferred_library_review.py tests\test_preferred_library_api.py -q
cd frontend
npm test -- --run src/views/__tests__/PreferredLibrary.test.js
```
```

- [ ] **Step 4: Run backend tests**

Run:

```powershell
py -3.11 -m pytest tests\test_preferred_library_importer.py tests\test_preferred_library_review.py tests\test_preferred_library_api.py -q
py -3.11 -m pytest tests -q
```

Expected: v3.4 focused tests pass and full backend test suite passes.

- [ ] **Step 5: Run frontend tests and build**

Run from `frontend`:

```powershell
npm test -- --run
npm run build
```

Expected: all frontend tests pass and build exits 0.

- [ ] **Step 6: Deploy to WorkBuddy target**

Run:

```powershell
powershell -ExecutionPolicy Bypass -File "d:\1项目清单\交期风险排查\BOM-Risk-Analyzer-patch\deploy-v3.2-mvp.ps1" -TargetProject "D:\软件\workbuddy\WorkBuddy\BOM-Risk-Analyzer"
```

Expected: deploy script exits 0 and includes v3.4 tests in output.

- [ ] **Step 7: Run browser E2E**

If old services are running, stop ports 8001 and 9000 first. Then run from target project:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\e2e-browser-demo.ps1
```

Expected: v3.2, v3.3 and v3.4 E2E specs pass.

- [ ] **Step 8: Commit deploy/docs/E2E**

```powershell
git add frontend/e2e/v34-preferred-library.spec.js deploy-v3.2-mvp.ps1 README-V3.2-MVP.md DEMO-V3.2.md GIT-HANDOFF.md
git commit -m "test: add v3.4 preferred library demo validation"
```

- [ ] **Step 9: Regenerate and verify Git bundle**

Run:

```powershell
git bundle create "..\BOM-Risk-Analyzer-v3.2-mvp.bundle" --all
git bundle verify "..\BOM-Risk-Analyzer-v3.2-mvp.bundle"
```

Expected: bundle verification prints `okay`.

---

## Self-Review

- Spec coverage: Tasks cover Excel import, standardization, historical new part recognition, independent UI window, delivery risk temporary blocked/restricted/watch logic, API, frontend, deploy and E2E.
- Scope control: MVP excludes approval workflow, automatic BOM rewrite, complex parameter equivalence and datasheet parsing.
- Type consistency: `delivery_control_status`, `delivery_control_reason`, `PreferredLibraryImporter`, `PreferredLibraryReviewService`, and `/api/preferred-library` names are consistent across backend, frontend and tests.
- Known implementation risk: the deploy script structure must be inspected before editing because previous versions already include v3.2/v3.3 file lists and two pytest command branches.
