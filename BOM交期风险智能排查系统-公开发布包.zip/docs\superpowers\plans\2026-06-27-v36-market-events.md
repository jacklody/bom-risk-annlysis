# v3.6 MarketEvents 实用管理版 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 补齐“市场事件”前端页面和事件 API 客户端，并扩展后端筛选能力，让 A 项生成的 `MarketEvent` 可以被查看、筛选、追溯和手动刷新。

**Architecture:** 后端继续使用现有 FastAPI `/api/events` 路由，只在 `list_events` 中增加事件类型、严重度和活跃状态筛选，不新增数据库字段。前端新增 `events.js` 作为统一事件 API 客户端，新增 `MarketEvents.vue` 负责列表、筛选、详情抽屉和触发采集；部署脚本复制新增文件和测试。

**Tech Stack:** FastAPI、SQLAlchemy、SQLite、pytest、Vue 3 `<script setup>`、Element Plus、Axios、Vitest、Vue Test Utils、PowerShell 部署脚本。

## Global Constraints

- 只实现 v3.6 实用管理版，不实现 v3.7 的事件状态操作、影响项目追踪和来源复核链路。
- 不新增数据库字段，不修改 `MarketEvent` 表结构。
- 不做趋势图，不做供应商 API 接入，不把 C 项内容提前合入。
- 保持现有 `/api/events/` 兼容：不传活跃状态参数时默认只查活跃事件。
- 前端页面字段为空时显示“暂无”或“未填写”，不能留空让用户误判为加载失败。
- 所有新增文件需要纳入 `deploy-v3.2-mvp.ps1`。
- 每个任务完成后运行对应测试并提交一次。

---

## File Structure

- Modify: `backend/app/api/events.py`
  - 负责扩展 `GET /api/events/` 查询参数和筛选逻辑。
  - 保留现有 `collect`、`manual`、`get_event` 行为。
- Create: `tests/test_market_events_api.py`
  - 负责验证事件列表筛选、活跃状态筛选和详情查询。
- Create: `frontend/src/api/events.js`
  - 负责封装 `listEvents`、`getEvent`、`collectEvents`、`addManualEvent`。
  - 同时修复 `ManualEventQuickAdd.vue` 和其测试依赖的 `addManualEvent` import。
- Create: `frontend/src/views/MarketEvents.vue`
  - 负责市场事件页面：筛选表单、事件列表、详情抽屉、刷新、触发采集。
- Create: `frontend/src/views/__tests__/MarketEvents.test.js`
  - 负责验证页面加载、筛选查询、详情展示和触发采集。
- Modify: `deploy-v3.2-mvp.ps1`
  - 负责复制新增前端文件、测试文件和后端测试。

---

### Task 1: 后端事件列表筛选

**Files:**
- Modify: `backend/app/api/events.py`
- Create: `tests/test_market_events_api.py`

**Interfaces:**
- Consumes: existing `MarketEvent.to_dict() -> dict`
- Produces: `GET /api/events/?brand=&category=&event_type=&severity=&active_status=&skip=&limit=` returning `{ "total": int, "events": list[dict] }`

- [ ] **Step 1: 写后端失败测试**

Create `tests/test_market_events_api.py` with this content:

```python
from fastapi.testclient import TestClient

from app.database import SessionLocal, init_db
from app.main import app
from app.models.event import EventType, MarketEvent, Severity

client = TestClient(app)


def _clean_events():
    init_db()
    db = SessionLocal()
    db.query(MarketEvent).delete()
    db.commit()
    db.close()


def _seed_event(
    *,
    brand: str,
    category: str,
    event_type: EventType,
    severity: Severity,
    is_active: int = 1,
    confidence: float = 0.8,
) -> int:
    db = SessionLocal()
    try:
        event = MarketEvent(
            source_name="测试来源",
            source_url="test://market-event",
            raw_text=f"{brand} {category} 行情通知",
            raw_title=f"{brand} {category} 通知",
            brand=brand,
            category=category,
            event_type=event_type,
            severity=severity,
            estimated_lead_time_impact_weeks=12,
            estimated_price_impact_pct=18.0,
            confidence=confidence,
            is_active=is_active,
        )
        db.add(event)
        db.commit()
        db.refresh(event)
        return event.id
    finally:
        db.close()


def test_list_events_filters_by_event_type_and_severity():
    _clean_events()
    _seed_event(
        brand="TDK",
        category="high_cap_mlcc",
        event_type=EventType.PRICE_INCREASE,
        severity=Severity.HIGH,
    )
    _seed_event(
        brand="Murata",
        category="resistor",
        event_type=EventType.SHORTAGE,
        severity=Severity.MEDIUM,
    )

    resp = client.get("/api/events/", params={"event_type": "price_increase", "severity": "high"})

    assert resp.status_code == 200
    data = resp.json()
    assert data["total"] == 1
    assert data["events"][0]["brand"] == "TDK"
    assert data["events"][0]["event_type"] == "price_increase"
    assert data["events"][0]["severity"] == "high"


def test_list_events_active_status_all_and_inactive():
    _clean_events()
    _seed_event(
        brand="TDK",
        category="mlcc",
        event_type=EventType.PRICE_INCREASE,
        severity=Severity.HIGH,
        is_active=1,
    )
    _seed_event(
        brand="Yageo",
        category="resistor",
        event_type=EventType.SHORTAGE,
        severity=Severity.LOW,
        is_active=0,
    )

    default_resp = client.get("/api/events/")
    assert default_resp.status_code == 200
    assert default_resp.json()["total"] == 1
    assert default_resp.json()["events"][0]["brand"] == "TDK"

    inactive_resp = client.get("/api/events/", params={"active_status": "inactive"})
    assert inactive_resp.status_code == 200
    assert inactive_resp.json()["total"] == 1
    assert inactive_resp.json()["events"][0]["brand"] == "Yageo"

    all_resp = client.get("/api/events/", params={"active_status": "all"})
    assert all_resp.status_code == 200
    assert all_resp.json()["total"] == 2


def test_get_event_returns_detail_fields():
    _clean_events()
    event_id = _seed_event(
        brand="TDK",
        category="high_cap_mlcc",
        event_type=EventType.LEAD_TIME,
        severity=Severity.CRITICAL,
        confidence=0.91,
    )

    resp = client.get(f"/api/events/{event_id}")

    assert resp.status_code == 200
    data = resp.json()
    assert data["id"] == event_id
    assert data["brand"] == "TDK"
    assert data["category"] == "high_cap_mlcc"
    assert data["event_type"] == "lead_time"
    assert data["severity"] == "critical"
    assert data["confidence"] == 0.91
    assert data["raw_text_excerpt"]
```

- [ ] **Step 2: 运行测试确认失败**

Run:

```powershell
pytest tests\test_market_events_api.py -q
```

Expected: at least one failure because `event_type`、`severity`、`active_status` filtering is not implemented yet.

- [ ] **Step 3: 实现后端筛选**

Modify `backend/app/api/events.py` so the import and `list_events` function become:

```python
"""市场事件接口"""

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.event import EventType, MarketEvent, Severity
from app.services.event_collector import EventCollector
from app.services.upstream.manual_event_service import build_market_event_from_manual_payload

router = APIRouter()


@router.get("/")
def list_events(
    db: Session = Depends(get_db),
    brand: str | None = Query(None),
    category: str | None = Query(None),
    event_type: EventType | None = Query(None),
    severity: Severity | None = Query(None),
    active_status: str = Query("active", pattern="^(active|inactive|all)$"),
    is_active: bool | None = Query(None),
    skip: int = 0,
    limit: int = 50,
):
    query = db.query(MarketEvent)

    if active_status == "active":
        if is_active is False:
            query = query.filter(MarketEvent.is_active == 0)
        else:
            query = query.filter(MarketEvent.is_active == 1)
    elif active_status == "inactive":
        query = query.filter(MarketEvent.is_active == 0)

    if brand:
        query = query.filter(MarketEvent.brand.contains(brand))
    if category:
        query = query.filter(MarketEvent.category.contains(category))
    if event_type:
        query = query.filter(MarketEvent.event_type == event_type)
    if severity:
        query = query.filter(MarketEvent.severity == severity)

    total = query.count()
    events = (
        query.order_by(MarketEvent.created_at.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )
    return {"total": total, "events": [e.to_dict() for e in events]}
```

Keep the existing `trigger_collection`、`add_manual_event`、`get_event` functions unchanged.

- [ ] **Step 4: 运行后端测试确认通过**

Run:

```powershell
pytest tests\test_market_events_api.py -q
```

Expected:

```text
3 passed
```

- [ ] **Step 5: 运行相关后端回归测试**

Run:

```powershell
pytest tests\test_market_events_api.py tests\test_market_inbox_api.py tests\test_market_inbox_review.py -q
```

Expected: all tests pass.

- [ ] **Step 6: 提交后端筛选能力**

Run:

```powershell
git add backend/app/api/events.py tests/test_market_events_api.py
git commit -m "feat: expand market events filters"
```

---

### Task 2: 前端事件 API 客户端

**Files:**
- Create: `frontend/src/api/events.js`
- Test: `frontend/src/components/__tests__/ManualEventQuickAdd.test.js`

**Interfaces:**
- Consumes: `client` from `frontend/src/api/client.js`
- Produces:
  - `listEvents(params?: object): Promise`
  - `getEvent(eventId: number|string): Promise`
  - `collectEvents(): Promise`
  - `addManualEvent(payload: object): Promise`

- [ ] **Step 1: 写 API 文件**

Create `frontend/src/api/events.js`:

```javascript
import client from './client'

export function listEvents(params = {}) {
  return client.get('/events/', { params })
}

export function getEvent(eventId) {
  return client.get(`/events/${eventId}`)
}

export function collectEvents() {
  return client.post('/events/collect')
}

export function addManualEvent(payload) {
  return client.post('/events/manual', payload)
}
```

- [ ] **Step 2: 运行 ManualEventQuickAdd 测试**

Run:

```powershell
npm test -- --run src/components/__tests__/ManualEventQuickAdd.test.js
```

Working directory: `frontend`

Expected: the previous import error for `../../api/events` is gone. If the test now fails because of component behavior, keep the API file unchanged and inspect the test failure before editing the component.

- [ ] **Step 3: 提交 API 客户端**

Run:

```powershell
git add frontend/src/api/events.js
git commit -m "feat: add market events api client"
```

---

### Task 3: MarketEvents 页面

**Files:**
- Create: `frontend/src/views/MarketEvents.vue`

**Interfaces:**
- Consumes:
  - `listEvents(params)` from `frontend/src/api/events.js`
  - `getEvent(eventId)` from `frontend/src/api/events.js`
  - `collectEvents()` from `frontend/src/api/events.js`
- Produces: `/events` route can render a usable market events management page.

- [ ] **Step 1: 创建页面实现**

Create `frontend/src/views/MarketEvents.vue`:

```vue
<template>
  <div class="market-events-page">
    <el-card class="filter-card">
      <template #header>
        <div class="header-row">
          <div>
            <h2>市场事件</h2>
            <p>集中查看行情收件箱、人工录入和采集任务生成的风险事件。</p>
          </div>
          <div class="header-actions">
            <el-button data-testid="events-refresh" :loading="loading" @click="loadEvents">刷新列表</el-button>
            <el-button type="primary" data-testid="events-collect" :loading="collecting" @click="handleCollect">触发采集</el-button>
          </div>
        </div>
      </template>

      <div class="filters">
        <el-input v-model="filters.brand" clearable placeholder="品牌，如 TDK" data-testid="events-filter-brand" />
        <el-input v-model="filters.category" clearable placeholder="品类，如 high_cap_mlcc" data-testid="events-filter-category" />
        <el-select v-model="filters.event_type" clearable placeholder="事件类型" data-testid="events-filter-type">
          <el-option v-for="item in eventTypeOptions" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
        <el-select v-model="filters.severity" clearable placeholder="严重度" data-testid="events-filter-severity">
          <el-option v-for="item in severityOptions" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
        <el-select v-model="filters.active_status" placeholder="活跃状态" data-testid="events-filter-active">
          <el-option label="活跃" value="active" />
          <el-option label="停用" value="inactive" />
          <el-option label="全部" value="all" />
        </el-select>
        <el-button type="primary" data-testid="events-search" @click="loadEvents">查询</el-button>
      </div>
    </el-card>

    <el-card class="list-card">
      <template #header>
        <div class="header-row">
          <h3>事件列表</h3>
          <span class="total-text">共 {{ total }} 条</span>
        </div>
      </template>

      <div v-if="!loading && !events.length" class="empty-tip" data-testid="events-empty">
        暂无市场事件。可以从行情收件箱确认信号、手动新增事件，或触发采集。
      </div>

      <el-table v-else :data="events" stripe style="width: 100%" v-loading="loading" data-testid="events-table">
        <el-table-column prop="brand" label="品牌" width="110">
          <template #default="scope">{{ displayValue(scope.row.brand) }}</template>
        </el-table-column>
        <el-table-column prop="category" label="品类" min-width="150">
          <template #default="scope">{{ displayValue(scope.row.category) }}</template>
        </el-table-column>
        <el-table-column prop="event_type" label="事件类型" width="130">
          <template #default="scope"><el-tag>{{ labelFor(eventTypeOptions, scope.row.event_type) }}</el-tag></template>
        </el-table-column>
        <el-table-column prop="severity" label="严重度" width="110">
          <template #default="scope"><el-tag :type="severityTag(scope.row.severity)">{{ labelFor(severityOptions, scope.row.severity) }}</el-tag></template>
        </el-table-column>
        <el-table-column prop="confidence" label="置信度" width="100">
          <template #default="scope">{{ formatPercent(scope.row.confidence) }}</template>
        </el-table-column>
        <el-table-column prop="source_name" label="来源" min-width="140">
          <template #default="scope">{{ displayValue(scope.row.source_name) }}</template>
        </el-table-column>
        <el-table-column prop="raw_title" label="标题" min-width="180">
          <template #default="scope">{{ displayValue(scope.row.raw_title) }}</template>
        </el-table-column>
        <el-table-column prop="estimated_lead_time_impact_weeks" label="交期影响" width="110">
          <template #default="scope">{{ scope.row.estimated_lead_time_impact_weeks ? `${scope.row.estimated_lead_time_impact_weeks} 周` : '暂无' }}</template>
        </el-table-column>
        <el-table-column prop="estimated_price_impact_pct" label="涨价影响" width="110">
          <template #default="scope">{{ scope.row.estimated_price_impact_pct ? `${scope.row.estimated_price_impact_pct}%` : '暂无' }}</template>
        </el-table-column>
        <el-table-column prop="created_at" label="创建时间" width="170">
          <template #default="scope">{{ formatDate(scope.row.created_at) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="110" fixed="right">
          <template #default="scope">
            <el-button size="small" link type="primary" data-testid="events-detail" @click="openDetail(scope.row)">查看详情</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-drawer v-model="detailVisible" title="事件详情" size="42%" data-testid="events-detail-drawer">
      <div v-if="selectedEvent" class="detail-body">
        <section>
          <h4>基本信息</h4>
          <p><span>品牌：</span>{{ displayValue(selectedEvent.brand) }}</p>
          <p><span>品类：</span>{{ displayValue(selectedEvent.category) }}</p>
          <p><span>事件类型：</span>{{ labelFor(eventTypeOptions, selectedEvent.event_type) }}</p>
          <p><span>严重度：</span>{{ labelFor(severityOptions, selectedEvent.severity) }}</p>
          <p><span>置信度：</span>{{ formatPercent(selectedEvent.confidence) }}</p>
          <p><span>交叉验证：</span>{{ selectedEvent.cross_validated ? '是' : '否' }}</p>
        </section>

        <section>
          <h4>来源信息</h4>
          <p><span>来源名称：</span>{{ displayValue(selectedEvent.source_name) }}</p>
          <p><span>来源链接：</span><a v-if="selectedEvent.source_url" :href="selectedEvent.source_url" target="_blank">{{ selectedEvent.source_url }}</a><span v-else>暂无</span></p>
          <p><span>原始标题：</span>{{ displayValue(selectedEvent.raw_title) }}</p>
          <p><span>原文摘要：</span>{{ displayValue(selectedEvent.raw_text_excerpt) }}</p>
        </section>

        <section>
          <h4>风险影响</h4>
          <p><span>交期影响：</span>{{ selectedEvent.estimated_lead_time_impact_weeks ? `${selectedEvent.estimated_lead_time_impact_weeks} 周` : '暂无' }}</p>
          <p><span>价格影响：</span>{{ selectedEvent.estimated_price_impact_pct ? `${selectedEvent.estimated_price_impact_pct}%` : '暂无' }}</p>
          <p><span>创建时间：</span>{{ formatDate(selectedEvent.created_at) }}</p>
        </section>
      </div>
    </el-drawer>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { collectEvents, getEvent, listEvents } from '../api/events'

const loading = ref(false)
const collecting = ref(false)
const events = ref([])
const total = ref(0)
const detailVisible = ref(false)
const selectedEvent = ref(null)

const filters = reactive({
  brand: '',
  category: '',
  event_type: '',
  severity: '',
  active_status: 'active'
})

const eventTypeOptions = [
  { label: '缺货', value: 'shortage' },
  { label: '涨价', value: 'price_increase' },
  { label: '产能问题', value: 'capacity_issue' },
  { label: '交期延长', value: 'lead_time' },
  { label: '停产', value: 'eol' },
  { label: '政策', value: 'policy' },
  { label: '灾害', value: 'disaster' },
  { label: '其他', value: 'other' }
]

const severityOptions = [
  { label: '严重', value: 'critical' },
  { label: '高', value: 'high' },
  { label: '中', value: 'medium' },
  { label: '低', value: 'low' },
  { label: '未知', value: 'unknown' }
]

function buildParams() {
  const params = { active_status: filters.active_status }
  if (filters.brand) params.brand = filters.brand
  if (filters.category) params.category = filters.category
  if (filters.event_type) params.event_type = filters.event_type
  if (filters.severity) params.severity = filters.severity
  return params
}

function displayValue(value) {
  return value === null || value === undefined || value === '' ? '暂无' : value
}

function formatPercent(value) {
  if (value === null || value === undefined) return '暂无'
  return `${Math.round(Number(value) * 100)}%`
}

function formatDate(value) {
  if (!value) return '暂无'
  return new Date(value).toLocaleString('zh-CN', { hour12: false })
}

function labelFor(options, value) {
  return options.find((item) => item.value === value)?.label || displayValue(value)
}

function severityTag(value) {
  if (value === 'critical' || value === 'high') return 'danger'
  if (value === 'medium') return 'warning'
  if (value === 'low') return 'success'
  return 'info'
}

async function loadEvents() {
  loading.value = true
  try {
    const { data } = await listEvents(buildParams())
    events.value = data.events || []
    total.value = data.total || 0
  } catch (error) {
    ElMessage.error(error?.response?.data?.detail || '市场事件加载失败')
    events.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

async function openDetail(row) {
  try {
    const { data } = await getEvent(row.id)
    selectedEvent.value = data
    detailVisible.value = true
  } catch (error) {
    ElMessage.error(error?.response?.data?.detail || '事件详情加载失败')
  }
}

async function handleCollect() {
  collecting.value = true
  try {
    const { data } = await collectEvents()
    ElMessage.success(`采集完成，新增 ${data.collected || 0} 条事件`)
    await loadEvents()
  } catch (error) {
    ElMessage.error(error?.response?.data?.detail || '事件采集失败')
  } finally {
    collecting.value = false
  }
}

onMounted(loadEvents)
</script>

<style scoped>
.market-events-page {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.header-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 16px;
}

.header-row h2,
.header-row h3 {
  margin: 0;
}

.header-row p {
  margin: 6px 0 0;
  color: #6b7280;
  font-size: 13px;
}

.header-actions,
.filters {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}

.filters .el-input,
.filters .el-select {
  width: 190px;
}

.total-text,
.empty-tip {
  color: #6b7280;
  font-size: 13px;
}

.empty-tip {
  padding: 32px;
  text-align: center;
  background: #f8fafc;
  border-radius: 8px;
}

.detail-body section {
  padding-bottom: 16px;
  margin-bottom: 16px;
  border-bottom: 1px solid #edf2f7;
}

.detail-body h4 {
  margin: 0 0 12px;
}

.detail-body p {
  margin: 8px 0;
  line-height: 1.6;
}

.detail-body span:first-child {
  color: #6b7280;
}
</style>
```

- [ ] **Step 2: 运行前端构建发现编译问题**

Run:

```powershell
npm run build
```

Working directory: `frontend`

Expected: in the patch repository this may fail if `index.html` is absent. If it fails with `Could not resolve entry module "index.html"`, do not edit source code for that reason; target project build will be verified after deploy. If it fails because of Vue syntax or imports, fix `MarketEvents.vue` before continuing.

- [ ] **Step 3: 提交页面**

Run:

```powershell
git add frontend/src/views/MarketEvents.vue
git commit -m "feat: add market events management page"
```

---

### Task 4: MarketEvents 前端测试

**Files:**
- Create: `frontend/src/views/__tests__/MarketEvents.test.js`

**Interfaces:**
- Consumes: `MarketEvents.vue`
- Mocks: `../../api/events` exports `listEvents`、`getEvent`、`collectEvents`

- [ ] **Step 1: 写页面测试**

Create `frontend/src/views/__tests__/MarketEvents.test.js`:

```javascript
import { mount, flushPromises } from '@vue/test-utils'
import MarketEvents from '../MarketEvents.vue'
import * as api from '../../api/events'

vi.mock('../../api/events', () => ({
  listEvents: vi.fn(),
  getEvent: vi.fn(),
  collectEvents: vi.fn()
}))

const sampleEvent = {
  id: 1,
  brand: 'TDK',
  category: 'high_cap_mlcc',
  event_type: 'price_increase',
  severity: 'high',
  confidence: 0.91,
  source_name: 'TDK代理商邮件',
  source_url: 'mail://tdk-notice-001',
  raw_title: 'TDK高容MLCC缺货涨价通知',
  raw_text_excerpt: 'TDK 高容MLCC 缺货，预计涨价 10%-20%，交期延长至 16 周',
  estimated_lead_time_impact_weeks: 16,
  estimated_price_impact_pct: 20,
  cross_validated: 0,
  created_at: '2026-06-27T10:00:00+00:00'
}

const globalStubs = {
  'el-card': { template: '<div><slot name="header" /><slot /></div>' },
  'el-button': { props: ['loading', 'size', 'type', 'link'], template: '<button @click="$emit(\'click\')"><slot /></button>' },
  'el-input': {
    props: ['modelValue'],
    emits: ['update:modelValue'],
    template: '<input :value="modelValue" @input="$emit(\'update:modelValue\', $event.target.value)" />'
  },
  'el-select': {
    props: ['modelValue'],
    emits: ['update:modelValue'],
    template: '<select :value="modelValue" @change="$emit(\'update:modelValue\', $event.target.value)"><slot /></select>'
  },
  'el-option': { props: ['label', 'value'], template: '<option :value="value">{{ label }}</option>' },
  'el-tag': { props: ['type'], template: '<span><slot /></span>' },
  'el-drawer': {
    props: ['modelValue', 'title'],
    template: '<div v-if="modelValue"><h3>{{ title }}</h3><slot /></div>'
  },
  'el-table': {
    props: ['data'],
    template: '<table><tbody><tr v-for="row in data" :key="row.id"><td>{{ row.brand }}</td><td>{{ row.category }}</td><td>{{ row.event_type }}</td><td>{{ row.severity }}</td><td>{{ row.source_name }}</td><td>{{ row.raw_title }}</td><td><button data-testid="events-detail" @click="$parent.$emit(\'row-detail\', row)">查看详情</button></td></tr></tbody></table>'
  },
  'el-table-column': { template: '<td><slot /></td>' }
}

describe('MarketEvents', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    api.listEvents.mockResolvedValue({ data: { total: 1, events: [sampleEvent] } })
    api.getEvent.mockResolvedValue({ data: sampleEvent })
    api.collectEvents.mockResolvedValue({ data: { collected: 1, events: [sampleEvent] } })
  })

  it('loads and renders market events', async () => {
    const wrapper = mount(MarketEvents, { global: { stubs: globalStubs } })
    await flushPromises()

    expect(api.listEvents).toHaveBeenCalledWith({ active_status: 'active' })
    expect(wrapper.text()).toContain('市场事件')
    expect(wrapper.text()).toContain('TDK')
    expect(wrapper.text()).toContain('high_cap_mlcc')
    expect(wrapper.text()).toContain('TDK高容MLCC缺货涨价通知')
  })

  it('queries with filter parameters', async () => {
    const wrapper = mount(MarketEvents, { global: { stubs: globalStubs } })
    await flushPromises()

    await wrapper.find('[data-testid="events-filter-brand"]').setValue('TDK')
    await wrapper.find('[data-testid="events-filter-category"]').setValue('high_cap_mlcc')
    await wrapper.find('[data-testid="events-filter-type"]').setValue('price_increase')
    await wrapper.find('[data-testid="events-filter-severity"]').setValue('high')
    await wrapper.find('[data-testid="events-search"]').trigger('click')
    await flushPromises()

    expect(api.listEvents).toHaveBeenLastCalledWith({
      active_status: 'active',
      brand: 'TDK',
      category: 'high_cap_mlcc',
      event_type: 'price_increase',
      severity: 'high'
    })
  })

  it('opens detail drawer through component method', async () => {
    const wrapper = mount(MarketEvents, { global: { stubs: globalStubs } })
    await flushPromises()

    await wrapper.vm.openDetail(sampleEvent)
    await flushPromises()

    expect(api.getEvent).toHaveBeenCalledWith(1)
    expect(wrapper.text()).toContain('事件详情')
    expect(wrapper.text()).toContain('TDK代理商邮件')
    expect(wrapper.text()).toContain('TDK 高容MLCC 缺货')
  })

  it('collects events and reloads list', async () => {
    const wrapper = mount(MarketEvents, { global: { stubs: globalStubs } })
    await flushPromises()

    await wrapper.find('[data-testid="events-collect"]').trigger('click')
    await flushPromises()

    expect(api.collectEvents).toHaveBeenCalled()
    expect(api.listEvents).toHaveBeenCalledTimes(2)
  })
})
```

- [ ] **Step 2: 暴露 `openDetail` 给测试或改用真实按钮测试**

If Step 1 fails because `wrapper.vm.openDetail` is not available in `<script setup>`, add this before `onMounted(loadEvents)` in `MarketEvents.vue`:

```javascript
defineExpose({ openDetail, loadEvents, handleCollect })
```

- [ ] **Step 3: 运行 MarketEvents 测试**

Run:

```powershell
npm test -- --run src/views/__tests__/MarketEvents.test.js
```

Working directory: `frontend`

Expected:

```text
4 passed
```

If the custom `el-table` stub does not trigger table-column scoped slots, keep assertions focused on rendered text and use `defineExpose` for detail behavior as shown above.

- [ ] **Step 4: 运行相关前端测试**

Run:

```powershell
npm test -- --run src/views/__tests__/MarketEvents.test.js src/views/__tests__/MarketInbox.test.js src/components/__tests__/ManualEventQuickAdd.test.js
```

Working directory: `frontend`

Expected: all selected tests pass.

- [ ] **Step 5: 提交前端测试**

Run:

```powershell
git add frontend/src/views/MarketEvents.vue frontend/src/views/__tests__/MarketEvents.test.js
git commit -m "test: cover market events page"
```

---

### Task 5: 部署脚本和验证

**Files:**
- Modify: `deploy-v3.2-mvp.ps1`

**Interfaces:**
- Consumes: files created in Tasks 1-4
- Produces: deploy script copies v3.6 files to target project and runs relevant checks.

- [ ] **Step 1: 更新前端复制列表**

In `deploy-v3.2-mvp.ps1`, extend `$frontendFiles` so it includes the new files:

```powershell
$frontendFiles = @(
    "src\components\V32EvidencePanel.vue",
    "src\components\ManualEventQuickAdd.vue",
    "src\components\RiskDetailTable.vue",
    "src\components\BomUploader.vue",
    "src\views\BomAnalyze.vue",
    "src\views\MarketInbox.vue",
    "src\views\MarketEvents.vue",
    "src\views\PreferredLibrary.vue",
    "src\views\__tests__\MarketInbox.test.js",
    "src\views\__tests__\MarketEvents.test.js",
    "src\views\__tests__\PreferredLibrary.test.js",
    "src\api\events.js",
    "src\api\marketInbox.js",
    "src\api\preferredLibrary.js",
    "src\router\index.js",
    "src\App.vue",
    "e2e\v32-demo-loop.spec.js",
    "e2e\v33-market-inbox.spec.js",
    "e2e\v34-preferred-library.spec.js"
)
```

- [ ] **Step 2: 更新后端测试复制列表**

In the same file, extend `$testFiles` so it includes:

```powershell
"test_market_events_api.py",
```

Place it near `test_market_inbox_api.py`:

```powershell
"test_market_notice_parser.py",
"test_market_events_api.py",
"test_market_inbox_api.py",
"test_market_inbox_review.py",
```

- [ ] **Step 3: 更新语法检查列表**

Confirm `$compileFiles` still includes:

```powershell
"app\api\events.py",
```

No new backend module needs to be added.

- [ ] **Step 4: 运行后端全量测试**

Run:

```powershell
pytest -q
```

Expected: all backend tests pass. If unrelated legacy tests fail, capture the failure and run focused tests before deciding whether to fix it in this scope.

- [ ] **Step 5: 运行前端相关测试**

Run:

```powershell
npm test -- --run src/views/__tests__/MarketEvents.test.js src/views/__tests__/MarketInbox.test.js src/components/__tests__/ManualEventQuickAdd.test.js
```

Working directory: `frontend`

Expected: selected tests pass.

- [ ] **Step 6: 部署到目标项目并验证**

Run the deploy script from the patch folder with the actual target project path used in this project:

```powershell
powershell -ExecutionPolicy Bypass -File "d:\1项目清单\交期风险排查\BOM-Risk-Analyzer-patch\deploy-v3.2-mvp.ps1" -TargetProject "<目标项目路径>"
```

Expected:

```text
Files copied
Syntax checks passed
Backend tests passed
Frontend build passed
```

If the target path is already known from previous deployment notes, use that exact path. Do not deploy to an inferred folder without checking it exists.

- [ ] **Step 7: 提交部署脚本**

Run:

```powershell
git add deploy-v3.2-mvp.ps1
git commit -m "chore: include market events page in deploy script"
```

---

## Self-Review

### Spec coverage

- v3.6 新增 `MarketEvents.vue`：Task 3 covers it.
- v3.6 新增 `events.js`：Task 2 covers it.
- 后端事件类型、严重度、活跃状态筛选：Task 1 covers it.
- 事件列表关键字段展示：Task 3 covers it.
- 详情抽屉展示来源、证据摘要和影响字段：Task 3 covers it.
- 刷新和触发采集：Task 3 covers it.
- 后端测试、前端测试：Task 1 and Task 4 cover them.
- `ManualEventQuickAdd` import 修复：Task 2 covers it.
- 部署脚本包含新增文件和测试：Task 5 covers it.
- v3.7 内容未纳入实现：Global Constraints explicitly excludes it.

### Placeholder scan

No TBD, TODO, “implement later”, or unspecified “add tests” placeholders remain. Each task includes concrete files, code, commands, expected outcomes, and commit messages.

### Type consistency

The frontend API functions used by `MarketEvents.vue` match `events.js`: `listEvents`、`getEvent`、`collectEvents`。后端筛选参数 match the spec and frontend: `brand`、`category`、`event_type`、`severity`、`active_status`。
