# v3.7 MarketEvents 增强运营版 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在 v3.6 市场事件查看页基础上增加运营处理能力：启用/停用事件、查看事件影响到的 BOM 项目和物料、追溯来自行情收件箱的复核信号。

**Architecture:** 后端继续复用 `MarketEvent.is_active` 实现启用/停用，不新增数据库字段；新增两个只读聚合接口：事件影响摘要、事件来源复核链路。前端在 `MarketEvents.vue` 详情抽屉中增加状态操作、影响摘要、受影响项目列表和复核来源区域，避免提前进入趋势分析或供应商 API 接入。

**Tech Stack:** FastAPI、SQLAlchemy、SQLite、pytest、Vue 3 `<script setup>`、Element Plus、Axios、Vitest、Vue Test Utils、PowerShell 部署脚本。

## Global Constraints

- 只实现 v3.7 增强运营版，不实现 C 项行情趋势视图和预测验证，不实现 D 项真实供应商 API 接入。
- 不新增数据库字段，不修改 `MarketEvent` 表结构；事件启用/停用只复用 `MarketEvent.is_active`。
- 不新增 `operation_status`、`review_status` 等事件表字段，避免 SQLite 迁移。
- 停用事件后，后续风险扫描不再匹配该事件；重新启用后恢复匹配，依赖现有风险扫描只读取 `is_active=1` 的行为。
- 影响项目追踪只从已有 `BomItem.matched_event_ids` 反查，不重新扫描 BOM，不写入 BOM 数据。
- 来源复核链路只从 `ExtractedMarketSignal.market_event_id` 和 `RawMarketNotice` 读取，不修改行情收件箱数据。
- 前端字段为空时显示“暂无”，不能留空让用户误判为加载失败。
- 所有新增文件或新增测试必须纳入 `deploy-v3.2-mvp.ps1`；本计划优先复用现有文件，不创建新部署脚本。
- 每个任务完成后运行对应测试并提交一次。

---

## File Structure

- Modify: `backend/app/api/events.py`
  - 增加 `PATCH /api/events/{event_id}/status`。
  - 增加 `GET /api/events/{event_id}/impact`。
  - 增加 `GET /api/events/{event_id}/source-signal`。
- Modify: `backend/app/models/event.py`
  - 在 `MarketEvent.to_dict()` 中返回 `is_active`，供列表、详情和启停操作统一显示状态。
- Modify: `tests/test_market_events_api.py`
  - 增加启用/停用、影响摘要、来源复核链路测试。
- Modify: `frontend/src/api/events.js`
  - 增加 `updateEventStatus(eventId, payload)`、`getEventImpact(eventId)`、`getEventSourceSignal(eventId)`。
- Modify: `frontend/src/views/MarketEvents.vue`
  - 详情抽屉增加状态操作、影响摘要、受影响项目列表、复核来源区域。
- Modify: `frontend/src/views/__tests__/MarketEvents.test.js`
  - 增加状态操作、影响摘要、来源复核链路前端测试。
- Modify: `deploy-v3.2-mvp.ps1`
  - 更新输出文案和显式测试说明，确保 v3.7 覆盖仍被部署流程验证。

---

### Task 1: 后端事件启用/停用接口

**Files:**
- Modify: `backend/app/api/events.py`
- Modify: `backend/app/models/event.py`
- Modify: `tests/test_market_events_api.py`

**Interfaces:**
- Consumes: `MarketEvent.is_active: int`
- Produces: `PATCH /api/events/{event_id}/status` accepting `{ "action": "disable" | "enable" }` and returning `{ "event": dict, "message": str }`

- [ ] **Step 1: 写失败测试**

Append these tests to `tests/test_market_events_api.py`:

```python
def test_update_event_status_disables_event_and_hides_from_active_list():
    _clean_events()
    event_id = _seed_event(
        brand="TDK",
        category="high_cap_mlcc",
        event_type=EventType.PRICE_INCREASE,
        severity=Severity.HIGH,
        is_active=1,
    )

    resp = client.patch(f"/api/events/{event_id}/status", json={"action": "disable"})

    assert resp.status_code == 200
    data = resp.json()
    assert data["event"]["id"] == event_id
    assert data["event"]["is_active"] == 0
    assert data["message"] == "事件已停用"

    active_resp = client.get("/api/events/")
    assert active_resp.status_code == 200
    assert active_resp.json()["total"] == 0

    all_resp = client.get("/api/events/", params={"active_status": "all"})
    assert all_resp.status_code == 200
    assert all_resp.json()["total"] == 1


def test_update_event_status_enables_event_again():
    _clean_events()
    event_id = _seed_event(
        brand="TDK",
        category="high_cap_mlcc",
        event_type=EventType.PRICE_INCREASE,
        severity=Severity.HIGH,
        is_active=0,
    )

    resp = client.patch(f"/api/events/{event_id}/status", json={"action": "enable"})

    assert resp.status_code == 200
    data = resp.json()
    assert data["event"]["id"] == event_id
    assert data["event"]["is_active"] == 1
    assert data["message"] == "事件已启用"

    active_resp = client.get("/api/events/")
    assert active_resp.status_code == 200
    assert active_resp.json()["total"] == 1


def test_update_event_status_rejects_unknown_action():
    _clean_events()
    event_id = _seed_event(
        brand="TDK",
        category="high_cap_mlcc",
        event_type=EventType.PRICE_INCREASE,
        severity=Severity.HIGH,
    )

    resp = client.patch(f"/api/events/{event_id}/status", json={"action": "archive"})

    assert resp.status_code == 422
```

- [ ] **Step 2: 运行测试确认失败**

Run:

```powershell
py -3.11 -m pytest tests\test_market_events_api.py -q
```

Expected: status endpoint tests fail with 404 or method not allowed.

- [ ] **Step 3: 实现接口**

Modify the import section in `backend/app/api/events.py`:

```python
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
```

Add this request model after `router = APIRouter()`:

```python
class EventStatusRequest(BaseModel):
    action: str = Field(..., pattern="^(disable|enable)$")
```

Add this route before `@router.get("/{event_id}")`:

```python
@router.patch("/{event_id}/status")
def update_event_status(event_id: int, payload: EventStatusRequest, db: Session = Depends(get_db)):
    event = db.query(MarketEvent).filter(MarketEvent.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    if payload.action == "disable":
        event.is_active = 0
        message = "事件已停用"
    else:
        event.is_active = 1
        message = "事件已启用"

    db.commit()
    db.refresh(event)
    return {"event": event.to_dict(), "message": message}
```

Modify `MarketEvent.to_dict()` in `backend/app/models/event.py` to include `is_active`:

```python
"is_active": self.is_active,
```

Place it near `created_at`.

- [ ] **Step 4: 运行测试确认通过**

Run:

```powershell
py -3.11 -m pytest tests\test_market_events_api.py -q
```

Expected: all tests in this file pass.

- [ ] **Step 5: 运行后端相关回归**

Run:

```powershell
py -3.11 -m pytest tests\test_market_events_api.py tests\test_market_inbox_api.py tests\test_market_inbox_review.py -q
```

Expected: all selected tests pass.

- [ ] **Step 6: 提交**

Run:

```powershell
git add backend/app/api/events.py backend/app/models/event.py tests/test_market_events_api.py
git commit -m "feat: add market event status operations"
```

---

### Task 2: 后端事件影响项目摘要

**Files:**
- Modify: `backend/app/api/events.py`
- Modify: `tests/test_market_events_api.py`

**Interfaces:**
- Consumes: `BomItem.matched_event_ids`, `BomProject.to_summary()`, `BomItem.risk_level`
- Produces: `GET /api/events/{event_id}/impact` returning:
  - `event_id: int`
  - `project_count: int`
  - `item_count: int`
  - `risk_counts: { red: int, yellow: int, green: int, gray: int }`
  - `projects: list[dict]`

- [ ] **Step 1: 写失败测试**

Append this test to `tests/test_market_events_api.py`:

```python
def test_get_event_impact_summarizes_projects_and_items():
    from app.models.bom import BomItem, BomProject, RiskLevel

    _clean_events()
    db = SessionLocal()
    db.query(BomItem).delete()
    db.query(BomProject).delete()
    db.commit()
    try:
        event = MarketEvent(
            source_name="测试来源",
            source_url="test://impact",
            raw_text="TDK MLCC 涨价缺货",
            raw_title="TDK MLCC 通知",
            brand="TDK",
            category="high_cap_mlcc",
            event_type=EventType.PRICE_INCREASE,
            severity=Severity.HIGH,
            confidence=0.9,
            is_active=1,
        )
        db.add(event)
        db.commit()
        db.refresh(event)

        project = BomProject(filename="real_bom.xlsx", project_name="真实项目A", status="active", total_items=2)
        db.add(project)
        db.commit()
        db.refresh(project)

        db.add_all([
            BomItem(
                bom_upload_id=project.id,
                row_number=1,
                raw_part_number="C3225X5R1A226M250AC",
                raw_brand="TDK",
                raw_category="MLCC",
                normalized_brand="TDK",
                normalized_category="high_cap_mlcc",
                risk_level=RiskLevel.RED,
                risk_score=91,
                matched_event_ids=str(event.id),
            ),
            BomItem(
                bom_upload_id=project.id,
                row_number=2,
                raw_part_number="C1608X7R1H104K080AA",
                raw_brand="TDK",
                raw_category="MLCC",
                normalized_brand="TDK",
                normalized_category="high_cap_mlcc",
                risk_level=RiskLevel.YELLOW,
                risk_score=72,
                matched_event_ids=f"999,{event.id}",
            ),
        ])
        db.commit()
        event_id = event.id
    finally:
        db.close()

    resp = client.get(f"/api/events/{event_id}/impact")

    assert resp.status_code == 200
    data = resp.json()
    assert data["event_id"] == event_id
    assert data["project_count"] == 1
    assert data["item_count"] == 2
    assert data["risk_counts"] == {"red": 1, "yellow": 1, "green": 0, "gray": 0}
    assert data["projects"][0]["project_id"]
    assert data["projects"][0]["project_name"] == "真实项目A"
    assert data["projects"][0]["affected_item_count"] == 2
    assert data["projects"][0]["highest_risk_level"] == "red"
```

- [ ] **Step 2: 运行测试确认失败**

Run:

```powershell
py -3.11 -m pytest tests\test_market_events_api.py::test_get_event_impact_summarizes_projects_and_items -q
```

Expected: fails with 404.

- [ ] **Step 3: 实现影响摘要接口**

Modify imports in `backend/app/api/events.py`:

```python
from app.models.bom import BomItem, BomProject
```

Add helper functions before routes or near the new route:

```python
def _csv_contains_id(csv_text: str | None, target_id: int) -> bool:
    if not csv_text:
        return False
    return str(target_id) in {part.strip() for part in csv_text.split(",") if part.strip()}


def _risk_value(item: BomItem) -> str:
    if not item.risk_level:
        return "gray"
    return item.risk_level.value if hasattr(item.risk_level, "value") else str(item.risk_level)


def _highest_risk(levels: list[str]) -> str:
    order = {"red": 4, "yellow": 3, "green": 2, "gray": 1}
    if not levels:
        return "gray"
    return max(levels, key=lambda level: order.get(level, 0))
```

Add route before `@router.get("/{event_id}")`:

```python
@router.get("/{event_id}/impact")
def get_event_impact(event_id: int, db: Session = Depends(get_db)):
    event = db.query(MarketEvent).filter(MarketEvent.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    items = db.query(BomItem).all()
    matched_items = [item for item in items if _csv_contains_id(item.matched_event_ids, event_id)]
    project_ids = sorted({item.bom_upload_id for item in matched_items})
    projects = db.query(BomProject).filter(BomProject.id.in_(project_ids)).all() if project_ids else []
    project_map = {project.id: project for project in projects}

    risk_counts = {"red": 0, "yellow": 0, "green": 0, "gray": 0}
    grouped: dict[int, list[BomItem]] = {}
    for item in matched_items:
        level = _risk_value(item)
        if level not in risk_counts:
            level = "gray"
        risk_counts[level] += 1
        grouped.setdefault(item.bom_upload_id, []).append(item)

    project_payloads = []
    for project_id, project_items in grouped.items():
        levels = [_risk_value(item) for item in project_items]
        project = project_map.get(project_id)
        project_payloads.append({
            "project_id": project_id,
            "project_name": (project.project_name or project.filename) if project else f"项目 {project_id}",
            "affected_item_count": len(project_items),
            "highest_risk_level": _highest_risk(levels),
        })

    project_payloads.sort(key=lambda item: item["project_id"])
    return {
        "event_id": event_id,
        "project_count": len(grouped),
        "item_count": len(matched_items),
        "risk_counts": risk_counts,
        "projects": project_payloads,
    }
```

- [ ] **Step 4: 运行测试确认通过**

Run:

```powershell
py -3.11 -m pytest tests\test_market_events_api.py::test_get_event_impact_summarizes_projects_and_items -q
```

Expected: test passes.

- [ ] **Step 5: 运行后端相关回归**

Run:

```powershell
py -3.11 -m pytest tests\test_market_events_api.py tests\test_market_inbox_review.py -q
```

Expected: all selected tests pass.

- [ ] **Step 6: 提交**

Run:

```powershell
git add backend/app/api/events.py tests/test_market_events_api.py
git commit -m "feat: summarize market event BOM impact"
```

---

### Task 3: 后端行情收件箱来源追溯接口

**Files:**
- Modify: `backend/app/api/events.py`
- Modify: `tests/test_market_events_api.py`

**Interfaces:**
- Consumes: `ExtractedMarketSignal.market_event_id`, `RawMarketNotice.id`
- Produces: `GET /api/events/{event_id}/source-signal` returning `{ "event_id": int, "signal": dict | None, "raw_notice": dict | None }`

- [ ] **Step 1: 写失败测试**

Append this test to `tests/test_market_events_api.py`:

```python
def test_get_event_source_signal_returns_review_context():
    from app.models.event import ExtractedMarketSignal, RawMarketNotice

    _clean_events()
    db = SessionLocal()
    db.query(ExtractedMarketSignal).delete()
    db.query(RawMarketNotice).delete()
    db.commit()
    try:
        event = MarketEvent(
            source_name="行情收件箱复核",
            source_url="market-inbox://review/1",
            raw_text="TDK 高容 MLCC 缺货涨价",
            raw_title="TDK MLCC 复核确认",
            brand="TDK",
            category="high_cap_mlcc",
            event_type=EventType.PRICE_INCREASE,
            severity=Severity.HIGH,
            confidence=0.85,
            is_active=1,
        )
        db.add(event)
        db.commit()
        db.refresh(event)

        notice = RawMarketNotice(
            source_type="email",
            source_name="采购邮箱",
            source_url="mail://notice-001",
            title="TDK MLCC 缺货涨价邮件",
            raw_text="供应商确认 TDK 高容 MLCC 缺货，交期 16 周。",
            sender="buyer@example.com",
            parse_status="parsed",
        )
        db.add(notice)
        db.commit()
        db.refresh(notice)

        signal = ExtractedMarketSignal(
            raw_notice_id=notice.id,
            market_event_id=event.id,
            brand="TDK",
            category="high_cap_mlcc",
            event_type="price_increase",
            confidence=0.85,
            evidence_text="供应商确认缺货涨价",
            review_status="confirmed",
            reviewed_by="purchaser",
            review_notes="电话复核属实",
        )
        db.add(signal)
        db.commit()
        event_id = event.id
    finally:
        db.close()

    resp = client.get(f"/api/events/{event_id}/source-signal")

    assert resp.status_code == 200
    data = resp.json()
    assert data["event_id"] == event_id
    assert data["signal"]["review_status"] == "confirmed"
    assert data["signal"]["reviewed_by"] == "purchaser"
    assert data["signal"]["review_notes"] == "电话复核属实"
    assert data["signal"]["evidence_text"] == "供应商确认缺货涨价"
    assert data["raw_notice"]["source_name"] == "采购邮箱"
    assert data["raw_notice"]["title"] == "TDK MLCC 缺货涨价邮件"
```

- [ ] **Step 2: 运行测试确认失败**

Run:

```powershell
py -3.11 -m pytest tests\test_market_events_api.py::test_get_event_source_signal_returns_review_context -q
```

Expected: fails with 404.

- [ ] **Step 3: 实现来源追溯接口**

Modify imports in `backend/app/api/events.py`:

```python
from app.models.event import EventType, ExtractedMarketSignal, MarketEvent, RawMarketNotice, Severity
```

Add route before `@router.get("/{event_id}")`:

```python
@router.get("/{event_id}/source-signal")
def get_event_source_signal(event_id: int, db: Session = Depends(get_db)):
    event = db.query(MarketEvent).filter(MarketEvent.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    signal = (
        db.query(ExtractedMarketSignal)
        .filter(ExtractedMarketSignal.market_event_id == event_id)
        .order_by(ExtractedMarketSignal.id.desc())
        .first()
    )
    notice = None
    if signal:
        notice = db.query(RawMarketNotice).filter(RawMarketNotice.id == signal.raw_notice_id).first()

    return {
        "event_id": event_id,
        "signal": signal.to_dict() if signal else None,
        "raw_notice": notice.to_dict() if notice else None,
    }
```

- [ ] **Step 4: 运行测试确认通过**

Run:

```powershell
py -3.11 -m pytest tests\test_market_events_api.py::test_get_event_source_signal_returns_review_context -q
```

Expected: test passes.

- [ ] **Step 5: 运行后端相关回归**

Run:

```powershell
py -3.11 -m pytest tests\test_market_events_api.py tests\test_market_inbox_review.py -q
```

Expected: all selected tests pass.

- [ ] **Step 6: 提交**

Run:

```powershell
git add backend/app/api/events.py tests/test_market_events_api.py
git commit -m "feat: expose market event source signal"
```

---

### Task 4: 前端 API 客户端扩展

**Files:**
- Modify: `frontend/src/api/events.js`

**Interfaces:**
- Consumes: v3.7 backend endpoints from Tasks 1-3
- Produces:
  - `updateEventStatus(eventId, payload): Promise`
  - `getEventImpact(eventId): Promise`
  - `getEventSourceSignal(eventId): Promise`

- [ ] **Step 1: 修改 API 客户端**

Append these functions to `frontend/src/api/events.js`:

```javascript
export function updateEventStatus(eventId, payload) {
  return client.patch(`/events/${eventId}/status`, payload)
}

export function getEventImpact(eventId) {
  return client.get(`/events/${eventId}/impact`)
}

export function getEventSourceSignal(eventId) {
  return client.get(`/events/${eventId}/source-signal`)
}
```

- [ ] **Step 2: 运行当前前端测试**

Run:

```powershell
npm test -- --run src/views/__tests__/MarketEvents.test.js src/components/__tests__/ManualEventQuickAdd.test.js
```

Working directory: `frontend`

Expected: existing tests still pass.

- [ ] **Step 3: 提交**

Run:

```powershell
git add frontend/src/api/events.js
git commit -m "feat: add market event operations api client"
```

---

### Task 5: 前端详情抽屉运营能力

**Files:**
- Modify: `frontend/src/views/MarketEvents.vue`
- Modify: `frontend/src/views/__tests__/MarketEvents.test.js`

**Interfaces:**
- Consumes:
  - `updateEventStatus(eventId, payload)`
  - `getEventImpact(eventId)`
  - `getEventSourceSignal(eventId)`
- Produces: 详情抽屉展示状态操作、影响摘要、受影响项目列表、复核来源。

- [ ] **Step 1: 写失败测试**

Modify `frontend/src/views/__tests__/MarketEvents.test.js` mock block to include new functions:

```javascript
vi.mock('../../api/events', () => ({
  listEvents: vi.fn(),
  getEvent: vi.fn(),
  collectEvents: vi.fn(),
  updateEventStatus: vi.fn(),
  getEventImpact: vi.fn(),
  getEventSourceSignal: vi.fn()
}))
```

In `beforeEach`, add defaults:

```javascript
api.getEventImpact.mockResolvedValue({
  data: {
    event_id: 1,
    project_count: 1,
    item_count: 2,
    risk_counts: { red: 1, yellow: 1, green: 0, gray: 0 },
    projects: [{ project_id: 10, project_name: '真实项目A', affected_item_count: 2, highest_risk_level: 'red' }]
  }
})
api.getEventSourceSignal.mockResolvedValue({
  data: {
    event_id: 1,
    signal: {
      review_status: 'confirmed',
      reviewed_by: 'purchaser',
      review_notes: '电话复核属实',
      evidence_text: '供应商确认缺货涨价'
    },
    raw_notice: {
      source_name: '采购邮箱',
      title: 'TDK MLCC 缺货涨价邮件',
      raw_text_excerpt: '供应商确认 TDK 高容 MLCC 缺货，交期 16 周。'
    }
  }
})
api.updateEventStatus.mockResolvedValue({ data: { event: { ...sampleEvent, is_active: 0 }, message: '事件已停用' } })
```

Add this test:

```javascript
it('loads impact and source signal when opening detail drawer', async () => {
  const wrapper = mountMarketEvents()
  await flushPromises()

  await wrapper.find('[data-testid="events-detail"]').trigger('click')
  await flushPromises()

  expect(api.getEventImpact).toHaveBeenCalledWith(1)
  expect(api.getEventSourceSignal).toHaveBeenCalledWith(1)
  const text = wrapper.text()
  expect(text).toContain('影响项目')
  expect(text).toContain('真实项目A')
  expect(text).toContain('受影响物料：2')
  expect(text).toContain('复核来源')
  expect(text).toContain('电话复核属实')
  expect(text).toContain('供应商确认缺货涨价')
})
```

Add this test:

```javascript
it('disables event from detail drawer and reloads list', async () => {
  const wrapper = mountMarketEvents()
  await flushPromises()

  await wrapper.find('[data-testid="events-detail"]').trigger('click')
  await flushPromises()
  await wrapper.find('[data-testid="events-disable"]').trigger('click')
  await flushPromises()

  expect(api.updateEventStatus).toHaveBeenCalledWith(1, { action: 'disable' })
  expect(api.listEvents.mock.calls.length).toBeGreaterThan(1)
})
```

- [ ] **Step 2: 运行测试确认失败**

Run:

```powershell
npm test -- --run src/views/__tests__/MarketEvents.test.js
```

Working directory: `frontend`

Expected: tests fail because v3.7 UI and API calls are not wired.

- [ ] **Step 3: 修改页面脚本导入和状态**

Modify import in `MarketEvents.vue`:

```javascript
import {
  collectEvents,
  getEvent,
  getEventImpact,
  getEventSourceSignal,
  listEvents,
  updateEventStatus
} from '../api/events'
```

Add refs after `selectedEvent`:

```javascript
const eventImpact = ref(null)
const sourceSignal = ref(null)
const operatingStatus = ref(false)
```

Modify `openDetail(row)` to load v3.7 data:

```javascript
async function openDetail(row) {
  try {
    const [{ data: eventData }, { data: impactData }, { data: sourceData }] = await Promise.all([
      getEvent(row.id),
      getEventImpact(row.id),
      getEventSourceSignal(row.id)
    ])
    selectedEvent.value = eventData
    eventImpact.value = impactData
    sourceSignal.value = sourceData
    detailVisible.value = true
  } catch (error) {
    ElMessage.error(error?.response?.data?.detail || '事件详情加载失败')
  }
}
```

Add helper functions:

```javascript
function riskText(level) {
  const map = { red: '红色', yellow: '黄色', green: '绿色', gray: '灰色' }
  return map[level] || displayValue(level)
}

function isActive(event) {
  return Number(event?.is_active ?? 1) === 1
}

async function changeEventStatus(action) {
  if (!selectedEvent.value) return
  operatingStatus.value = true
  try {
    const { data } = await updateEventStatus(selectedEvent.value.id, { action })
    selectedEvent.value = data.event
    ElMessage.success(data.message || '事件状态已更新')
    await loadEvents()
  } catch (error) {
    ElMessage.error(error?.response?.data?.detail || '事件状态更新失败')
  } finally {
    operatingStatus.value = false
  }
}
```

- [ ] **Step 4: 修改详情模板**

Inside the first detail `<section>` after cross validation, add:

```vue
<p><span>状态：</span>{{ isActive(selectedEvent) ? '活跃' : '停用' }}</p>
<div class="detail-actions">
  <el-button v-if="isActive(selectedEvent)" type="danger" size="small" data-testid="events-disable" :loading="operatingStatus" @click="changeEventStatus('disable')">停用事件</el-button>
  <el-button v-else type="success" size="small" data-testid="events-enable" :loading="operatingStatus" @click="changeEventStatus('enable')">启用事件</el-button>
</div>
```

After risk impact section, add:

```vue
<section>
  <h4>影响项目</h4>
  <p><span>项目数：</span>{{ eventImpact?.project_count ?? 0 }}</p>
  <p><span>受影响物料：</span>{{ eventImpact?.item_count ?? 0 }}</p>
  <p><span>风险分布：</span>红 {{ eventImpact?.risk_counts?.red ?? 0 }} / 黄 {{ eventImpact?.risk_counts?.yellow ?? 0 }} / 绿 {{ eventImpact?.risk_counts?.green ?? 0 }} / 灰 {{ eventImpact?.risk_counts?.gray ?? 0 }}</p>
  <div v-if="eventImpact?.projects?.length" class="impact-projects">
    <div v-for="project in eventImpact.projects" :key="project.project_id" class="impact-project">
      <strong>{{ project.project_name }}</strong>
      <span>受影响物料：{{ project.affected_item_count }}</span>
      <span>最高风险：{{ riskText(project.highest_risk_level) }}</span>
    </div>
  </div>
  <p v-else>暂无已记录影响项目</p>
</section>

<section>
  <h4>复核来源</h4>
  <template v-if="sourceSignal?.signal">
    <p><span>复核状态：</span>{{ displayValue(sourceSignal.signal.review_status) }}</p>
    <p><span>复核人：</span>{{ displayValue(sourceSignal.signal.reviewed_by) }}</p>
    <p><span>复核备注：</span>{{ displayValue(sourceSignal.signal.review_notes) }}</p>
    <p><span>证据文本：</span>{{ displayValue(sourceSignal.signal.evidence_text) }}</p>
    <p><span>原始通知：</span>{{ displayValue(sourceSignal.raw_notice?.title) }}</p>
    <p><span>通知来源：</span>{{ displayValue(sourceSignal.raw_notice?.source_name) }}</p>
  </template>
  <p v-else>暂无行情收件箱复核来源</p>
</section>
```

Add CSS:

```css
.detail-actions {
  margin-top: 10px;
}

.impact-projects {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.impact-project {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  padding: 8px 10px;
  background: #f8fafc;
  border-radius: 6px;
  font-size: 13px;
}
```

- [ ] **Step 5: 运行前端测试确认通过**

Run:

```powershell
npm test -- --run src/views/__tests__/MarketEvents.test.js
```

Expected: tests pass.

- [ ] **Step 6: 运行相关前端回归**

Run:

```powershell
npm test -- --run src/views/__tests__/MarketEvents.test.js src/views/__tests__/MarketInbox.test.js src/components/__tests__/ManualEventQuickAdd.test.js
```

Expected: selected tests pass.

- [ ] **Step 7: 提交**

Run:

```powershell
git add frontend/src/views/MarketEvents.vue frontend/src/views/__tests__/MarketEvents.test.js
git commit -m "feat: add market event operations panel"
```

---

### Task 6: 部署脚本、验证和真实数据检查

**Files:**
- Modify: `deploy-v3.2-mvp.ps1`

**Interfaces:**
- Consumes: Tasks 1-5
- Produces: deploy script validates v3.7 backend and frontend coverage.

- [ ] **Step 1: 更新部署脚本输出说明**

In `deploy-v3.2-mvp.ps1`, add this installed capability line after the v3.6 line:

```powershell
Write-Host "  v3.7 MarketEvents operations: enable/disable, BOM impact summary, review-source trace"
```

The `$frontendFiles` and `$testFiles` lists already contain the files modified in v3.7, so do not add duplicate entries.

- [ ] **Step 2: 运行后端全量测试**

Run:

```powershell
py -3.11 -m pytest tests -q
```

Expected: all backend tests pass.

- [ ] **Step 3: 运行前端相关测试**

Run:

```powershell
npm test -- --run src/views/__tests__/MarketEvents.test.js src/views/__tests__/MarketInbox.test.js src/components/__tests__/ManualEventQuickAdd.test.js
```

Working directory: `frontend`

Expected: selected tests pass.

- [ ] **Step 4: 部署到目标项目并验证**

Run:

```powershell
powershell -ExecutionPolicy Bypass -File "d:\1项目清单\交期风险排查\BOM-Risk-Analyzer-patch\deploy-v3.2-mvp.ps1" -TargetProject "D:\软件\workbuddy\WorkBuddy\BOM-Risk-Analyzer"
```

Expected output includes:

```text
Files copied
Syntax checks passed
Frontend related tests passed
Frontend build passed
```

- [ ] **Step 5: 真实数据库 API 验证**

Create a temporary script outside the repository, under `c:\Users\HAIER\.trae-cn\work\6a3a1656122fe7f887f6ea50\validate_v37_market_events.py`, that imports the target project app and verifies:

```python
import os
import sys
from pathlib import Path

project = Path(r"D:\软件\workbuddy\WorkBuddy\BOM-Risk-Analyzer")
os.chdir(project)
sys.path.insert(0, str(project / "backend"))

from app.database import init_db
from app.main import app
from fastapi.testclient import TestClient

init_db()
client = TestClient(app)

list_resp = client.get("/api/events/", params={"active_status": "all", "limit": 1})
print("list_status", list_resp.status_code)
print("list_total", list_resp.json().get("total"))

if list_resp.status_code == 200 and list_resp.json().get("events"):
    event = list_resp.json()["events"][0]
    event_id = event["id"]
    print("event_id", event_id)
    print("initial_is_active", event.get("is_active"))

    impact = client.get(f"/api/events/{event_id}/impact")
    print("impact_status", impact.status_code)
    print("impact_body", impact.json())

    source = client.get(f"/api/events/{event_id}/source-signal")
    print("source_status", source.status_code)
    print("source_has_signal", bool(source.json().get("signal")))

    disable = client.patch(f"/api/events/{event_id}/status", json={"action": "disable"})
    print("disable_status", disable.status_code)
    print("disable_is_active", disable.json().get("event", {}).get("is_active"))

    enable = client.patch(f"/api/events/{event_id}/status", json={"action": "enable"})
    print("enable_status", enable.status_code)
    print("enable_is_active", enable.json().get("event", {}).get("is_active"))
else:
    print("no_real_event")
```

Run:

```powershell
py -3.11 "c:\Users\HAIER\.trae-cn\work\6a3a1656122fe7f887f6ea50\validate_v37_market_events.py"
```

Expected:

```text
list_status 200
impact_status 200
source_status 200
```

If there is no real event, do not fabricate one in the target database; report that runtime UI validation needs one confirmed MarketEvent.

- [ ] **Step 6: 提交部署脚本**

Run:

```powershell
git add deploy-v3.2-mvp.ps1
git commit -m "chore: include market events operations in deploy output"
```

- [ ] **Step 7: 更新 bundle**

Run from patch repository root after the deploy-script commit so the bundle includes every v3.7 commit:

```powershell
git bundle create "..\BOM-Risk-Analyzer-v3.2-mvp.bundle" --all
git bundle verify "..\BOM-Risk-Analyzer-v3.2-mvp.bundle"
```

Expected:

```text
..\BOM-Risk-Analyzer-v3.2-mvp.bundle is okay
```

If bundle is not tracked by git, do not commit it; share the file link in the final response.

---

## Self-Review

### Spec coverage

- v3.7 事件状态操作：Task 1 and Task 5 cover backend and frontend.
- 停用事件后不参与后续风险匹配：Task 1 verifies active list behavior; existing risk scan reads active events and therefore respects `is_active`.
- 事件影响项目摘要：Task 2 backend and Task 5 frontend cover it.
- 行情收件箱来源追溯：Task 3 backend and Task 5 frontend cover it.
- 不新增数据库字段：Global Constraints enforce it; tasks reuse `is_active` and existing signal/BOM fields.
- 不进入 C/D：Global Constraints enforce it; no trend/supplier API tasks exist.
- 部署验证和真实数据检查：Task 6 covers it.

### Placeholder scan

No TBD, TODO, “implement later”, or unspecified “add tests” placeholders remain. Each task includes concrete files, code, commands, expected outcomes, and commit messages.

### Type consistency

Backend routes and frontend API names match:

- `PATCH /api/events/{event_id}/status` ↔ `updateEventStatus(eventId, payload)`
- `GET /api/events/{event_id}/impact` ↔ `getEventImpact(eventId)`
- `GET /api/events/{event_id}/source-signal` ↔ `getEventSourceSignal(eventId)`

Payload fields used by the frontend match backend response fields: `project_count`、`item_count`、`risk_counts`、`projects`、`signal`、`raw_notice`、`is_active`。
