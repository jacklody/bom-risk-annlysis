# v3.8 行情趋势视图与预测验证 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 基于现有市场事件、复核信号和 BOM 命中结果，新增只读趋势预警、预测验证和主动预警行动队列。

**Architecture:** 后端新增 `market_trends` API 模块，只读聚合 `MarketEvent`、`ExtractedMarketSignal`、`BomProject`、`BomItem`，不新增数据库字段，不接供应商 API。前端新增 `MarketTrends.vue` 页面和 API client，通过概览卡片、趋势分布、预测验证和行动队列呈现 C 项能力。

**Tech Stack:** FastAPI、SQLAlchemy、SQLite、pytest、Vue 3 `<script setup>`、Element Plus、Axios、Vitest、Vue Test Utils、PowerShell 部署脚本。

## Global Constraints

- 只实现 C 项：行情趋势视图、预测验证、主动预警行动队列。
- 不实现 D 项真实供应商 API，不新增外部 API client，不抓取供应商数据。
- 不新增数据库字段，不新增预测验证表，不修改 SQLite migration。
- 所有趋势、验证和动作接口只读，不修改 `MarketEvent`、`BomProject`、`BomItem`、`ExtractedMarketSignal`。
- 主动预警只生成建议动作，不自动停用事件，不自动重扫 BOM，不自动修改风险等级。
- 预测验证口径限定为“系统内预警是否在 BOM 风险结果中体现”，不判断外部市场事实真假。
- 前端空字段显示“暂无”；无趋势数据显示“暂无趋势数据”；无动作显示“暂无主动预警动作”。
- 新增后端 API、测试、前端页面、前端 API client 必须纳入 `deploy-v3.2-mvp.ps1`。
- 每个任务完成后运行对应测试并提交一次。

---

## File Structure

- Create: `backend/app/api/market_trends.py`
  - 提供 `/summary`、`/timeline`、`/validation`、`/actions` 四个只读接口。
  - 内部 helper 负责事件影响反查、复核来源判断、验证状态和行动建议生成。
- Modify: `backend/app/main.py`
  - 引入并挂载 `market_trends.router` 到 `/api/market-trends`。
- Create: `tests/test_market_trends_api.py`
  - 覆盖四个接口和只读约束。
- Create: `frontend/src/api/marketTrends.js`
  - 前端趋势 API client。
- Create: `frontend/src/views/MarketTrends.vue`
  - 新增趋势预警页面。
- Create: `frontend/src/views/__tests__/MarketTrends.test.js`
  - 覆盖页面加载、刷新、days 切换、空数据、跳转事件页。
- Modify: `frontend/src/router/index.js`
  - 新增 `/market-trends` 路由。
- Modify: `frontend/src/App.vue`
  - 侧边栏新增“趋势预警”。
- Modify: `deploy-v3.2-mvp.ps1`
  - 复制新增文件，编译新增后端 API，运行新增测试，输出 v3.8 能力说明。

---

### Task 1: 后端趋势 API 基础与 summary

**Files:**
- Create: `backend/app/api/market_trends.py`
- Modify: `backend/app/main.py`
- Test: `tests/test_market_trends_api.py`

**Interfaces:**
- Produces: `GET /api/market-trends/summary`
- Produces helper: `_csv_contains_id(csv_text: str | None, target_id: int) -> bool`
- Produces helper: `_event_impact(db: Session, event_id: int) -> dict`

- [ ] **Step 1: 写失败测试**

Create `tests/test_market_trends_api.py` with this initial content:

```python
from datetime import datetime, timedelta, timezone

from fastapi.testclient import TestClient

from app.database import SessionLocal, init_db
from app.main import app
from app.models.bom import BomItem, BomProject, RiskLevel
from app.models.event import EventType, MarketEvent, Severity

client = TestClient(app)


def _clean_trend_data():
    init_db()
    db = SessionLocal()
    db.query(BomItem).delete()
    db.query(BomProject).delete()
    db.query(MarketEvent).delete()
    db.commit()
    db.close()


def _seed_event(*, brand="TDK", category="high_cap_mlcc", severity=Severity.HIGH, confidence=0.85, days_ago=0, is_active=1):
    db = SessionLocal()
    try:
        event = MarketEvent(
            source_name="趋势测试来源",
            source_url="test://trend",
            raw_text=f"{brand} {category} 行情波动",
            raw_title=f"{brand} {category} 通知",
            brand=brand,
            category=category,
            event_type=EventType.PRICE_INCREASE,
            severity=severity,
            confidence=confidence,
            created_at=datetime.now(timezone.utc) - timedelta(days=days_ago),
            is_active=is_active,
        )
        db.add(event)
        db.commit()
        db.refresh(event)
        return event.id
    finally:
        db.close()


def _seed_project_with_items(event_id: int):
    db = SessionLocal()
    try:
        project = BomProject(
            filename="trend-demo.xlsx",
            project_name="趋势验证项目",
            total_items=2,
            items_analyzed=2,
            items_red=1,
            items_yellow=1,
            last_analysis_at=datetime.now(timezone.utc) - timedelta(days=3),
        )
        db.add(project)
        db.commit()
        db.refresh(project)
        db.add_all([
            BomItem(
                bom_upload_id=project.id,
                row_number=1,
                raw_part_number="C-RED",
                raw_brand="TDK",
                raw_category="high_cap_mlcc",
                normalized_brand="TDK",
                normalized_category="high_cap_mlcc",
                risk_level=RiskLevel.RED,
                risk_score=0.92,
                matched_event_ids=str(event_id),
            ),
            BomItem(
                bom_upload_id=project.id,
                row_number=2,
                raw_part_number="C-YELLOW",
                raw_brand="TDK",
                raw_category="high_cap_mlcc",
                normalized_brand="TDK",
                normalized_category="high_cap_mlcc",
                risk_level=RiskLevel.YELLOW,
                risk_score=0.68,
                matched_event_ids=str(event_id),
            ),
        ])
        db.commit()
        return project.id
    finally:
        db.close()


def test_trend_summary_counts_events_and_impacted_bom_items():
    _clean_trend_data()
    event_id = _seed_event(days_ago=2)
    _seed_project_with_items(event_id)
    _seed_event(brand="Murata", category="resistor", severity=Severity.LOW, days_ago=40)
    _seed_event(brand="Yageo", category="resistor", severity=Severity.HIGH, is_active=0)

    resp = client.get("/api/market-trends/summary")

    assert resp.status_code == 200
    data = resp.json()
    assert data["active_event_count"] == 2
    assert data["high_severity_event_count"] == 1
    assert data["new_events_7d"] == 1
    assert data["new_events_30d"] == 1
    assert data["affected_project_count"] == 1
    assert data["affected_item_count"] == 2
    assert data["red_item_count"] == 1
    assert data["yellow_item_count"] == 1
    assert data["action_count"] >= 1
    assert data["generated_at"]
```

- [ ] **Step 2: 运行失败测试**

Run:

```powershell
py -3.11 -m pytest tests\test_market_trends_api.py::test_trend_summary_counts_events_and_impacted_bom_items -q
```

Expected: FAIL because `/api/market-trends/summary` is not mounted.

- [ ] **Step 3: 实现 API 与挂载**

Create `backend/app/api/market_trends.py`:

```python
from collections import defaultdict
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Query
from sqlalchemy.orm import Session
from fastapi import Depends

from app.database import get_db
from app.models.bom import BomItem, BomProject
from app.models.event import ExtractedMarketSignal, MarketEvent, Severity

router = APIRouter()

PRIORITY_ORDER = {"high": 3, "medium": 2, "low": 1}


def _now():
    return datetime.now(timezone.utc)


def _as_aware(dt):
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def _csv_contains_id(csv_text: str | None, target_id: int) -> bool:
    if not csv_text:
        return False
    return str(target_id) in {part.strip() for part in csv_text.split(",") if part.strip()}


def _risk_value(item: BomItem) -> str:
    if not item.risk_level:
        return "gray"
    return item.risk_level.value if hasattr(item.risk_level, "value") else str(item.risk_level)


def _active_events(db: Session):
    return db.query(MarketEvent).filter(MarketEvent.is_active == 1).all()


def _event_impact(db: Session, event_id: int) -> dict:
    items = db.query(BomItem).filter(BomItem.matched_event_ids.isnot(None)).all()
    matched_items = [item for item in items if _csv_contains_id(item.matched_event_ids, event_id)]
    project_ids = sorted({item.bom_upload_id for item in matched_items})
    risk_counts = {"red": 0, "yellow": 0, "green": 0, "gray": 0}
    for item in matched_items:
        level = _risk_value(item)
        if level not in risk_counts:
            level = "gray"
        risk_counts[level] += 1
    return {
        "project_ids": project_ids,
        "project_count": len(project_ids),
        "item_count": len(matched_items),
        "risk_counts": risk_counts,
        "items": matched_items,
    }


def _has_review_source(db: Session, event_id: int) -> bool:
    return (
        db.query(ExtractedMarketSignal)
        .filter(ExtractedMarketSignal.market_event_id == event_id)
        .first()
        is not None
    )


def _is_high_severity(event: MarketEvent) -> bool:
    return event.severity in {Severity.CRITICAL, Severity.HIGH}


def _build_actions(db: Session, events: list[MarketEvent] | None = None) -> list[dict]:
    events = events if events is not None else _active_events(db)
    actions: list[dict] = []
    grouped: dict[tuple[str, str], list[MarketEvent]] = defaultdict(list)
    now = _now()

    for event in events:
        impact = _event_impact(db, event.id)
        has_review = _has_review_source(db, event.id)
        brand = event.brand or "暂无"
        category = event.category or "暂无"
        grouped[(brand, category)].append(event)

        if _is_high_severity(event) and (not has_review or (event.confidence or 0) < 0.75):
            actions.append({
                "id": f"review_event:{event.id}",
                "action_type": "review_event",
                "priority": "high",
                "title": "建议复核高风险事件",
                "reason": "事件严重度较高，但复核来源不足或置信度偏低。",
                "brand": event.brand,
                "category": event.category,
                "event_ids": [event.id],
                "project_count": impact["project_count"],
                "item_count": impact["item_count"],
                "target_route": "/events",
            })

        if impact["item_count"] > 0:
            actions.append({
                "id": f"validate_prediction:{event.id}",
                "action_type": "validate_prediction",
                "priority": "medium",
                "title": "建议验证预测命中",
                "reason": "事件已经命中 BOM 物料，需要确认命中物料和风险等级是否符合业务判断。",
                "brand": event.brand,
                "category": event.category,
                "event_ids": [event.id],
                "project_count": impact["project_count"],
                "item_count": impact["item_count"],
                "target_route": "/events",
            })

        if (event.confidence or 0) < 0.75 and not has_review and impact["item_count"] == 0:
            actions.append({
                "id": f"consider_disable_event:{event.id}",
                "action_type": "consider_disable_event",
                "priority": "low",
                "title": "建议人工判断是否停用事件",
                "reason": "事件置信度偏低、无复核来源，且暂未命中任何 BOM 物料。",
                "brand": event.brand,
                "category": event.category,
                "event_ids": [event.id],
                "project_count": 0,
                "item_count": 0,
                "target_route": "/events",
            })

        if _is_high_severity(event):
            projects = db.query(BomProject).all()
            event_created_at = _as_aware(event.created_at)
            stale_projects = []
            for project in projects:
                last_analysis_at = _as_aware(project.last_analysis_at)
                if last_analysis_at is None or (event_created_at and last_analysis_at < event_created_at):
                    stale_projects.append(project.id)
            if stale_projects:
                actions.append({
                    "id": f"rescan_bom:{event.id}",
                    "action_type": "rescan_bom",
                    "priority": "high",
                    "title": "建议重扫历史 BOM",
                    "reason": "存在高风险事件晚于项目最后分析时间，历史 BOM 可能需要重新评估。",
                    "brand": event.brand,
                    "category": event.category,
                    "event_ids": [event.id],
                    "project_count": len(stale_projects),
                    "item_count": impact["item_count"],
                    "target_route": "/events",
                })

    for (brand, category), grouped_events in grouped.items():
        recent_events = [event for event in grouped_events if _as_aware(event.created_at) and _as_aware(event.created_at) >= now - timedelta(days=30)]
        if len(recent_events) >= 2:
            item_count = sum(_event_impact(db, event.id)["item_count"] for event in recent_events)
            project_ids = set()
            for event in recent_events:
                project_ids.update(_event_impact(db, event.id)["project_ids"])
            actions.append({
                "id": f"watch_category:{brand}:{category}",
                "action_type": "watch_category",
                "priority": "medium",
                "title": "建议关注品牌品类趋势",
                "reason": "同一品牌和品类近 30 天出现多条活跃行情事件。",
                "brand": None if brand == "暂无" else brand,
                "category": None if category == "暂无" else category,
                "event_ids": [event.id for event in recent_events],
                "project_count": len(project_ids),
                "item_count": item_count,
                "target_route": "/events",
            })

    actions.sort(key=lambda item: (-PRIORITY_ORDER.get(item["priority"], 0), -item["item_count"], item["id"]))
    return actions


@router.get("/summary")
def get_trend_summary(db: Session = Depends(get_db)):
    events = _active_events(db)
    now = _now()
    event_impacts = [_event_impact(db, event.id) for event in events]
    affected_project_ids = set()
    affected_item_count = 0
    red_item_count = 0
    yellow_item_count = 0
    for impact in event_impacts:
        affected_project_ids.update(impact["project_ids"])
        affected_item_count += impact["item_count"]
        red_item_count += impact["risk_counts"]["red"]
        yellow_item_count += impact["risk_counts"]["yellow"]

    return {
        "active_event_count": len(events),
        "high_severity_event_count": sum(1 for event in events if _is_high_severity(event)),
        "new_events_7d": sum(1 for event in events if _as_aware(event.created_at) and _as_aware(event.created_at) >= now - timedelta(days=7)),
        "new_events_30d": sum(1 for event in events if _as_aware(event.created_at) and _as_aware(event.created_at) >= now - timedelta(days=30)),
        "affected_project_count": len(affected_project_ids),
        "affected_item_count": affected_item_count,
        "red_item_count": red_item_count,
        "yellow_item_count": yellow_item_count,
        "action_count": len(_build_actions(db, events)),
        "generated_at": now.isoformat(),
    }
```

Modify `backend/app/main.py`:

```python
from app.api import events, bom_upload, risk_analysis, bom_project, intel_watch, market_inbox, preferred_library, market_trends
```

Add after preferred library include:

```python
app.include_router(market_trends.router, prefix="/api/market-trends", tags=["market-trends"])
```

- [ ] **Step 4: 运行测试并提交**

Run:

```powershell
py -3.11 -m pytest tests\test_market_trends_api.py::test_trend_summary_counts_events_and_impacted_bom_items -q
```

Expected: PASS.

Commit:

```powershell
git add backend/app/api/market_trends.py backend/app/main.py tests/test_market_trends_api.py
git commit -m "feat: add market trend summary api"
```

---

### Task 2: 后端 timeline、validation 与 actions

**Files:**
- Modify: `backend/app/api/market_trends.py`
- Modify: `tests/test_market_trends_api.py`

**Interfaces:**
- Produces: `GET /api/market-trends/timeline?days=7|30|90`
- Produces: `GET /api/market-trends/validation`
- Produces: `GET /api/market-trends/actions`

- [ ] **Step 1: 追加失败测试**

Append to `tests/test_market_trends_api.py`:

```python
def test_trend_timeline_groups_by_date_brand_category_and_severity():
    _clean_trend_data()
    first_id = _seed_event(brand="TDK", category="high_cap_mlcc", severity=Severity.HIGH, days_ago=1)
    second_id = _seed_event(brand="TDK", category="high_cap_mlcc", severity=Severity.MEDIUM, days_ago=2)
    _seed_project_with_items(first_id)
    _seed_project_with_items(second_id)

    resp = client.get("/api/market-trends/timeline", params={"days": 30})

    assert resp.status_code == 200
    data = resp.json()
    assert data["days"] == 30
    assert data["brand_rank"][0]["brand"] == "TDK"
    assert data["brand_rank"][0]["event_count"] == 2
    assert data["category_rank"][0]["category"] == "high_cap_mlcc"
    assert data["severity_counts"]["high"] == 1
    assert data["severity_counts"]["medium"] == 1
    assert sum(day["event_count"] for day in data["daily_events"]) == 2


def test_trend_validation_classifies_hit_not_hit_and_needs_review():
    _clean_trend_data()
    hit_id = _seed_event(brand="TDK", category="high_cap_mlcc", severity=Severity.MEDIUM, confidence=0.9)
    _seed_project_with_items(hit_id)
    _seed_event(brand="Murata", category="resistor", severity=Severity.LOW, confidence=0.9)
    _seed_event(brand="Yageo", category="resistor", severity=Severity.HIGH, confidence=0.6)

    resp = client.get("/api/market-trends/validation")

    assert resp.status_code == 200
    data = resp.json()
    assert data["risk_hit_count"] == 1
    assert data["not_hit_yet_count"] == 1
    assert data["needs_review_count"] == 1
    assert data["hit_rate"] == 1 / 3
    statuses = {event["validation_status"] for event in data["events"]}
    assert "risk_hit" in statuses
    assert "not_hit_yet" in statuses
    assert "needs_review" in statuses


def test_trend_actions_generate_active_warning_queue_without_writes():
    _clean_trend_data()
    hit_id = _seed_event(brand="TDK", category="high_cap_mlcc", severity=Severity.HIGH, confidence=0.7)
    _seed_event(brand="TDK", category="high_cap_mlcc", severity=Severity.MEDIUM, confidence=0.9)
    low_id = _seed_event(brand="Unknown", category="connector", severity=Severity.LOW, confidence=0.5)
    _seed_project_with_items(hit_id)

    before_events = client.get("/api/events/", params={"active_status": "all"}).json()["total"]
    resp = client.get("/api/market-trends/actions")
    after_events = client.get("/api/events/", params={"active_status": "all"}).json()["total"]

    assert resp.status_code == 200
    actions = resp.json()["actions"]
    action_types = {action["action_type"] for action in actions}
    assert "review_event" in action_types
    assert "rescan_bom" in action_types
    assert "watch_category" in action_types
    assert "validate_prediction" in action_types
    assert "consider_disable_event" in action_types
    assert before_events == after_events
    assert any(action["event_ids"] == [low_id] for action in actions if action["action_type"] == "consider_disable_event")
```

- [ ] **Step 2: 运行失败测试**

Run:

```powershell
py -3.11 -m pytest tests\test_market_trends_api.py -q
```

Expected: new tests FAIL because endpoints are missing.

- [ ] **Step 3: 实现三个接口**

Append to `backend/app/api/market_trends.py` after `get_trend_summary`:

```python

def _severity_value(event: MarketEvent) -> str:
    return event.severity.value if event.severity else "unknown"


def _validation_status(db: Session, event: MarketEvent, impact: dict) -> str:
    has_review = _has_review_source(db, event.id)
    has_red_or_yellow = impact["risk_counts"]["red"] > 0 or impact["risk_counts"]["yellow"] > 0
    if _is_high_severity(event) and ((event.confidence or 0) < 0.75 or not has_review):
        return "needs_review"
    if impact["item_count"] > 0 and has_red_or_yellow:
        return "risk_hit"
    return "not_hit_yet"


@router.get("/timeline")
def get_trend_timeline(days: int = Query(30), db: Session = Depends(get_db)):
    if days not in {7, 30, 90}:
        days = 30
    now = _now()
    since = now - timedelta(days=days)
    events = [event for event in _active_events(db) if _as_aware(event.created_at) and _as_aware(event.created_at) >= since]

    daily = defaultdict(lambda: {"event_count": 0, "high_severity_event_count": 0})
    brand_map = defaultdict(lambda: {"brand": "暂无", "event_count": 0, "project_ids": set(), "item_count": 0})
    category_map = defaultdict(lambda: {"category": "暂无", "event_count": 0, "project_ids": set(), "item_count": 0})
    severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "unknown": 0}

    for event in events:
        day_key = _as_aware(event.created_at).date().isoformat()
        daily[day_key]["event_count"] += 1
        if _is_high_severity(event):
            daily[day_key]["high_severity_event_count"] += 1
        severity = _severity_value(event)
        if severity not in severity_counts:
            severity = "unknown"
        severity_counts[severity] += 1

        impact = _event_impact(db, event.id)
        brand = event.brand or "暂无"
        category = event.category or "暂无"
        brand_map[brand]["brand"] = brand
        brand_map[brand]["event_count"] += 1
        brand_map[brand]["project_ids"].update(impact["project_ids"])
        brand_map[brand]["item_count"] += impact["item_count"]
        category_map[category]["category"] = category
        category_map[category]["event_count"] += 1
        category_map[category]["project_ids"].update(impact["project_ids"])
        category_map[category]["item_count"] += impact["item_count"]

    def rank_rows(rows, name_key):
        payload = []
        for row in rows.values():
            payload.append({
                name_key: row[name_key],
                "event_count": row["event_count"],
                "project_count": len(row["project_ids"]),
                "item_count": row["item_count"],
            })
        return sorted(payload, key=lambda item: (-item["item_count"], -item["event_count"], item[name_key]))

    return {
        "days": days,
        "daily_events": [
            {"date": day, **daily[day]}
            for day in sorted(daily.keys())
        ],
        "brand_rank": rank_rows(brand_map, "brand"),
        "category_rank": rank_rows(category_map, "category"),
        "severity_counts": severity_counts,
    }


@router.get("/validation")
def get_trend_validation(db: Session = Depends(get_db)):
    events = _active_events(db)
    result_events = []
    counts = {"risk_hit": 0, "not_hit_yet": 0, "needs_review": 0}
    for event in events:
        impact = _event_impact(db, event.id)
        status = _validation_status(db, event, impact)
        counts[status] += 1
        result_events.append({
            "event_id": event.id,
            "brand": event.brand,
            "category": event.category,
            "severity": _severity_value(event),
            "confidence": event.confidence,
            "validation_status": status,
            "project_count": impact["project_count"],
            "item_count": impact["item_count"],
        })
    active_count = len(events)
    return {
        "risk_hit_count": counts["risk_hit"],
        "not_hit_yet_count": counts["not_hit_yet"],
        "needs_review_count": counts["needs_review"],
        "hit_rate": counts["risk_hit"] / active_count if active_count else 0,
        "review_needed_rate": counts["needs_review"] / active_count if active_count else 0,
        "events": result_events,
    }


@router.get("/actions")
def get_trend_actions(db: Session = Depends(get_db)):
    return {"actions": _build_actions(db)}
```

- [ ] **Step 4: 运行后端测试并提交**

Run:

```powershell
py -3.11 -m pytest tests\test_market_trends_api.py tests\test_market_events_api.py -q
```

Expected: PASS.

Commit:

```powershell
git add backend/app/api/market_trends.py tests/test_market_trends_api.py
git commit -m "feat: add trend validation and action queue api"
```

---

### Task 3: 前端 API client 与路由入口

**Files:**
- Create: `frontend/src/api/marketTrends.js`
- Modify: `frontend/src/router/index.js`
- Modify: `frontend/src/App.vue`
- Test: existing frontend route build through component tests in Task 4

**Interfaces:**
- Produces: `getTrendSummary()`
- Produces: `getTrendTimeline(params)`
- Produces: `getTrendValidation()`
- Produces: `getTrendActions()`
- Produces route: `/market-trends`

- [ ] **Step 1: 新增 API client**

Create `frontend/src/api/marketTrends.js`:

```javascript
import client from './client'

export function getTrendSummary() {
  return client.get('/market-trends/summary')
}

export function getTrendTimeline(params = {}) {
  return client.get('/market-trends/timeline', { params })
}

export function getTrendValidation() {
  return client.get('/market-trends/validation')
}

export function getTrendActions() {
  return client.get('/market-trends/actions')
}
```

- [ ] **Step 2: 新增路由和菜单**

Modify `frontend/src/router/index.js`, add after `/events`:

```javascript
  {
    path: '/market-trends',
    name: 'market-trends',
    component: () => import('../views/MarketTrends.vue')
  },
```

Modify `frontend/src/App.vue`, add after 市场事件 menu item:

```vue
        <el-menu-item index="/market-trends">
          <el-icon><DataAnalysis /></el-icon>
          <span>趋势预警</span>
        </el-menu-item>
```

- [ ] **Step 3: 创建临时最小页面避免路由导入失败**

Create `frontend/src/views/MarketTrends.vue`:

```vue
<template>
  <div class="market-trends-page">
    <h2>趋势预警</h2>
    <p>暂无趋势数据</p>
  </div>
</template>
```

- [ ] **Step 4: 运行前端测试并提交**

Run:

```powershell
cd frontend
npm test -- --run src/views/__tests__/MarketEvents.test.js
```

Expected: PASS.

Commit:

```powershell
git add frontend/src/api/marketTrends.js frontend/src/router/index.js frontend/src/App.vue frontend/src/views/MarketTrends.vue
git commit -m "feat: add market trends frontend entry"
```

---

### Task 4: 前端 MarketTrends 页面

**Files:**
- Modify: `frontend/src/views/MarketTrends.vue`
- Create: `frontend/src/views/__tests__/MarketTrends.test.js`

**Interfaces:**
- Consumes: `getTrendSummary()`
- Consumes: `getTrendTimeline({ days })`
- Consumes: `getTrendValidation()`
- Consumes: `getTrendActions()`

- [ ] **Step 1: 写失败测试**

Create `frontend/src/views/__tests__/MarketTrends.test.js`:

```javascript
import { mount, flushPromises } from '@vue/test-utils'
import { describe, it, expect, vi, beforeEach } from 'vitest'
import MarketTrends from '../MarketTrends.vue'
import * as api from '../../api/marketTrends'

vi.mock('../../api/marketTrends', () => ({
  getTrendSummary: vi.fn(),
  getTrendTimeline: vi.fn(),
  getTrendValidation: vi.fn(),
  getTrendActions: vi.fn()
}))

const push = vi.fn()
vi.mock('vue-router', () => ({
  useRouter: () => ({ push })
}))

const stubs = {
  'el-card': { template: '<div class="el-card"><slot /></div>' },
  'el-button': { template: '<button v-bind="$attrs" @click="$emit(\'click\')"><slot /></button>' },
  'el-select': { template: '<select v-bind="$attrs" @change="$emit(\'change\', Number($event.target.value))"><slot /></select>' },
  'el-option': { props: ['label', 'value'], template: '<option :value="value">{{ label }}</option>' },
  'el-table': { props: ['data'], template: '<div><slot /><div v-for="row in data" :key="row.id || row.action_type"><slot name="default" :row="row" /></div></div>' },
  'el-table-column': { props: ['prop', 'label'], template: '<div><slot :row="$parent?.row" /></div>' },
  'el-tag': { template: '<span><slot /></span>' },
  'el-empty': { props: ['description'], template: '<div>{{ description }}</div>' }
}

function mockData({ empty = false } = {}) {
  api.getTrendSummary.mockResolvedValue({ data: empty ? {
    active_event_count: 0, high_severity_event_count: 0, new_events_7d: 0, new_events_30d: 0,
    affected_project_count: 0, affected_item_count: 0, red_item_count: 0, yellow_item_count: 0,
    action_count: 0, generated_at: '2026-06-27T00:00:00+00:00'
  } : {
    active_event_count: 3, high_severity_event_count: 1, new_events_7d: 2, new_events_30d: 3,
    affected_project_count: 1, affected_item_count: 2, red_item_count: 1, yellow_item_count: 1,
    action_count: 2, generated_at: '2026-06-27T00:00:00+00:00'
  } })
  api.getTrendTimeline.mockResolvedValue({ data: empty ? {
    days: 30, daily_events: [], brand_rank: [], category_rank: [], severity_counts: {}
  } : {
    days: 30,
    daily_events: [{ date: '2026-06-27', event_count: 2, high_severity_event_count: 1 }],
    brand_rank: [{ brand: 'TDK', event_count: 2, project_count: 1, item_count: 2 }],
    category_rank: [{ category: 'high_cap_mlcc', event_count: 2, project_count: 1, item_count: 2 }],
    severity_counts: { high: 1, medium: 1 }
  } })
  api.getTrendValidation.mockResolvedValue({ data: empty ? {
    risk_hit_count: 0, not_hit_yet_count: 0, needs_review_count: 0, hit_rate: 0, review_needed_rate: 0, events: []
  } : {
    risk_hit_count: 1, not_hit_yet_count: 1, needs_review_count: 1, hit_rate: 0.33, review_needed_rate: 0.33, events: []
  } })
  api.getTrendActions.mockResolvedValue({ data: empty ? { actions: [] } : { actions: [
    { id: 'review_event:1', action_type: 'review_event', priority: 'high', title: '建议复核高风险事件', reason: '事件严重度较高', brand: 'TDK', category: 'high_cap_mlcc', event_ids: [1], project_count: 1, item_count: 2, target_route: '/events' }
  ] } })
}

function mountPage() {
  return mount(MarketTrends, { global: { stubs } })
}

describe('MarketTrends', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    push.mockReset()
  })

  it('loads summary timeline validation and action queue', async () => {
    mockData()
    const wrapper = mountPage()
    await flushPromises()
    expect(api.getTrendSummary).toHaveBeenCalled()
    expect(api.getTrendTimeline).toHaveBeenCalledWith({ days: 30 })
    expect(api.getTrendValidation).toHaveBeenCalled()
    expect(api.getTrendActions).toHaveBeenCalled()
    expect(wrapper.text()).toContain('趋势预警')
    expect(wrapper.text()).toContain('活跃事件')
    expect(wrapper.text()).toContain('TDK')
    expect(wrapper.text()).toContain('预测验证')
    expect(wrapper.text()).toContain('建议复核高风险事件')
  })

  it('refreshes all data when clicking refresh', async () => {
    mockData()
    const wrapper = mountPage()
    await flushPromises()
    await wrapper.find('[data-testid="trends-refresh"]').trigger('click')
    await flushPromises()
    expect(api.getTrendSummary).toHaveBeenCalledTimes(2)
    expect(api.getTrendActions).toHaveBeenCalledTimes(2)
  })

  it('reloads timeline when days changes', async () => {
    mockData()
    const wrapper = mountPage()
    await flushPromises()
    await wrapper.find('[data-testid="trends-days"]').setValue('7')
    await flushPromises()
    expect(api.getTrendTimeline).toHaveBeenLastCalledWith({ days: 7 })
  })

  it('shows empty state for no trends and no actions', async () => {
    mockData({ empty: true })
    const wrapper = mountPage()
    await flushPromises()
    expect(wrapper.text()).toContain('暂无趋势数据')
    expect(wrapper.text()).toContain('暂无主动预警动作')
  })

  it('jumps to events page from action queue', async () => {
    mockData()
    const wrapper = mountPage()
    await flushPromises()
    await wrapper.find('[data-testid="action-open-events"]').trigger('click')
    expect(push).toHaveBeenCalledWith('/events')
  })
})
```

- [ ] **Step 2: 运行失败测试**

Run:

```powershell
cd frontend
npm test -- --run src/views/__tests__/MarketTrends.test.js
```

Expected: FAIL because page is still placeholder.

- [ ] **Step 3: 实现页面**

Replace `frontend/src/views/MarketTrends.vue` with a Vue page containing:

```vue
<template>
  <div class="market-trends-page">
    <header class="page-header">
      <div>
        <h2>趋势预警</h2>
        <p>基于现有市场事件、复核信号和 BOM 命中结果生成只读趋势判断。</p>
      </div>
      <el-button data-testid="trends-refresh" :loading="loading" type="primary" @click="loadAll">刷新</el-button>
    </header>

    <section class="summary-grid">
      <el-card v-for="card in summaryCards" :key="card.label" class="summary-card">
        <span>{{ card.label }}</span>
        <strong>{{ card.value }}</strong>
      </el-card>
    </section>

    <el-card class="section-card">
      <div class="section-header">
        <h3>趋势分布</h3>
        <el-select v-model="days" data-testid="trends-days" @change="loadTimeline">
          <el-option label="近 7 天" :value="7" />
          <el-option label="近 30 天" :value="30" />
          <el-option label="近 90 天" :value="90" />
        </el-select>
      </div>
      <p v-if="!hasTrendData">暂无趋势数据</p>
      <div v-else class="trend-columns">
        <div>
          <h4>品牌排行</h4>
          <div v-for="row in timeline.brand_rank" :key="row.brand" class="rank-row">
            <strong>{{ displayValue(row.brand) }}</strong>
            <span>事件 {{ row.event_count }} / 物料 {{ row.item_count }}</span>
          </div>
        </div>
        <div>
          <h4>品类排行</h4>
          <div v-for="row in timeline.category_rank" :key="row.category" class="rank-row">
            <strong>{{ displayValue(row.category) }}</strong>
            <span>事件 {{ row.event_count }} / 物料 {{ row.item_count }}</span>
          </div>
        </div>
        <div>
          <h4>每日事件</h4>
          <div v-for="row in timeline.daily_events" :key="row.date" class="rank-row">
            <strong>{{ row.date }}</strong>
            <span>事件 {{ row.event_count }} / 高风险 {{ row.high_severity_event_count }}</span>
          </div>
        </div>
      </div>
    </el-card>

    <el-card class="section-card">
      <h3>预测验证</h3>
      <div class="validation-grid">
        <p><span>已命中风险：</span>{{ validation.risk_hit_count ?? 0 }}</p>
        <p><span>暂未命中：</span>{{ validation.not_hit_yet_count ?? 0 }}</p>
        <p><span>待复核：</span>{{ validation.needs_review_count ?? 0 }}</p>
        <p><span>命中率：</span>{{ percent(validation.hit_rate) }}</p>
      </div>
    </el-card>

    <el-card class="section-card">
      <h3>主动预警行动队列</h3>
      <p v-if="!actions.length">暂无主动预警动作</p>
      <div v-else class="action-list">
        <article v-for="action in actions" :key="action.id" class="action-card">
          <div>
            <el-tag>{{ priorityText(action.priority) }}</el-tag>
            <strong>{{ action.title }}</strong>
          </div>
          <p>{{ action.reason }}</p>
          <p>品牌：{{ displayValue(action.brand) }} / 品类：{{ displayValue(action.category) }}</p>
          <p>影响项目：{{ action.project_count }} / 影响物料：{{ action.item_count }}</p>
          <el-button size="small" data-testid="action-open-events" @click="openEvents(action)">查看事件</el-button>
        </article>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { getTrendActions, getTrendSummary, getTrendTimeline, getTrendValidation } from '../api/marketTrends'

const router = useRouter()
const loading = ref(false)
const days = ref(30)
const summary = ref({})
const timeline = ref({ daily_events: [], brand_rank: [], category_rank: [], severity_counts: {} })
const validation = ref({})
const actions = ref([])

const summaryCards = computed(() => [
  { label: '活跃事件', value: summary.value.active_event_count ?? 0 },
  { label: '高风险事件', value: summary.value.high_severity_event_count ?? 0 },
  { label: '近 7 天新增', value: summary.value.new_events_7d ?? 0 },
  { label: '受影响项目', value: summary.value.affected_project_count ?? 0 },
  { label: '受影响物料', value: summary.value.affected_item_count ?? 0 },
  { label: '主动预警动作', value: summary.value.action_count ?? 0 }
])

const hasTrendData = computed(() => {
  return Boolean(
    timeline.value.daily_events?.length ||
    timeline.value.brand_rank?.length ||
    timeline.value.category_rank?.length
  )
})

function displayValue(value) {
  return value === null || value === undefined || value === '' ? '暂无' : value
}

function percent(value) {
  if (value === null || value === undefined) return '0%'
  return `${Math.round(Number(value) * 100)}%`
}

function priorityText(priority) {
  return { high: '高', medium: '中', low: '低' }[priority] || displayValue(priority)
}

async function loadTimeline() {
  try {
    const { data } = await getTrendTimeline({ days: Number(days.value) })
    timeline.value = data
  } catch (error) {
    ElMessage.error(error?.response?.data?.detail || '趋势分布加载失败')
  }
}

async function loadAll() {
  loading.value = true
  try {
    const [{ data: summaryData }, { data: timelineData }, { data: validationData }, { data: actionsData }] = await Promise.all([
      getTrendSummary(),
      getTrendTimeline({ days: Number(days.value) }),
      getTrendValidation(),
      getTrendActions()
    ])
    summary.value = summaryData
    timeline.value = timelineData
    validation.value = validationData
    actions.value = actionsData.actions || []
  } catch (error) {
    ElMessage.error(error?.response?.data?.detail || '趋势预警加载失败')
  } finally {
    loading.value = false
  }
}

function openEvents() {
  router.push('/events')
}

onMounted(loadAll)
</script>

<style scoped>
.market-trends-page { display: flex; flex-direction: column; gap: 16px; }
.page-header, .section-header { display: flex; justify-content: space-between; align-items: center; gap: 16px; }
.page-header p { color: #606266; margin-top: 6px; }
.summary-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; }
.summary-card span { color: #606266; font-size: 13px; }
.summary-card strong { display: block; margin-top: 8px; font-size: 24px; color: #303133; }
.section-card { width: 100%; }
.trend-columns { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
.rank-row, .action-card { border: 1px solid #ebeef5; border-radius: 8px; padding: 10px; margin-top: 8px; background: #fff; }
.rank-row { display: flex; justify-content: space-between; gap: 12px; }
.validation-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 10px; }
.action-list { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 12px; }
.action-card div { display: flex; align-items: center; gap: 8px; }
.action-card p { margin-top: 8px; color: #606266; }
</style>
```

- [ ] **Step 4: 运行测试并提交**

Run:

```powershell
cd frontend
npm test -- --run src/views/__tests__/MarketTrends.test.js src/views/__tests__/MarketEvents.test.js src/views/__tests__/MarketInbox.test.js src/components/__tests__/ManualEventQuickAdd.test.js
```

Expected: PASS.

Commit:

```powershell
git add frontend/src/views/MarketTrends.vue frontend/src/views/__tests__/MarketTrends.test.js
git commit -m "feat: add market trends page"
```

---

### Task 5: 部署脚本、目标项目验证和 bundle

**Files:**
- Modify: `deploy-v3.2-mvp.ps1`

**Interfaces:**
- Deployment copies all v3.8 backend/frontend/test files.
- Deployment runs backend and frontend v3.8 tests.

- [ ] **Step 1: 更新部署脚本**

Modify `deploy-v3.2-mvp.ps1`:

1. Add API copy after `market_inbox.py`:

```powershell
    Copy-Item (Join-Path $SRC "backend\app\api\market_trends.py") $targetApi -Force
```

2. Add compile file after `app\api\market_inbox.py`:

```powershell
        "app\api\market_trends.py",
```

3. Add frontend files:

```powershell
            "src\views\MarketTrends.vue",
            "src\views\__tests__\MarketTrends.test.js",
            "src\api\marketTrends.js",
```

4. Add test file:

```powershell
        "test_market_trends_api.py",
```

5. Add backend pytest command `tests\test_market_trends_api.py` to both py -3.11 and python branches.

6. Add frontend test command argument:

```powershell
src/views/__tests__/MarketTrends.test.js
```

7. Add final capability line:

```powershell
Write-Host "  v3.8 MarketTrends: trend summary, prediction validation, active warning action queue"
```

- [ ] **Step 2: 运行全量测试**

Run from patch repository root:

```powershell
py -3.11 -m pytest tests -q
```

Expected: PASS.

Run from `frontend`:

```powershell
npm test -- --run src/views/__tests__/MarketTrends.test.js src/views/__tests__/MarketEvents.test.js src/views/__tests__/MarketInbox.test.js src/components/__tests__/ManualEventQuickAdd.test.js
```

Expected: PASS.

- [ ] **Step 3: 部署到目标项目并验证**

Run:

```powershell
powershell -ExecutionPolicy Bypass -File 'd:\1项目清单\交期风险排查\BOM-Risk-Analyzer-patch\deploy-v3.2-mvp.ps1' -TargetProject 'D:\软件\workbuddy\WorkBuddy\BOM-Risk-Analyzer'
```

Expected:

```text
Files copied
v3.2 MVP tests passed
Frontend related tests passed
Frontend build passed
v3.8 MarketTrends: trend summary, prediction validation, active warning action queue
```

- [ ] **Step 4: 真实数据验证**

Create temporary script in `c:\Users\HAIER\.trae-cn\work\6a3a1656122fe7f887f6ea50\validate_v38_market_trends.py` with TestClient against target project. Script must print:

```text
summary_status <code>
timeline_status <code>
validation_status <code>
actions_status <code>
active_event_count <number>
hit_rate <number>
action_count <number>
```

Run from target project root using `py -3.11` and verify all statuses are 200. Do not save this script in the user workspace.

- [ ] **Step 5: 提交部署脚本**

Run:

```powershell
git add deploy-v3.2-mvp.ps1
git commit -m "chore: deploy market trends validation v38"
```

- [ ] **Step 6: 更新 bundle**

Run after the deploy-script commit:

```powershell
git bundle create "..\BOM-Risk-Analyzer-v3.2-mvp.bundle" --all
git bundle verify "..\BOM-Risk-Analyzer-v3.2-mvp.bundle"
```

Expected:

```text
..\BOM-Risk-Analyzer-v3.2-mvp.bundle is okay
```

---

## Self-Review

Spec coverage:

- summary, timeline, validation, actions covered by Tasks 1 and 2.
- frontend API, route, menu, page covered by Tasks 3 and 4.
- tests, deployment, target validation and bundle covered by Task 5.
- global constraints explicitly prevent D supplier API, DB field changes and automatic writes.

Placeholder scan:

- No TBD/TODO/fill-in placeholders.
- Every task has concrete files, code snippets, commands and expected results.

Type consistency:

- API routes use `/api/market-trends/*`; frontend client uses `/market-trends/*` because `client.js` base URL is `/api`.
- Action strings match spec: `review_event`, `rescan_bom`, `watch_category`, `validate_prediction`, `consider_disable_event`.
- Priority strings match spec: `high`, `medium`, `low`.
