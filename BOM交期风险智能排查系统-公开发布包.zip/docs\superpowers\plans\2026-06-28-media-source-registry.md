# 行业媒体源注册表 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将芯师爷、半导体行业观察、国际电子商情、满天芯、EEWorld、芯智讯、立创商城公众号/接口纳入正式媒体源规划，并改造成注册表驱动的行情采集体系。

**Architecture:** 新增媒体源注册表作为单一事实来源，`IndustryMediaCrawler` 从注册表读取源并按策略分发采集；`events.py` 暴露媒体源状态与单源/全量采集入口。微信公众号类源不伪造成稳定 HTTP 爬虫，先以 `manual_forward`、`wechat_feed`、`playwright_required` 等策略登记，并按可信度降权进入行情事件链路。

**Tech Stack:** Python 3.11、FastAPI、SQLAlchemy、httpx、BeautifulSoup、现有 `MarketEvent` / `parse_market_notice` / `EventCollector`。

## Global Constraints

- 用户列出的 7 个渠道必须全部登记：芯师爷、半导体行业观察、国际电子商情、满天芯、EEWorld、芯智讯、立创商城公众号/接口。
- 微信公众号无公开 API，不能把公众号源伪造成稳定直接抓取；必须明确接入方式和待配置状态。
- 公众号/媒体/传闻类来源必须保留可信度降权，不允许单一公众号直接触发强红色风险。
- 当前已验证可用的 LCSC/JLCSearch API 能力必须保留。
- 不引入重量级新依赖；第一阶段继续使用 httpx + BeautifulSoup。
- 所有新增接口返回结构化 JSON，便于前端后续展示媒体源状态。

---

## File Structure

- Create: `backend/app/knowledge/media_sources.py`
  - 负责定义媒体源数据结构、策略枚举、7 个渠道注册信息、按源 ID 查询函数。
- Modify: `backend/app/services/media_crawler.py`
  - 从 `MEDIA_SOURCES` 读取 enabled 源；按 `crawler_strategy` 执行 `api_json`、`http_html`、`keyword_search`、`manual_forward`、`wechat_feed`、`playwright_required`。
- Modify: `backend/app/api/events.py`
  - 增加 `GET /api/events/media-sources`；扩展 `POST /api/events/collect-media` 支持可选 `source_id`。
- Modify: `backend/app/services/event_collector.py`
  - 调整调用方式以支持全量或单源采集；保留 LCSC 热词趋势。
- Optional Test: 若项目已有 pytest 环境可用，新增 `backend/tests/test_media_sources.py`；若本机后端测试环境不可用，使用 Python 导入检查 + FastAPI API 手工验证。

---

### Task 1: 新增媒体源注册表

**Files:**
- Create: `d:\1项目清单\交期风险排查\BOM-Risk-Analyzer-patch\backend\app\knowledge\media_sources.py`

**Interfaces:**
- Produces: `MEDIA_SOURCES: list[MediaSource]`
- Produces: `get_media_source(source_id: str) -> MediaSource | None`
- Produces: `list_media_sources(enabled_only: bool = False) -> list[MediaSource]`
- Produces: `MediaSource.to_dict() -> dict`

- [ ] **Step 1: Create registry model and source list**

Create `media_sources.py` with this implementation:

```python
# -*- coding: utf-8 -*-
"""行业媒体/行情数据源注册表。

这里登记“可以采集什么”和“如何采集”，不直接执行网络请求。
微信公众号类源没有公开 API，必须显式标记为 feed/manual/playwright 等待配置策略。
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field


@dataclass(frozen=True)
class MediaSource:
    source_id: str
    name: str
    channel_type: str
    access_method: str
    crawler_strategy: str
    confidence_base: float
    enabled: bool = True
    website_url: str = ""
    wechat_name: str = ""
    url_template: str = ""
    source_type: str = "website"
    max_articles: int = 8
    keywords: list[str] = field(default_factory=list)
    selectors: dict[str, str] = field(default_factory=dict)
    notes: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


DEFAULT_MARKET_KEYWORDS = [
    "MLCC涨价", "高容MLCC缺货", "MCU缺货", "含存储MCU交期",
    "SDRAM缺货", "DRAM产能", "NAND涨价", "PCB涨价", "高端PCB缺货",
    "日东纺 玻纤布", "IGBT交期", "功率模块涨价", "MOSFET涨价",
    "长晶涨价", "杨杰涨价", "分立器件涨价", "晶圆产能紧张",
]


MEDIA_SOURCES: list[MediaSource] = [
    MediaSource(
        source_id="xinshiyeye_wechat",
        name="芯师爷",
        channel_type="wechat_mp",
        access_method="微信公众号搜索「芯师爷」关注；无公开 API，优先接入 Feed/手动转发",
        crawler_strategy="manual_forward",
        confidence_base=0.48,
        enabled=True,
        wechat_name="芯师爷",
        source_type="wechat_mp",
        notes="每日芯闻/行情来源；单源默认降权，进入观察或待复核。",
    ),
    MediaSource(
        source_id="semiinsights_wechat",
        name="半导体行业观察",
        channel_type="wechat_mp",
        access_method="微信公众号搜索关注；无公开 API，优先接入 Feed/手动转发",
        crawler_strategy="manual_forward",
        confidence_base=0.50,
        enabled=True,
        wechat_name="半导体行业观察",
        source_type="wechat_mp",
        notes="行业深度分析来源；适合提取产业趋势，不单独触发强预警。",
    ),
    MediaSource(
        source_id="esmchina_web",
        name="国际电子商情",
        channel_type="website_and_wechat",
        access_method="官网 esmchina.com + 公众号",
        crawler_strategy="http_html",
        confidence_base=0.68,
        enabled=True,
        website_url="https://www.esmchina.com/",
        wechat_name="国际电子商情",
        url_template="https://www.esmchina.com/",
        source_type="website",
        max_articles=8,
        keywords=DEFAULT_MARKET_KEYWORDS,
        selectors={"article": "article, .item, li", "title": "a", "link": "a"},
        notes="元器件行情/分销商动态；官网若超时或 JS 渲染失败，保留为待增强源。",
    ),
    MediaSource(
        source_id="mantianxin_wechat",
        name="满天芯",
        channel_type="wechat_mp",
        access_method="微信公众号搜索关注；无公开 API，优先接入 Feed/手动转发",
        crawler_strategy="manual_forward",
        confidence_base=0.52,
        enabled=True,
        wechat_name="满天芯",
        source_type="wechat_mp",
        notes="IC 交易网旗下每日元器件行情；用于补充分销市场情绪。",
    ),
    MediaSource(
        source_id="eeworld_web",
        name="电子工程世界 EEWorld",
        channel_type="website_and_wechat",
        access_method="eeworld.com.cn + 公众号",
        crawler_strategy="http_html",
        confidence_base=0.62,
        enabled=True,
        website_url="https://www.eeworld.com.cn/",
        wechat_name="电子工程世界",
        url_template="https://www.eeworld.com.cn/",
        source_type="website",
        max_articles=8,
        keywords=DEFAULT_MARKET_KEYWORDS,
        selectors={"article": "article, .news-list li, li", "title": "a", "link": "a"},
        notes="行业资讯/技术趋势；官网抓取失败时不影响其他源。",
    ),
    MediaSource(
        source_id="xinzhixun_wechat",
        name="芯智讯",
        channel_type="wechat_mp",
        access_method="微信公众号搜索关注；无公开 API，优先接入 Feed/手动转发",
        crawler_strategy="manual_forward",
        confidence_base=0.50,
        enabled=True,
        wechat_name="芯智讯",
        source_type="wechat_mp",
        notes="芯片产业新闻；先登记为待接入公众号源。",
    ),
    MediaSource(
        source_id="lcsc_jlcsearch",
        name="立创商城 / JLCSearch",
        channel_type="api_and_wechat",
        access_method="JLCSearch API 已接入；公众号促销/活动后续通过手动转发或 Feed 接入",
        crawler_strategy="api_json",
        confidence_base=0.60,
        enabled=True,
        website_url="https://www.szlcsc.com/",
        wechat_name="立创商城",
        url_template="https://jlcsearch.tscircuit.com/api/search?q={keyword}",
        source_type="website",
        max_articles=10,
        keywords=DEFAULT_MARKET_KEYWORDS,
        notes="API 用于库存/热词趋势，公众号用于促销和活动补充。",
    ),
    MediaSource(
        source_id="guanxintai_search",
        name="观芯台行情搜索",
        channel_type="website",
        access_method="网页关键词搜索",
        crawler_strategy="keyword_search",
        confidence_base=0.72,
        enabled=True,
        website_url="https://www.guanxintai.com/",
        url_template="https://www.guanxintai.com/index?keyword={keyword}",
        source_type="website",
        max_articles=10,
        keywords=DEFAULT_MARKET_KEYWORDS,
        selectors={"article": "tr", "title": "td:first-child", "link": "a"},
        notes="当前已验证可作为关键词行情源之一。",
    ),
]


def list_media_sources(enabled_only: bool = False) -> list[MediaSource]:
    if enabled_only:
        return [source for source in MEDIA_SOURCES if source.enabled]
    return list(MEDIA_SOURCES)


def get_media_source(source_id: str) -> MediaSource | None:
    for source in MEDIA_SOURCES:
        if source.source_id == source_id:
            return source
    return None
```

- [ ] **Step 2: Run import check**

Run:

```powershell
& 'C:\Users\HAIER\AppData\Local\Programs\Python\Python311\python.exe' -c "from app.knowledge.media_sources import MEDIA_SOURCES; print(len(MEDIA_SOURCES)); print([s.source_id for s in MEDIA_SOURCES])"
```

Expected: prints at least `8`, including the 7 user-requested sources plus `guanxintai_search`.

---

### Task 2: 将 IndustryMediaCrawler 改为注册表驱动

**Files:**
- Modify: `d:\1项目清单\交期风险排查\BOM-Risk-Analyzer-patch\backend\app\services\media_crawler.py`

**Interfaces:**
- Consumes: `list_media_sources(enabled_only=True)` and `get_media_source(source_id)` from Task 1.
- Produces: `IndustryMediaCrawler.crawl_all(source_id: str | None = None) -> list[CrawledArticle]`
- Produces: `IndustryMediaCrawler.crawl_source(source: MediaSource) -> list[CrawledArticle]`

- [ ] **Step 1: Update imports**

Add:

```python
from app.knowledge.media_sources import MediaSource, list_media_sources, get_media_source
```

- [ ] **Step 2: Replace hard-coded source list**

Remove the `SOURCES = [...]` class attribute. Keep `SEARCH_KEYWORDS` as fallback, but source-specific keywords should come from `MediaSource.keywords`.

- [ ] **Step 3: Update crawl_all signature and dispatch**

Implement:

```python
def crawl_all(self, source_id: str | None = None) -> list[CrawledArticle]:
    """爬取所有启用数据源，或按 source_id 爬取单个数据源。"""
    if source_id:
        source = get_media_source(source_id)
        if not source:
            logger.warning(f"Media crawler: unknown source_id={source_id}")
            return []
        sources = [source] if source.enabled else []
    else:
        sources = list_media_sources(enabled_only=True)

    all_articles: list[CrawledArticle] = []
    for source in sources:
        try:
            articles = self.crawl_source(source)
            all_articles.extend(articles)
            logger.info(
                f"Media crawler: {source.name}({source.source_id}) → {len(articles)} articles"
            )
        except Exception as e:
            logger.warning(f"Media crawler: {source.name}({source.source_id}) failed: {e}")
    return all_articles


def crawl_source(self, source: MediaSource) -> list[CrawledArticle]:
    strategy = source.crawler_strategy
    if strategy == "api_json":
        return self._crawl_keyword_source(source)
    if strategy == "keyword_search":
        return self._crawl_keyword_source(source)
    if strategy == "http_html":
        return self._crawl_source(source)
    if strategy in {"manual_forward", "wechat_feed", "playwright_required"}:
        logger.info(
            f"Media crawler: {source.name} uses {strategy}; no direct HTTP crawl in this stage"
        )
        return []
    logger.warning(f"Media crawler: unsupported strategy={strategy} for {source.source_id}")
    return []
```

- [ ] **Step 4: Make helper methods accept MediaSource**

Update dictionary access:

```python
max_total = source.max_articles
keywords = source.keywords or self.SEARCH_KEYWORDS
url = source.url_template.replace("{keyword}", keyword)
source.source_id
source.source_type
source.selectors
source.confidence_base
```

In `CrawledArticle`, set:

```python
source_name=source.source_id
source_type=source.source_type
```

- [ ] **Step 5: Preserve API JSON parsing for LCSC**

Keep parsing:

```python
components = data.get("components", [])
for comp in components[:limit]:
    mfr = comp.get("mfr", "")
    stock = comp.get("stock", 0)
    lcsc = comp.get("lcsc", "")
```

- [ ] **Step 6: Run import and smoke check**

Run:

```powershell
& 'C:\Users\HAIER\AppData\Local\Programs\Python\Python311\python.exe' -c "from app.services.media_crawler import IndustryMediaCrawler; c=IndustryMediaCrawler(); print(type(c.crawl_all(source_id='xinshiyeye_wechat')).__name__); c.close()"
```

Expected: prints `list`; no exception. `xinshiyeye_wechat` should return an empty list because it is `manual_forward`.

---

### Task 3: 扩展事件 API 支持媒体源状态和单源采集

**Files:**
- Modify: `d:\1项目清单\交期风险排查\BOM-Risk-Analyzer-patch\backend\app\api\events.py`

**Interfaces:**
- Consumes: `list_media_sources()`
- Consumes: `IndustryMediaCrawler.crawl_all(source_id: str | None = None)`
- Produces: `GET /api/events/media-sources`
- Produces: `POST /api/events/collect-media?source_id=lcsc_jlcsearch`

- [ ] **Step 1: Add import**

```python
from app.knowledge.media_sources import list_media_sources, get_media_source
```

- [ ] **Step 2: Add media source listing endpoint before `/{event_id}` routes**

```python
@router.get("/media-sources")
def list_registered_media_sources(enabled_only: bool = Query(False)):
    """查看已登记的行业媒体/行情数据源及接入状态。"""
    sources = list_media_sources(enabled_only=enabled_only)
    return {
        "total": len(sources),
        "sources": [source.to_dict() for source in sources],
    }
```

- [ ] **Step 3: Update collect-media signature**

Change:

```python
@router.post("/collect-media")
def trigger_media_crawl(db: Session = Depends(get_db)):
```

To:

```python
@router.post("/collect-media")
def trigger_media_crawl(
    source_id: str | None = Query(None),
    db: Session = Depends(get_db),
):
```

- [ ] **Step 4: Validate source_id**

At start of function:

```python
if source_id and not get_media_source(source_id):
    raise HTTPException(status_code=404, detail=f"Unknown media source: {source_id}")
```

- [ ] **Step 5: Pass source_id to crawler**

Change:

```python
articles = crawler.crawl_all()
```

To:

```python
articles = crawler.crawl_all(source_id=source_id)
```

- [ ] **Step 6: Include source_id in response**

Return:

```python
return {
    "status": "ok",
    "source_id": source_id or "all",
    "articles_crawled": len(articles),
    "signals_parsed": len(signals),
    "events_created": len(new_events),
    "events": [e.to_dict() for e in new_events],
}
```

- [ ] **Step 7: API smoke checks**

With backend running, run:

```powershell
Invoke-RestMethod -Method Get -Uri 'http://127.0.0.1:8000/api/events/media-sources'
Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:8000/api/events/collect-media?source_id=lcsc_jlcsearch'
Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:8000/api/events/collect-media?source_id=xinshiyeye_wechat'
```

Expected:
- First call returns `total >= 8`.
- LCSC call returns `source_id = lcsc_jlcsearch` and no exception.
- 芯师爷 call returns `source_id = xinshiyeye_wechat`, `articles_crawled = 0`, no exception.

---

### Task 4: 调整 EventCollector 单源采集入口

**Files:**
- Modify: `d:\1项目清单\交期风险排查\BOM-Risk-Analyzer-patch\backend\app\services\event_collector.py`

**Interfaces:**
- Consumes: `IndustryMediaCrawler.crawl_all(source_id: str | None = None)`
- Produces: `_collect_from_industry_media(source_id: str | None = None) -> list[MarketEvent]`

- [ ] **Step 1: Change private method signature**

```python
def _collect_from_industry_media(self, source_id: str | None = None) -> List[MarketEvent]:
```

- [ ] **Step 2: Pass source_id to crawler**

```python
articles = crawler.crawl_all(source_id=source_id)
```

- [ ] **Step 3: Keep collect_all unchanged for full collection**

`collect_all()` should continue calling:

```python
media_events = self._collect_from_industry_media()
```

Expected behavior: full collection still seeds knowledge base, crawls all enabled direct sources, and keeps LCSC trends.

---

### Task 5: Verification

**Files:**
- No production file changes unless verification reveals a defect.

**Interfaces:**
- Verifies: media source import, crawler direct-source behavior, API routing.

- [ ] **Step 1: Python import verification**

Run from backend directory:

```powershell
& 'C:\Users\HAIER\AppData\Local\Programs\Python\Python311\python.exe' -c "from app.knowledge.media_sources import MEDIA_SOURCES; assert len(MEDIA_SOURCES) >= 8; assert any(s.source_id == 'lcsc_jlcsearch' for s in MEDIA_SOURCES); print('media source registry ok')"
```

Expected: `media source registry ok`.

- [ ] **Step 2: Crawler strategy verification**

Run from backend directory:

```powershell
& 'C:\Users\HAIER\AppData\Local\Programs\Python\Python311\python.exe' -c "from app.services.media_crawler import IndustryMediaCrawler; c=IndustryMediaCrawler(); assert c.crawl_all('xinshiyeye_wechat') == []; print('manual source ok'); print(type(c.crawl_all('lcsc_jlcsearch')).__name__); c.close()"
```

Expected: prints `manual source ok` and `list`.

- [ ] **Step 3: Frontend/backend route safety check**

Run backend import:

```powershell
& 'C:\Users\HAIER\AppData\Local\Programs\Python\Python311\python.exe' -c "from app.main import app; print('fastapi app import ok')"
```

Expected: `fastapi app import ok`.

- [ ] **Step 4: If frontend tests are available, run existing test suite**

Run from frontend directory:

```powershell
npm run test -- --run
```

Expected: existing tests remain passing.

- [ ] **Step 5: Build check**

Run from frontend directory:

```powershell
npm run build
```

Expected: build completes successfully.

---

## Self-Review

- Spec coverage: The plan registers all 7 user-requested sources, preserves LCSC, adds source status API, supports single-source media collection, and keeps公众号降权策略.
- Placeholder scan: No `TBD` / `TODO` / vague implementation steps remain.
- Type consistency: `MediaSource`, `MEDIA_SOURCES`, `get_media_source`, `list_media_sources`, and `crawl_all(source_id=None)` are consistently named across tasks.
