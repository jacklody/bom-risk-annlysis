# v3.10 多源供应数据聚合实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将 DigiKey、Mouser、观芯台并行接入 SupplyDataService，采用最优值合并策略（库存取最大、单价取最低、交期取最短、生命周期取最可靠），补齐 v3.9 交期和生命周期盲区。

**Architecture:** 每个数据源独立为一个 `SourceResult` 状态化 Provider，SupplyDataService 通过 `asyncio.gather` 并行查询，合并层取跨源最优值写入 BomItem 既有字段。API 层和写入保护逻辑不变。

**Tech Stack:** Python 3.11, httpx, FastAPI, pytest-asyncio, BeautifulSoup4 (观芯台 HTML 解析)

## Global Constraints

- 只实现 v3.10：多源供应数据聚合（DigiKey + Mouser + 观芯台 + LCSC）
- Nexar/Octopart 待开通后作为 v3.11 增量接入
- 不新增数据库字段，只写入 BomItem 既有字段
- 失败不清空旧供应字段（`is_available=False` 时 `apply_to_bom_item` 返回 `False`）
- 单独刷新供应数据不改 `risk_level`/`risk_score`/`risk_reason`
- 不改变 v3.8 市场趋势/事件逻辑
- 真实数据验证必须报告真实状态，不伪造命中结果
- LCSC 单源回退兼容：当只有 LCSC 可用时行为与 v3.9 一致
- Mouser API Key 只允许保存在 `backend/.env` 的 `MOUSER_API_KEY`，不要写入计划文档或 README
- DigiKey ClientId 只允许保存在 `backend/.env` 的 `DIGIKEY_CLIENT_ID`，不要写入计划文档或 README
- DigiKey ClientSecret 只允许保存在 `backend/.env` 的 `DIGIKEY_CLIENT_SECRET`，不要写入计划文档或 README
- 凭证台账见项目根目录外层的 `API密钥与数据源接入台账.md`，文档只记录变量名和状态，不展开真实值

---

### Task 1: MouserSource 状态化 + Header 认证 + 跨 loop

**Files:**
- Modify: `backend/app/services/sources/mouser.py`
- Test: `tests/test_multi_source_supply.py` (新建)

**Interfaces:**
- Produces: `MouserSource.query_by_mpn(mpn: str) -> SourceResult` (不再返回 Optional[SourceResult] 或 None)
- Produces: `MouserSource._client_loop` 跨事件循环重建（对齐 LCSCSource 已验证模式）

- [ ] **Step 1: 写 MouserSource 状态化失败测试**

Create `tests/test_multi_source_supply.py`:

```python
"""多源供应数据聚合测试"""
import pytest
import httpx
from app.services.sources.base import SourceResult
from app.services.sources.mouser import MouserSource


class FakeResponse2:
    def __init__(self, payload=None, status_code=200):
        self.payload = payload or {}
        self.status_code = status_code

    def raise_for_status(self):
        if self.status_code >= 400:
            raise Exception(f"HTTP {self.status_code}")

    def json(self):
        return self.payload


class FakeClient2:
    def __init__(self, response=None, error=None):
        self.response = response
        self.error = error
        self.calls = []

    async def post(self, url, params=None, json=None, headers=None):
        self.calls.append({"url": url, "params": params, "json": json, "headers": headers})
        if self.error:
            raise self.error
        return self.response


@pytest.mark.asyncio
async def test_mouser_query_returns_hit_with_stock_price_leadtime_lifecycle():
    source = MouserSource(api_key="test-key")
    source._client = FakeClient2(FakeResponse2({
        "SearchResults": {
            "Parts": [{
                "ManufacturerPartNumber": "STM32F103C8T6",
                "Manufacturer": "STMicroelectronics",
                "Availability": "1,234 In Stock. 10 Days Factory Lead Time.",
                "LifecycleStatus": "Active",
                "PriceBreaks": [
                    {"Quantity": 1, "Price": "$12.34"},
                    {"Quantity": 10, "Price": "$10.50"},
                ],
                "Min": 1,
            }]
        }
    }))

    result = await source.query_by_mpn("STM32F103C8T6")

    assert isinstance(result, SourceResult)
    assert result.source == "mouser"
    assert result.match_status == "hit"
    assert result.is_available is True
    assert result.total_stock == 1234
    assert result.lead_time_days == 10
    assert result.unit_price == 12.34
    assert result.currency == "USD"
    assert result.lifecycle_status == "Active"
    assert result.manufacturer == "STMicroelectronics"


@pytest.mark.asyncio
async def test_mouser_query_returns_not_found_without_exception():
    source = MouserSource(api_key="test-key")
    source._client = FakeClient2(FakeResponse2({"SearchResults": {"Parts": []}}))

    result = await source.query_by_mpn("NO_SUCH")

    assert result.match_status == "not_found"
    assert result.is_available is False


@pytest.mark.asyncio
async def test_mouser_query_returns_timeout_for_httpx_timeout():
    source = MouserSource(api_key="test-key")
    source._client = FakeClient2(error=httpx.TimeoutException("timeout"))

    result = await source.query_by_mpn("TIMED_OUT")

    assert result.match_status == "timeout"
    assert result.is_available is False
    assert "timeout" in result.error_reason


@pytest.mark.asyncio
async def test_mouser_not_configured_returns_unconfigured():
    source = MouserSource(api_key="")

    result = await source.query_by_mpn("STM32")

    assert result.match_status == "not_configured"
    assert result.is_available is False
```

- [ ] **Step 2: 运行测试确认失败**

Run: `py -3.11 -m pytest tests\test_multi_source_supply.py -q`

Expected: FAIL — `MouserSource` 仍返回 `Optional[SourceResult]`/`None`，无 `match_status`

- [ ] **Step 3: 重写 MouserSource**

Rewrite `backend/app/services/sources/mouser.py`:

```python
"""Mouser API 数据源 — 免费注册获取 API Key 后使用。

注册地址: https://www.mouser.com/api-search/
频率限制: 30次/分钟

返回：实时库存、工厂交期(天)、阶梯价格、生命周期状态
"""

from __future__ import annotations

import asyncio
import logging
import re as _re
from typing import Optional

import httpx
from app.config import settings

from .base import BaseSource, SourceResult

logger = logging.getLogger(__name__)

MOUSER_API_BASE = "https://api.mouser.com/api/v1"


class MouserSource(BaseSource):
    """Mouser 数据源 — 实时库存 + 工厂交期(天) + 生命周期"""

    source_name = "mouser"

    def __init__(self, api_key: str = ""):
        self.api_key = api_key or settings.mouser_api_key
        self._client: Optional[httpx.AsyncClient] = None
        self._client_loop: Optional[asyncio.AbstractEventLoop] = None

    @property
    def is_configured(self) -> bool:
        return bool(self.api_key)

    async def _get_client(self) -> httpx.AsyncClient:
        current_loop = asyncio.get_running_loop()
        if self._client is not None and self._client_loop is None and not self._client.is_closed:
            self._client_loop = current_loop
            return self._client
        if (
            self._client is None
            or self._client_loop is not current_loop
            or self._client.is_closed
        ):
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(15.0),
                follow_redirects=True,
            )
            self._client_loop = current_loop
        return self._client

    async def health_check(self) -> bool:
        if not self.is_configured:
            return False
        try:
            result = await self.query_by_mpn("STM32F103C8T6")
            return result is not None and result.match_status == "hit"
        except Exception:
            return False

    async def query_by_mpn(self, mpn: str) -> SourceResult:
        if not self.is_configured:
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                match_status="not_configured",
                error_reason="Mouser API Key 未配置",
            )

        clean = self.clean_mpn(mpn)
        if not clean:
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                match_status="missing_mpn",
                error_reason="物料型号为空，无法查询 Mouser",
            )

        client = await self._get_client()

        try:
            response = await client.post(
                f"{MOUSER_API_BASE}/search/keyword",
                headers={"apiKey": self.api_key, "Content-Type": "application/json"},
                json={"SearchByKeywordRequest": {"keyword": clean, "records": 3}},
            )
            response.raise_for_status()
        except httpx.TimeoutException as exc:
            logger.warning(f"Mouser query timeout for '{clean}': {exc}")
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                match_status="timeout",
                error_reason=str(exc) or "Mouser 查询超时",
            )
        except Exception as exc:
            logger.warning(f"Mouser query failed for '{clean}': {exc}")
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                match_status="request_failed",
                error_reason=str(exc) or "Mouser 请求失败",
            )

        try:
            data = response.json()
            parts = data.get("SearchResults", {}).get("Parts", [])
        except Exception as exc:
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                match_status="parse_failed",
                error_reason=str(exc) or "Mouser 响应解析失败",
            )

        if not parts:
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                is_available=False,
                match_status="not_found",
                error_reason="Mouser 暂未命中该型号",
            )

        try:
            best = parts[0]

            availability = best.get("Availability", "") or ""
            total_stock = self._parse_stock(availability)

            lead_time_days = None
            lead_time_display = availability
            if "factory lead time" in availability.lower():
                m = _re.search(r'(\d+)\s*Days?\s*[Ff]actory\s*[Ll]ead\s*[Tt]ime', availability)
                if m:
                    lead_time_days = int(m.group(1))

            price_breaks_data = best.get("PriceBreaks", [])
            price_breaks = []
            unit_price = None
            for pb in price_breaks_data:
                qty = pb.get("Quantity", 0)
                price_str = str(pb.get("Price", ""))
                try:
                    price = float(price_str.replace("¥", "").replace("$", "").replace(",", "").strip())
                except (ValueError, TypeError):
                    price = 0.0
                price_breaks.append({"qty": qty, "price": price, "currency": "USD"})
                if unit_price is None and qty >= 1:
                    unit_price = price

            moq = best.get("Min", 1) or 1
            manufacturer_part = best.get("ManufacturerPartNumber", "")
            lifecycle = best.get("LifecycleStatus", "") or ""
            currency = "CNY" if "¥" in str(best.get("PriceBreaks", [{}])[0].get("Price", "$")) else "USD"
            raw_summary = f"Mouser 命中 {manufacturer_part or clean}，库存{total_stock}"

            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                mpn_matched=str(manufacturer_part),
                manufacturer=str(best.get("Manufacturer", "")),
                total_stock=total_stock,
                lead_time_days=lead_time_days,
                lead_time_display=lead_time_display,
                unit_price=unit_price,
                price_breaks=price_breaks,
                moq=moq,
                currency="USD",
                lifecycle_status=lifecycle,
                category=str(best.get("Category", "")),
                product_url=str(best.get("ProductDetailUrl", "")),
                datasheet_url=str(best.get("DataSheetUrl", "")),
                match_status="hit",
                raw_summary=raw_summary,
                is_available=True,
                raw_response=best,
            )
        except Exception as exc:
            logger.warning(f"Mouser response parse failed for '{clean}': {exc}")
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                match_status="parse_failed",
                error_reason=str(exc) or "Mouser 响应字段解析失败",
            )

    @staticmethod
    def _parse_stock(availability: str) -> int:
        if not availability:
            return 0
        m = _re.match(r'([\d,]+)', availability.strip())
        if m:
            return int(m.group(1).replace(",", ""))
        return 0

    async def close(self):
        if self._client:
            await self._client.aclose()
            self._client = None
            self._client_loop = None
```

- [ ] **Step 4: 运行测试确认通过**

Run: `py -3.11 -m pytest tests\test_multi_source_supply.py -q`

Expected: `4 passed`

- [ ] **Step 5: 提交**

```powershell
git add backend\app\services\sources\mouser.py tests\test_multi_source_supply.py
git commit -m 'refactor: normalize mouser supply source status and auth'
```

---

### Task 2: DigiKeySource 新增 Provider

**Files:**
- Create: `backend/app/services/sources/digikey.py`
- Modify: `backend/app/config.py` (开启 digikey_enabled)
- Test: `tests/test_multi_source_supply.py` (追加)

**Interfaces:**
- Produces: `DigiKeySource.query_by_mpn(mpn: str) -> SourceResult`
- Produces: `DigiKeySource.is_configured: bool`

- [ ] **Step 1: 开启配置**

In `backend/app/config.py`, change L32:

```python
    digikey_enabled: bool = True
```

- [ ] **Step 2: 写 DigiKeySource 基础测试**

Append to `tests/test_multi_source_supply.py`:

```python
from app.services.sources.digikey import DigiKeySource


class FakeDigiKeyClient:
    def __init__(self, responses=None):
        self.responses = responses or {}
        self.calls = []

    async def post(self, url, data=None, json=None, headers=None):
        self.calls.append({"url": url, "data": data, "json": json, "headers": headers})
        if url.endswith("/oauth2/token"):
            return FakeResponse2({"access_token": "fake-token", "expires_in": 600})
        return self.responses.get(url, FakeResponse2({}))


@pytest.mark.asyncio
async def test_digikey_query_returns_hit_with_all_fields():
    source = DigiKeySource(client_id="test-id", client_secret="test-secret")
    digi_resp = FakeResponse2({
        "Products": [{
            "ManufacturerProductNumber": "STM32F103C8T6TR",
            "Manufacturer": {"Name": "STMicroelectronics"},
            "QuantityAvailable": 4034,
            "UnitPrice": 54.66,
            "ManufacturerLeadWeeks": "20",
            "ProductStatus": {"Id": 0, "Status": "在售"},
        }]
    })
    fake = FakeDigiKeyClient({"/products/v4/search/keyword": digi_resp})
    source._client = fake

    result = await source.query_by_mpn("STM32F103C8T6")

    assert isinstance(result, SourceResult)
    assert result.source == "digikey"
    assert result.match_status == "hit"
    assert result.is_available is True
    assert result.total_stock == 4034
    assert result.unit_price == 54.66
    assert result.lead_time_days == 140
    assert result.lifecycle_status == "在售"
    assert result.manufacturer == "STMicroelectronics"


@pytest.mark.asyncio
async def test_digikey_query_returns_not_found_for_empty_products():
    source = DigiKeySource(client_id="test-id", client_secret="test-secret")
    digi_resp = FakeResponse2({"Products": []})
    fake = FakeDigiKeyClient({"/products/v4/search/keyword": digi_resp})
    source._client = fake

    result = await source.query_by_mpn("NO_SUCH")

    assert result.match_status == "not_found"
    assert result.is_available is False
```

- [ ] **Step 3: 运行测试确认失败**

Run: `py -3.11 -m pytest tests\test_multi_source_supply.py::test_digikey_query_returns_hit_with_all_fields -q`

Expected: FAIL — `ModuleNotFoundError: No module named 'app.services.sources.digikey'`

- [ ] **Step 4: 实现 DigiKeySource**

Create `backend/app/services/sources/digikey.py`:

```python
"""DigiKey API 数据源 — OAuth2 Client Credentials 认证。

注册地址: https://developer.digikey.com/
认证方式: OAuth2 Client Credentials (client_id + client_secret)

返回：实时库存、价格、工厂交期(周→天)、生命周期状态(在售/停产等)、PCN 变更通知
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Optional

import httpx
from app.config import settings

from .base import BaseSource, SourceResult

logger = logging.getLogger(__name__)

DIGIKEY_OAUTH_URL = "https://api.digikey.com/v1/oauth2/token"
DIGIKEY_SEARCH_URL = "https://api.digikey.com/products/v4/search/keyword"


class DigiKeySource(BaseSource):
    """DigiKey 数据源 — OAuth2 + Product Information V4"""

    source_name = "digikey"

    def __init__(self, client_id: str = "", client_secret: str = ""):
        self.client_id = client_id or settings.digikey_client_id
        self.client_secret = client_secret or settings.digikey_client_secret
        self._token: Optional[str] = None
        self._token_expiry: float = 0.0
        self._client: Optional[httpx.AsyncClient] = None
        self._client_loop: Optional[asyncio.AbstractEventLoop] = None

    @property
    def is_configured(self) -> bool:
        return bool(self.client_id and self.client_secret)

    async def _get_client(self) -> httpx.AsyncClient:
        current_loop = asyncio.get_running_loop()
        if self._client is not None and self._client_loop is None and not self._client.is_closed:
            self._client_loop = current_loop
            return self._client
        if (
            self._client is None
            or self._client_loop is not current_loop
            or self._client.is_closed
        ):
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(15.0),
                follow_redirects=True,
            )
            self._client_loop = current_loop
        return self._client

    async def _get_token(self) -> Optional[str]:
        now = time.monotonic()
        if self._token and now < self._token_expiry - 30:
            return self._token

        client = await self._get_client()
        try:
            response = await client.post(
                DIGIKEY_OAUTH_URL,
                data={
                    "client_id": self.client_id,
                    "client_secret": self.client_secret,
                    "grant_type": "client_credentials",
                },
            )
            response.raise_for_status()
            data = response.json()
            self._token = data.get("access_token", "")
            self._token_expiry = now + data.get("expires_in", 600)
            return self._token
        except Exception as exc:
            logger.warning(f"DigiKey OAuth failed: {exc}")
            return None

    async def health_check(self) -> bool:
        if not self.is_configured:
            return False
        try:
            result = await self.query_by_mpn("STM32F103C8T6")
            return result is not None and result.match_status == "hit"
        except Exception:
            return False

    async def query_by_mpn(self, mpn: str) -> SourceResult:
        if not self.is_configured:
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                match_status="not_configured",
                error_reason="DigiKey ClientId/ClientSecret 未配置",
            )

        clean = self.clean_mpn(mpn)
        if not clean:
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                match_status="missing_mpn",
                error_reason="物料型号为空，无法查询 DigiKey",
            )

        token = await self._get_token()
        if not token:
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                match_status="auth_failed",
                error_reason="DigiKey OAuth Token 获取失败",
            )

        client = await self._get_client()

        try:
            response = await client.post(
                DIGIKEY_SEARCH_URL,
                headers={
                    "Authorization": f"Bearer {token}",
                    "X-DIGIKEY-Client-Id": self.client_id,
                    "X-DIGIKEY-Locale-Site": "CN",
                    "X-DIGIKEY-Locale-Language": "zh",
                    "X-DIGIKEY-Locale-Currency": "CNY",
                    "Content-Type": "application/json",
                },
                json={"Keywords": clean, "Limit": 3},
            )
            response.raise_for_status()
        except httpx.TimeoutException as exc:
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                match_status="timeout",
                error_reason=str(exc) or "DigiKey 查询超时",
            )
        except Exception as exc:
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                match_status="request_failed",
                error_reason=str(exc) or "DigiKey 请求失败",
            )

        try:
            data = response.json()
            products = data.get("Products", [])
        except Exception as exc:
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                match_status="parse_failed",
                error_reason=str(exc) or "DigiKey 响应解析失败",
            )

        if not products:
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                is_available=False,
                match_status="not_found",
                error_reason="DigiKey 暂未命中该型号",
            )

        try:
            p = products[0]
            qty = p.get("QuantityAvailable", 0) or 0
            price = p.get("UnitPrice", None)
            lead_weeks_str = str(p.get("ManufacturerLeadWeeks", "") or "")
            lead_days = None
            try:
                lead_days = int(lead_weeks_str) * 7
            except (ValueError, TypeError):
                pass
            lifecycle = p.get("ProductStatus", {}).get("Status", "") or ""
            mfr = p.get("Manufacturer", {}).get("Name", "") or ""
            mpn_matched = p.get("ManufacturerProductNumber", "") or ""
            raw_summary = f"DigiKey 命中 {mpn_matched or clean}，库存{qty}，状态{lifecycle}"

            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                mpn_matched=mpn_matched,
                manufacturer=mfr,
                total_stock=qty,
                lead_time_days=lead_days,
                unit_price=price,
                currency="CNY",
                lifecycle_status=lifecycle,
                match_status="hit",
                raw_summary=raw_summary,
                is_available=True,
                raw_response=p,
            )
        except Exception as exc:
            logger.warning(f"DigiKey response parse failed for '{clean}': {exc}")
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                match_status="parse_failed",
                error_reason=str(exc) or "DigiKey 响应字段解析失败",
            )

    async def close(self):
        if self._client:
            await self._client.aclose()
            self._client = None
            self._client_loop = None
```

- [ ] **Step 5: 注册导出**

In `backend/app/services/sources/__init__.py`, add after L5:

```python
from .digikey import DigiKeySource

__all__ = ["BaseSource", "SourceResult", "LCSCSource", "MouserSource", "DigiKeySource"]
```

- [ ] **Step 6: 运行 DigiKey 测试**

Run: `py -3.11 -m pytest tests\test_multi_source_supply.py::test_digikey -q`

Expected: `2 passed`

- [ ] **Step 7: 提交**

```powershell
git add backend\app\services\sources\digikey.py backend\app\services\sources\__init__.py backend\app\config.py tests\test_multi_source_supply.py
git commit -m 'feat: add digikey oauth2 supply source'
```

---

### Task 3: 观芯台 Source (HTML 解析)

**Files:**
- Create: `backend/app/services/sources/guanxintai.py`
- Create: `backend/app/services/sources/html_source.py` (HTML utility)
- Modify: `backend/app/services/sources/__init__.py`
- Modify: `backend/app/config.py` (新增 guanxintai_enabled)
- Test: `tests/test_multi_source_supply.py` (追加)

**Interfaces:**
- Produces: `GuanxintaiSource.query_by_mpn(mpn: str) -> SourceResult`
- Dependencies: `beautifulsoup4` (需安装)

- [ ] **Step 1: 安装依赖 + 开启配置**

```powershell
pip install beautifulsoup4
```

In `backend/app/config.py`, after L27:

```python
    # 观芯台 — 免登录网页聚合比价
    guanxintai_enabled: bool = True
```

- [ ] **Step 2: 写观芯台测试**

Append to `tests/test_multi_source_supply.py`:

```python
from app.services.sources.guanxintai import GuanxintaiSource


@pytest.mark.asyncio
async def test_guanxintai_parse_table_yields_stock_price():
    html = """
<table>
<tr><td>STM32F103C8T6</td><td>ST</td><td>1+:¥6.98</td><td>1,063</td><td>立即发货</td><td>立创商城</td></tr>
<tr><td>STM32F103C8T6</td><td>ST</td><td>1+:¥6.98</td><td>33,688</td><td>立即发货</td><td>华秋商城</td></tr>
</table>
"""
    class FakeGuanxinClient:
        async def get(self, url, params=None):
            return FakeResponse2({}, status_code=200)
        async def aclose(self): pass

    source = GuanxintaiSource()
    source._client = FakeGuanxinClient()
    result = source._parse_html_to_result(html, "STM32F103C8T6")

    assert result.source == "guanxintai"
    assert result.is_available is True
    assert result.total_stock == 33688
    assert result.unit_price == 6.98
    assert result.match_status == "hit"
```

- [ ] **Step 3: 运行测试确认失败**

Run: `py -3.11 -m pytest tests\test_multi_source_supply.py::test_guanxintai -q`

Expected: FAIL — `ModuleNotFoundError`

- [ ] **Step 4: 实现观芯台 Source**

Create `backend/app/services/sources/guanxintai.py`:

```python
"""观芯台 (guanxintai.com) 数据源 — 免登录 HTML 解析。

搜索 URL: https://www.guanxintai.com/index?keyword=型号
数据：聚合立创商城、华秋商城、圣禾堂等多渠道价格库存
频率限制: 3s 请求间隔
"""

from __future__ import annotations

import asyncio
import logging
import re
import time
from typing import Optional

import httpx

from .base import BaseSource, SourceResult

logger = logging.getLogger(__name__)

GUANXINTAI_SEARCH_URL = "https://www.guanxintai.com/index"


class GuanxintaiSource(BaseSource):
    """观芯台 — 国内元器件聚合比价"""

    source_name = "guanxintai"

    def __init__(self):
        self._last_request_time = 0.0
        self._client: Optional[httpx.AsyncClient] = None
        self._client_loop: Optional[asyncio.AbstractEventLoop] = None

    @property
    def is_configured(self) -> bool:
        return True  # 免认证

    async def _get_client(self) -> httpx.AsyncClient:
        current_loop = asyncio.get_running_loop()
        if self._client is not None and self._client_loop is None and not self._client.is_closed:
            self._client_loop = current_loop
            return self._client
        if (
            self._client is None
            or self._client_loop is not current_loop
            or self._client.is_closed
        ):
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(15.0),
                follow_redirects=True,
                headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
            )
            self._client_loop = current_loop
        return self._client

    async def _rate_limit(self):
        now = time.monotonic()
        elapsed = now - self._last_request_time
        if elapsed < 3.0:
            await asyncio.sleep(3.0 - elapsed)
        self._last_request_time = time.monotonic()

    async def health_check(self) -> bool:
        try:
            result = await self.query_by_mpn("STM32F103C8T6")
            return result is not None and result.match_status == "hit"
        except Exception:
            return False

    async def query_by_mpn(self, mpn: str) -> SourceResult:
        clean = self.clean_mpn(mpn)
        if not clean:
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                match_status="missing_mpn",
                error_reason="物料型号为空，无法查询观芯台",
            )

        await self._rate_limit()
        client = await self._get_client()

        try:
            response = await client.get(
                GUANXINTAI_SEARCH_URL,
                params={"keyword": clean},
            )
            response.raise_for_status()
            html = response.text
        except httpx.TimeoutException as exc:
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                match_status="timeout",
                error_reason=str(exc) or "观芯台 查询超时",
            )
        except Exception as exc:
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                match_status="request_failed",
                error_reason=str(exc) or "观芯台 请求失败",
            )

        if not html or len(html) < 200:
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                is_available=False,
                match_status="not_found",
                error_reason="观芯台 返回空页面",
            )

        return self._parse_html_to_result(html, clean)

    def _parse_html_to_result(self, html: str, mpn: str) -> SourceResult:
        """解析观芯台 HTML 中的价格表格行。

        页面结构: 多个 <table> 中每行 <tr> 包含
        型号 | 厂牌 | 封装 | 价格(含税) | 库存 | 批次 | 交期 | 渠道
        解析所有行的价格和库存，取最优值。
        """
        try:
            from bs4 import BeautifulSoup
        except ImportError:
            logger.warning("beautifulsoup4 not installed, guanxintai parse skipped")
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                match_status="parse_failed",
                error_reason="beautifulsoup4 未安装",
            )

        soup = BeautifulSoup(html, "html.parser")
        tables = soup.find_all("table")
        if not tables:
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                is_available=False,
                match_status="not_found",
                error_reason="观芯台 未找到价格表格",
            )

        # 聚合所有表格行
        total_stock = 0
        unit_price = None
        lead_time_display = ""
        channels = []

        price_pattern = re.compile(r'(\d+\.?\d*)')  # 从价格文本提取数字

        for table in tables:
            rows = table.find_all("tr")
            for row in rows:
                cells = row.find_all("td")
                if len(cells) < 4:
                    continue
                # 尝试从单元格提取价格和库存
                text_content = [c.get_text(strip=True) for c in cells]

                # 查找含 "¥" 或纯数字价格模式的列
                price_val = None
                for text in text_content:
                    price_match = re.search(r'[¥￥]?\s*([\d.]+)', text)
                    if price_match:
                        try:
                            p = float(price_match.group(1))
                            if 0.001 < p < 100000:
                                price_val = p
                                break
                        except ValueError:
                            continue

                # 查找库存列（纯数字，靠后位置）
                stock_val = 0
                for text in reversed(text_content[-4:]):  # 最后4列中找库存
                    cleaned = text.replace(",", "").replace(" ", "")
                    if cleaned.isdigit():
                        stock_val = int(cleaned)
                        if stock_val > 0:
                            break

                # 查找交期列
                for text in text_content[-3:]:
                    if any(w in text for w in ["发货", "现货", "交期"]):
                        lead_time_display = text
                        break

                if stock_val > 0:
                    total_stock = max(total_stock, stock_val)
                if price_val and (unit_price is None or price_val < unit_price):
                    unit_price = price_val

                if stock_val > 0 or price_val:
                    channels.append(text_content[0] if text_content else "?")

        if total_stock == 0 and unit_price is None:
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                is_available=False,
                match_status="not_found",
                error_reason="观芯台 未解析到有效价格/库存",
            )

        raw_summary = f"观芯台 命中，库存{total_stock}，渠道{len(channels)}家"
        return SourceResult(
            source=self.source_name,
            mpn_queried=mpn,
            total_stock=total_stock,
            supplier_count=len(set(channels)),
            unit_price=unit_price,
            currency="CNY",
            lead_time_display=lead_time_display,
            match_status="hit",
            raw_summary=raw_summary,
            is_available=True,
        )

    async def close(self):
        if self._client:
            await self._client.aclose()
            self._client = None
            self._client_loop = None
```

- [ ] **Step 5: 注册导出**

In `backend/app/services/sources/__init__.py`:

```python
from .guanxintai import GuanxintaiSource

__all__ = ["BaseSource", "SourceResult", "LCSCSource", "MouserSource", "DigiKeySource", "GuanxintaiSource"]
```

- [ ] **Step 6: 运行观芯台测试**

Run: `py -3.11 -m pytest tests\test_multi_source_supply.py::test_guanxintai -q`

Expected: `1 passed`

- [ ] **Step 7: 运行全部多源测试**

Run: `py -3.11 -m pytest tests\test_multi_source_supply.py -q`

Expected: `7 passed` (4 Mouser + 2 DigiKey + 1 Guanxintai)

- [ ] **Step 8: 提交**

```powershell
git add backend\app\services\sources\guanxintai.py backend\app\services\sources\__init__.py backend\app\config.py tests\test_multi_source_supply.py
git commit -m 'feat: add guanxintai html scraping supply source'
```

---

### Task 4: SupplyDataService 多源并行 + 最优合并

**Files:**
- Modify: `backend/app/services/supply_data.py`
- Test: `tests/test_multi_source_supply.py` (追加)

**Interfaces:**
- Modifies: `SupplyDataService.__init__` 实例化 4 个源
- Modifies: `SupplyDataService.query_one` 并行查询 + 合并
- Modifies: `SupplyDataService.query_batch` 适配新 query_one
- Produces: `SupplyDataService._merge_best(results) -> AggregatedResult`
- Produces: `SupplyDataService._best_lifecycle(hits) -> str`
- Produces: `SupplyDataService._resolve_currency(hits, min_price) -> str`

- [ ] **Step 1: 写合并策略测试**

Append to `tests/test_multi_source_supply.py`:

```python
from app.services.supply_data import SupplyDataService, AggregatedResult


class StubSource:
    def __init__(self, name, result=None, configured=True):
        self.source_name = name
        self._result = result
        self._configured = configured

    @property
    def is_configured(self):
        return self._configured

    async def query_by_mpn(self, mpn):
        if self._result is None:
            return SourceResult(
                source=self.source_name,
                mpn_queried=mpn,
                match_status="not_found",
            )
        return self._result


def make_hit(name, stock=0, price=None, lead=None, lifecycle="Unknown"):
    return SourceResult(
        source=name, mpn_queried="TEST",
        total_stock=stock, unit_price=price, lead_time_days=lead,
        lifecycle_status=lifecycle, currency="CNY" if name != "mouser" else "USD",
        match_status="hit", is_available=True,
        raw_summary=f"{name}:测试"
    )


@pytest.mark.asyncio
async def test_merge_best_picks_max_stock_min_price_min_lead():
    service = SupplyDataService()
    service._lcsc = StubSource("lcsc", make_hit("lcsc", stock=120, price=6.50, lead=None, lifecycle="Unknown"))
    service._mouser = StubSource("mouser", make_hit("mouser", stock=18058, price=4.60, lead=7, lifecycle=""))
    service._digikey = StubSource("digikey", make_hit("digikey", stock=4034, price=54.66, lead=140, lifecycle="在售"))
    service._guanxintai = StubSource("guanxintai", make_hit("guanxintai", stock=33688, price=6.98))

    service._enabled_sources = [service._lcsc, service._mouser, service._digikey, service._guanxintai]

    result = await service.query_one("TEST")

    assert result.is_available is True
    assert result.total_stock == 33688  # max
    assert result.unit_price == 4.60  # min
    assert result.lead_time_days == 7  # min
    assert result.lifecycle_status == "在售"  # DigiKey priority
    assert result.supplier_count == 4
    assert result.match_status == "hit"


@pytest.mark.asyncio
async def test_merge_all_not_found_returns_unavailable():
    service = SupplyDataService()
    service._lcsc = StubSource("lcsc", None)
    service._mouser = StubSource("mouser", None)
    service._enabled_sources = [service._lcsc, service._mouser]

    result = await service.query_one("NONE")

    assert result.is_available is False
    assert result.match_status == "not_found"
    assert result.total_stock == 0


@pytest.mark.asyncio
async def test_merge_mixed_some_hit_some_not():
    service = SupplyDataService()
    service._lcsc = StubSource("lcsc", make_hit("lcsc", stock=120, price=6.50))
    service._mouser = StubSource("mouser", None)
    service._digikey = StubSource("digikey", None)
    service._enabled_sources = [service._lcsc, service._mouser, service._digikey]

    result = await service.query_one("MIX")

    assert result.is_available is True
    assert result.total_stock == 120
    assert result.supplier_count == 1
```

- [ ] **Step 2: 运行测试确认失败**

Run: `py -3.11 -m pytest tests\test_multi_source_supply.py::test_merge -q`

Expected: FAIL — service 仍只查 LCSC 单源

- [ ] **Step 3: 重写 SupplyDataService**

Rewrite `backend/app/services/supply_data.py` (替换现有内容):

```python
"""多源供应数据编排服务 — 并行查询 DigiKey/Mouser/观芯台/LCSC，最优合并。"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Optional

from sqlalchemy.orm import Session

from app.models.bom import BomItem
from app.services.supply_risk import evaluate_supply_risk
from app.config import settings
from .sources.base import SourceResult
from .sources.digikey import DigiKeySource
from .sources.guanxintai import GuanxintaiSource
from .sources.lcsc import LCSCSource
from .sources.mouser import MouserSource

logger = logging.getLogger(__name__)

LIFECYCLE_PRIORITY = {
    "digikey": 3,
    "mouser": 2,
}


@dataclass
class AggregatedResult:
    """供应数据聚合后的统一结果。"""

    mpn_queried: str = ""
    source_name: str = "多源聚合"
    match_status: str = "not_found"
    error_reason: str = ""
    raw_summary: str = ""
    total_stock: int = 0
    supplier_count: int = 0
    lead_time_days: Optional[int] = None
    unit_price: Optional[float] = None
    currency: str = "CNY"
    lifecycle_status: str = "Unknown"
    sources: list[SourceResult] = field(default_factory=list)
    is_available: bool = False


class SupplyDataService:
    """多源供应链实时数据编排服务。"""

    def __init__(self):
        self._lcsc = LCSCSource(request_delay=0.55)
        self._mouser = MouserSource()
        self._digikey = DigiKeySource()
        self._guanxintai = GuanxintaiSource()
        self._all_sources: list = [self._lcsc, self._mouser, self._digikey, self._guanxintai]
        self._enabled_sources: list = []
        self._initialized = False

    async def initialize(self):
        if not self._initialized:
            self._enabled_sources = [s for s in self._all_sources if s.is_configured]
            for s in self._all_sources:
                ok = await s.health_check()
                logger.info(f"SupplyDataService init: {s.source_name}={'OK' if ok else 'FAIL'}")
            self._initialized = True

    async def shutdown(self):
        for s in self._all_sources:
            await s.close()

    async def query_one(self, mpn: str) -> AggregatedResult:
        if not mpn:
            return AggregatedResult(
                mpn_queried=mpn,
                match_status="missing_mpn",
                error_reason="物料型号为空，无法查询供应数据",
            )
        sources = self._enabled_sources if self._enabled_sources else [self._lcsc]
        tasks = [s.query_by_mpn(mpn) for s in sources]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        source_results = [
            r for r in results
            if isinstance(r, SourceResult)
        ]
        exceptions = [r for r in results if isinstance(r, Exception)]
        for exc in exceptions:
            logger.error(f"Supply query exception: {exc}")
        return self._merge_best(mpn, source_results)

    def _merge_best(self, mpn: str, source_results: list[SourceResult]) -> AggregatedResult:
        hits = [r for r in source_results if r.is_available]

        merged = AggregatedResult(mpn_queried=mpn)
        merged.sources = source_results

        if not hits:
            merged.is_available = False
            statuses = [r.match_status for r in source_results]
            merged.match_status = statuses[0] if statuses else "not_found"
            merged.error_reason = "; ".join(r.error_reason for r in source_results if r.error_reason)
            return merged

        merged.is_available = True
        merged.match_status = "hit"
        merged.total_stock = max((r.total_stock for r in hits), default=0)
        merged.supplier_count = sum(1 for r in hits if r.total_stock > 0)

        valid_prices = [r.unit_price for r in hits if r.unit_price is not None]
        if valid_prices:
            merged.unit_price = min(valid_prices)

        valid_leads = [r.lead_time_days for r in hits if r.lead_time_days is not None]
        if valid_leads:
            merged.lead_time_days = min(valid_leads)

        merged.lifecycle_status = self._best_lifecycle(hits)
        merged.currency = self._resolve_currency(hits, merged.unit_price)
        merged.raw_summary = " ".join(
            f"{r.source}:{r.raw_summary or r.match_status}" for r in hits
        )
        return merged

    def _best_lifecycle(self, hits: list[SourceResult]) -> str:
        """取最可靠源的生命周期状态。DigiKey > Mouser > 其他。"""
        best = "Unknown"
        best_priority = -1
        for r in hits:
            if r.lifecycle_status and r.lifecycle_status != "Unknown":
                pri = LIFECYCLE_PRIORITY.get(r.source, 0)
                if pri > best_priority:
                    best = r.lifecycle_status
                    best_priority = pri
        return best

    def _resolve_currency(self, hits: list[SourceResult], min_price: Optional[float]) -> str:
        """取最低单价对应源的币种。"""
        if min_price is not None:
            for r in hits:
                if r.unit_price == min_price:
                    return r.currency or "CNY"
        return "CNY"

    async def query_batch(self, mpns: list[str], concurrency: int = 3) -> dict[str, AggregatedResult]:
        semaphore = asyncio.Semaphore(max(1, min(concurrency, 5)))

        async def _query_one(mpn: str) -> AggregatedResult:
            async with semaphore:
                return await self.query_one(mpn)

        valid_mpns = [mpn for mpn in mpns if mpn]
        tasks = [_query_one(mpn) for mpn in valid_mpns]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        output = {}
        for mpn, result in zip(valid_mpns, results):
            if isinstance(result, Exception):
                logger.error(f"Batch query failed for '{mpn}': {result}")
                output[mpn] = AggregatedResult(
                    mpn_queried=mpn,
                    match_status="request_failed",
                    error_reason=str(result),
                )
            else:
                output[mpn] = result
        return output

    def apply_to_bom_item(self, item: BomItem, aggregated: AggregatedResult, db: Session, save: bool = True) -> bool:
        if not aggregated.is_available:
            return False

        item.total_stock = aggregated.total_stock
        item.supplier_count = aggregated.supplier_count
        item.lead_time_days = aggregated.lead_time_days
        item.unit_price = aggregated.unit_price
        item.lifecycle_status = aggregated.lifecycle_status

        realtime_data = {
            "total_stock": aggregated.total_stock,
            "supplier_count": aggregated.supplier_count,
            "lead_time_days": aggregated.lead_time_days,
            "unit_price": aggregated.unit_price,
            "lifecycle_status": aggregated.lifecycle_status,
        }
        commonality_data = {
            "has_multi_source": aggregated.supplier_count >= 2,
            "is_major_brand": bool(item.normalized_brand or item.raw_brand),
            "is_standard_package": bool(
                item.raw_spec
                and any(pkg in item.raw_spec.lower() for pkg in ["0402", "0603", "0805", "1206", "sot-23", "soic", "qfn"])
            ),
        }
        supply = evaluate_supply_risk(item, [], realtime_data, commonality_data)
        item.production_risk_level = supply.production_risk_level
        item.production_risk_score = supply.production_risk_score
        item.lead_time_risk_weeks = supply.lead_time_risk_weeks
        item.eol_status = supply.eol_status
        item.supply_risk_tags = supply.supply_risk_tags
        item.supply_risk_reason = supply.supply_risk_reason
        item.procurement_suggestion = supply.procurement_suggestion
        item.commonality_score = supply.commonality_score

        if save:
            db.commit()
        return True
```

- [ ] **Step 4: 运行合并测试**

Run: `py -3.11 -m pytest tests\test_multi_source_supply.py::test_merge -q`

Expected: `3 passed`

- [ ] **Step 5: 运行全量后端测试**

Run: `py -3.11 -m pytest tests -q`

Expected: 全部通过（如有现存测试受影响则修复）

- [ ] **Step 6: 提交**

```powershell
git add backend\app\services\supply_data.py tests\test_multi_source_supply.py
git commit -m 'feat: multi-source parallel query with best-of-all merge'
```

---

### Task 5: API 层 sources 数组 + 部署脚本

**Files:**
- Modify: `backend/app/api/supply.py`
- Modify: `deploy-v3.2-mvp.ps1`
- Test: `tests/test_supply_api.py` (可选追加)

**Interfaces:**
- Modifies: `_result_payload` 新增 `sources` 数组
- Modifies: deploy 脚本新增 digikey.py/guanxintai.py/test_multi_source_supply.py

- [ ] **Step 1: 更新 _result_payload**

In `backend/app/api/supply.py`, modify `_result_payload`:

```python
def _result_payload(result: AggregatedResult) -> dict:
    return {
        "mpn_queried": result.mpn_queried,
        "source_name": result.source_name,
        "is_available": result.is_available,
        "match_status": result.match_status,
        "total_stock": result.total_stock,
        "supplier_count": result.supplier_count,
        "lead_time_days": result.lead_time_days,
        "unit_price": result.unit_price,
        "currency": result.currency,
        "lifecycle_status": result.lifecycle_status,
        "raw_summary": result.raw_summary,
        "error_reason": result.error_reason,
        "sources": [
            {
                "name": s.source,
                "match_status": s.match_status,
                "is_available": s.is_available,
                "total_stock": s.total_stock,
                "lead_time_days": s.lead_time_days,
                "unit_price": s.unit_price,
                "lifecycle_status": s.lifecycle_status,
                "raw_summary": s.raw_summary,
                "error_reason": s.error_reason,
            }
            for s in (result.sources or [])
        ],
    }
```

- [ ] **Step 2: 更新部署脚本**

In `deploy-v3.2-mvp.ps1`, add in the source copy section:

```powershell
Copy-Item (Join-Path $SRC "backend\app\services\sources\digikey.py") $targetSources -Force
Copy-Item (Join-Path $SRC "backend\app\services\sources\guanxintai.py") $targetSources -Force
```

And in the test files section:

```powershell
"test_multi_source_supply.py",
```

And update the version output:

```powershell
Write-Host "  v3.10 multi-source supply: DigiKey + Mouser + Guanxintai + LCSC best-of-all merge"
```

- [ ] **Step 3: 运行全量测试**

```powershell
py -3.11 -m pytest tests -q
```

Expected: 全部通过

- [ ] **Step 4: 提交**

```powershell
git add backend\app\api\supply.py deploy-v3.2-mvp.ps1
git commit -m 'feat: expose per-source detail in supply api payload'
```

---

### Task 6: 真实数据验证 + Bundle

**Files:**
- 临时脚本: `c:\Users\HAIER\.trae-cn\work\6a3a1656122fe7f887f6ea50\validate_v310_real_data.py` (不提交)

- [ ] **Step 1: 运行全量回归测试**

```powershell
py -3.11 -m pytest tests -q
```

Expected: 全部通过

- [ ] **Step 2: 真实多源验证**

Create and run `c:\Users\HAIER\.trae-cn\work\6a3a1656122fe7f887f6ea50\validate_v310_real_data.py`:

```python
import sys
from pathlib import Path
repo = Path(r"d:\1项目清单\交期风险排查\BOM-Risk-Analyzer-patch")
sys.path.insert(0, str(repo / "backend"))

from app.services.supply_data import SupplyDataService
import asyncio

async def main():
    svc = SupplyDataService()
    await svc.initialize()
    for mpn in ["STM32F103C8T6", "TL084CDR", "0603WAF1002T5E"]:
        result = await svc.query_one(mpn)
        print(f"\n=== {mpn} ===")
        print(f"  merged: stock={result.total_stock} price={result.unit_price} lead={result.lead_time_days}d life={result.lifecycle_status}")
        for s in result.sources:
            print(f"  [{s.source}] {s.match_status} | stock={s.total_stock} price={s.unit_price} lead={s.lead_time_days} life={s.lifecycle_status}")
    await svc.shutdown()

asyncio.run(main())
```

Required: 所有查询不跑异常，每个源的 match_status 如实报告（不伪造命中）.

- [ ] **Step 3: 生成 Bundle**

```powershell
git bundle create '..\BOM-Risk-Analyzer-v3.2-mvp.bundle' --all
git bundle verify '..\BOM-Risk-Analyzer-v3.2-mvp.bundle'
```

Required: `The bundle records a complete history.`

- [ ] **Step 4: 提交 (如有修改)**

```powershell
git status --short
# 只在有部署/配置修改时提交
```
