# v3.9 LCSC 真实供应数据接入 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 接入 LCSC 单源真实供应数据，让系统能查询、刷新和展示 BOM 物料的库存、价格、交期、生命周期和供应链风险。

**Architecture:** 后端收敛现有供应数据服务为 LCSC 单源 MVP，新增 `api/supply.py` 暴露查询、单行刷新、项目批量刷新和状态接口。前端在现有 BOM 风险明细表中展示供应数据并提供单行刷新入口，在 BOM 分析完成区提供项目级刷新入口。外部 API 失败时返回可解释状态，不清空旧字段，不改市场事件主风险。

**Tech Stack:** FastAPI、SQLAlchemy、SQLite、httpx、pytest、FastAPI TestClient、Vue 3 `<script setup>`、Element Plus、Axios、Vitest、Vue Test Utils、PowerShell 部署脚本。

## Global Constraints

- 只实现 v3.9：LCSC 单源真实供应数据接入 MVP。
- 不启用 Mouser、DigiKey 或其他需要 API Key 的供应商。
- 不新增数据库字段，不新增供应数据快照表；只写入现有 `BomItem` 供应链字段。
- 不自动禁选物料，不自动变更采购状态，不自动替换型号。
- 不改变 v3.8 市场趋势、事件复核和行动队列逻辑。
- 不把外部供应数据当作行情事件写入 `MarketEvent`。
- 单独刷新供应数据不直接修改 `risk_level`、`risk_score`、`risk_reason`。
- 外部接口不可用、未命中、超时或解析失败时，不清空旧供应字段。
- 真实数据验证必须报告真实状态，不伪造命中结果。
- 每个任务完成后运行对应测试并提交一次。

---

## File Structure

- Modify: `backend/app/services/sources/base.py`
  - 扩展 `SourceResult`，增加 `match_status`、`error_reason`、`raw_summary`，用于区分命中、未命中、请求失败、解析失败、超时等状态。
- Modify: `backend/app/services/sources/lcsc.py`
  - 保留 LCSC/JLCSearch 单源查询，增强错误状态和响应解析，不再把所有异常吞成 `None`。
- Modify: `backend/app/services/supply_data.py`
  - 将 v3.9 默认服务收敛为 LCSC 单源；保留聚合数据结构但补充状态字段、批量查询和不清空旧字段的写入规则。
- Create: `backend/app/api/supply.py`
  - 新增 `/api/supply/query`、`/api/supply/items/{item_id}/refresh`、`/api/supply/projects/{project_id}/refresh`、`/api/supply/projects/{project_id}/status`。
- Modify: `backend/app/main.py`
  - 挂载 `supply.router` 到 `/api/supply`。
- Modify: `backend/app/api/bom_project.py`
  - 项目明细 items 返回现有供应字段，供前端展示。
- Modify: `backend/app/api/risk_analysis.py`
  - 分析完成返回的 item payload 增加 `id`，让前端单行供应刷新可以定位并更新当前表格行。
- Create: `tests/test_supply_api.py`
  - 覆盖 provider 解析、单物料查询不写库、单行刷新写字段、失败不清空旧字段、批量刷新和状态统计。
- Create: `frontend/src/api/supply.js`
  - 前端供应数据 API client。
- Create or Verify: `frontend/src/api/bom.js`
  - 如果当前分支缺少该文件，则补齐 `BomAnalyze.vue` 已依赖的上传/分析 API client，使新增视图测试和应用构建可解析。
- Modify: `frontend/src/components/RiskDetailTable.vue`
  - 增加供应数据列、单行刷新按钮、刷新中和失败提示。
- Modify: `frontend/src/views/BomAnalyze.vue`
  - 分析完成区增加项目级“刷新供应数据”入口，刷新完成后更新当前结果。
- Create or Modify: `frontend/src/components/__tests__/RiskDetailTable.test.js`
  - 覆盖供应字段展示和单行刷新。
- Modify: `frontend/src/views/__tests__/BomAnalyze.test.js`
  - 覆盖项目级供应刷新按钮和失败提示；如现有测试文件不存在，则在任务中创建。
- Modify: `deploy-v3.2-mvp.ps1`
  - 复制新增后端 API、供应服务文件、测试和前端文件，运行新增测试，输出 v3.9 能力说明。

---

### Task 1: LCSC provider 状态化返回

**Files:**
- Modify: `backend/app/services/sources/base.py`
- Modify: `backend/app/services/sources/lcsc.py`
- Test: `tests/test_supply_api.py`

**Interfaces:**
- Produces dataclass fields on `SourceResult`:
  - `match_status: str`
  - `error_reason: str`
  - `raw_summary: str`
- Produces LCSC behavior:
  - `await LCSCSource().query_by_mpn(mpn: str) -> SourceResult`
  - Never returns `None` for normal query outcomes; returns `match_status` instead.

- [ ] **Step 1: 写 provider 失败测试**

Create `tests/test_supply_api.py` with this initial content:

```python
import pytest

from app.services.sources.base import SourceResult
from app.services.sources.lcsc import LCSCSource


class FakeResponse:
    def __init__(self, payload=None, status_code=200, json_error=None):
        self.payload = payload or {}
        self.status_code = status_code
        self.json_error = json_error

    def raise_for_status(self):
        if self.status_code >= 400:
            raise Exception(f"HTTP {self.status_code}")

    def json(self):
        if self.json_error:
            raise self.json_error
        return self.payload


class FakeClient:
    def __init__(self, response):
        self.response = response
        self.calls = []

    async def get(self, url, params=None):
        self.calls.append({"url": url, "params": params})
        return self.response


@pytest.mark.asyncio
async def test_lcsc_query_returns_hit_with_stock_price_and_summary():
    source = LCSCSource(request_delay=0)
    source._client = FakeClient(FakeResponse({
        "results": [{
            "lcsc": "C12345",
            "partNumber": "STM32F103C8T6",
            "manufacturer": "STMicroelectronics",
            "category": "MCU",
            "product_url": "https://example.test/C12345",
            "extra": {
                "quantity": 120,
                "whs-js": 80,
                "whs-zh": 40,
                "prices": [{"min_qty": 1, "max_qty": 9, "price": "12.34", "currency": "CNY"}],
                "moq": 1,
                "basic": True,
                "datasheet": {"pdf": "https://example.test/ds.pdf"},
            },
        }]
    }))

    result = await source.query_by_mpn("STM32F103C8T6")

    assert isinstance(result, SourceResult)
    assert result.source == "lcsc"
    assert result.match_status == "hit"
    assert result.is_available is True
    assert result.total_stock == 120
    assert result.supplier_count == 1
    assert result.unit_price == 12.34
    assert result.currency == "CNY"
    assert "库存120" in result.raw_summary


@pytest.mark.asyncio
async def test_lcsc_query_returns_not_found_without_exception():
    source = LCSCSource(request_delay=0)
    source._client = FakeClient(FakeResponse({"results": []}))

    result = await source.query_by_mpn("NO_SUCH_PART")

    assert result.match_status == "not_found"
    assert result.is_available is False
    assert result.total_stock == 0
    assert result.error_reason == "LCSC 暂未命中该型号"


@pytest.mark.asyncio
async def test_lcsc_query_returns_parse_failed_for_bad_json():
    source = LCSCSource(request_delay=0)
    source._client = FakeClient(FakeResponse(json_error=ValueError("bad json")))

    result = await source.query_by_mpn("BAD_JSON")

    assert result.match_status == "parse_failed"
    assert result.is_available is False
    assert "bad json" in result.error_reason
```

- [ ] **Step 2: 运行测试确认失败**

Run:

```powershell
py -3.11 -m pytest tests\test_supply_api.py -q
```

Expected: FAIL because `SourceResult` has no `match_status` / `supplier_count` fields and `LCSCSource` still returns `None` for failures.

- [ ] **Step 3: 扩展 SourceResult**

In `backend/app/services/sources/base.py`, update `SourceResult` to include these fields while preserving existing fields:

```python
@dataclass
class SourceResult:
    """统一的数据源查询结果，屏蔽不同 API 的字段差异。"""

    source: str
    mpn_queried: str
    mpn_matched: str = ""
    manufacturer: str = ""

    total_stock: int = 0
    supplier_count: int = 0
    stock_location: str = ""

    lead_time_days: Optional[int] = None
    lead_time_display: str = ""

    unit_price: Optional[float] = None
    price_breaks: list[dict] = field(default_factory=list)
    moq: int = 1
    currency: str = "USD"

    lifecycle_status: str = "Unknown"
    category: str = ""

    product_url: str = ""
    datasheet_url: str = ""

    match_status: str = "not_found"
    error_reason: str = ""
    raw_summary: str = ""
    raw_response: dict = field(default_factory=dict)
    is_available: bool = False
```

- [ ] **Step 4: 修改 LCSCSource 查询行为**

In `backend/app/services/sources/lcsc.py`, replace `query_by_mpn` with this behavior:

```python
async def query_by_mpn(self, mpn: str) -> SourceResult:
    clean = self.clean_mpn(mpn)
    if not clean:
        return SourceResult(
            source=self.source_name,
            mpn_queried=mpn,
            match_status="missing_mpn",
            error_reason="物料型号为空，无法查询 LCSC",
        )

    await self._rate_limit()
    client = await self._get_client()

    try:
        response = await client.get(
            f"{LCSC_API_BASE}/search",
            params={"q": clean, "limit": 5, "full": "true"},
        )
        response.raise_for_status()
    except TimeoutError as exc:
        logger.warning(f"LCSC query timeout for '{clean}': {exc}")
        return SourceResult(
            source=self.source_name,
            mpn_queried=mpn,
            match_status="timeout",
            error_reason=str(exc) or "LCSC 查询超时",
        )
    except Exception as exc:
        logger.warning(f"LCSC query failed for '{clean}': {exc}")
        return SourceResult(
            source=self.source_name,
            mpn_queried=mpn,
            match_status="request_failed",
            error_reason=str(exc) or "LCSC 请求失败",
        )

    try:
        data = response.json()
        results = data.get("results", [])
    except Exception as exc:
        return SourceResult(
            source=self.source_name,
            mpn_queried=mpn,
            match_status="parse_failed",
            error_reason=str(exc) or "LCSC 响应解析失败",
        )

    if not results:
        return SourceResult(
            source=self.source_name,
            mpn_queried=mpn,
            is_available=False,
            match_status="not_found",
            error_reason="LCSC 暂未命中该型号",
        )

    best = results[0]
    extra = best.get("extra", {}) or {}
    total_stock = int(extra.get("quantity", 0) or 0)
    warehouses = []
    for wh_key, wh_label in [("whs-js", "深圳"), ("whs-zh", "珠海"), ("whs-hk", "香港")]:
        q = int(extra.get(wh_key, 0) or 0)
        if q > 0:
            warehouses.append(f"{wh_label}:{q}")
    stock_location = "/".join(warehouses) if warehouses else ""

    prices = extra.get("prices", []) or []
    unit_price = None
    if prices and prices[0].get("price") not in (None, ""):
        unit_price = float(prices[0].get("price"))
    currency = prices[0].get("currency", "CNY") if prices else "CNY"
    price_breaks = [
        {
            "qty_min": p.get("min_qty", 0),
            "qty_max": p.get("max_qty", 0),
            "price": p.get("price", 0),
            "currency": p.get("currency", currency),
        }
        for p in prices
    ]
    moq = int(extra.get("moq", 1) or 1)
    is_basic = bool(extra.get("basic", False))
    supplier_count = 1 if total_stock > 0 else 0
    raw_summary = f"LCSC 命中 {best.get('lcsc', best.get('partNumber', clean))}，库存{total_stock}，币种{currency}"

    return SourceResult(
        source=self.source_name,
        mpn_queried=mpn,
        mpn_matched=best.get("lcsc", best.get("partNumber", "")),
        manufacturer=best.get("manufacturer", ""),
        total_stock=total_stock,
        supplier_count=supplier_count,
        stock_location=stock_location,
        lead_time_days=None,
        lead_time_display="现货" if total_stock > 0 else "需要订货",
        unit_price=unit_price,
        price_breaks=price_breaks,
        moq=moq,
        currency=currency,
        lifecycle_status="Unknown",
        category=best.get("category", ""),
        product_url=best.get("product_url", ""),
        datasheet_url=(extra.get("datasheet", {}) or {}).get("pdf", ""),
        match_status="hit",
        raw_summary=raw_summary,
        is_available=True,
        raw_response={"total_stock": total_stock, "is_basic": is_basic, **best},
    )
```

- [ ] **Step 5: 运行 Task 1 测试**

Run:

```powershell
py -3.11 -m pytest tests\test_supply_api.py -q
```

Expected: PASS for the three provider tests.

- [ ] **Step 6: 提交 Task 1**

```powershell
git add backend\app\services\sources\base.py backend\app\services\sources\lcsc.py tests\test_supply_api.py
git commit -m 'feat: normalize lcsc supply source status'
```

---

### Task 2: 后端供应数据 API 与写入规则

**Files:**
- Modify: `backend/app/services/supply_data.py`
- Create: `backend/app/api/supply.py`
- Modify: `backend/app/main.py`
- Test: `tests/test_supply_api.py`

**Interfaces:**
- Consumes: `SourceResult` from Task 1.
- Produces:
  - `GET /api/supply/query?mpn=<mpn>`
  - `POST /api/supply/items/{item_id}/refresh`
  - `POST /api/supply/projects/{project_id}/refresh?limit=50&concurrency=3`
  - `GET /api/supply/projects/{project_id}/status`
  - `SupplyDataService.query_one(mpn: str) -> AggregatedResult`
  - `SupplyDataService.apply_to_bom_item(item: BomItem, aggregated: AggregatedResult, db: Session, save: bool = True) -> bool`

- [ ] **Step 1: 追加 API 失败测试**

Append these tests to `tests/test_supply_api.py`:

```python
from datetime import datetime, timezone

from fastapi.testclient import TestClient

from app.database import SessionLocal, init_db
from app.main import app
from app.models.bom import BomItem, BomProject, RiskLevel
from app.services.supply_data import AggregatedResult

client = TestClient(app)


def _clean_supply_data():
    init_db()
    db = SessionLocal()
    db.query(BomItem).delete()
    db.query(BomProject).delete()
    db.commit()
    db.close()


def _seed_supply_project_with_item(part_number="STM32F103C8T6"):
    db = SessionLocal()
    try:
        project = BomProject(
            filename="supply-demo.xlsx",
            project_name="供应数据验证项目",
            total_items=1,
            items_analyzed=1,
            last_analysis_at=datetime.now(timezone.utc),
        )
        db.add(project)
        db.commit()
        db.refresh(project)
        item = BomItem(
            bom_upload_id=project.id,
            row_number=1,
            raw_part_number=part_number,
            raw_brand="ST",
            raw_category="MCU",
            normalized_brand="ST",
            normalized_category="MCU",
            risk_level=RiskLevel.YELLOW,
            risk_score=60,
            risk_reason="市场事件风险保留",
            total_stock=7,
            supplier_count=1,
            lead_time_days=30,
            unit_price=8.8,
            lifecycle_status="Active",
        )
        db.add(item)
        db.commit()
        db.refresh(item)
        return project.id, item.id
    finally:
        db.close()


class StubSupplyService:
    def __init__(self, result):
        self.result = result

    async def query_one(self, mpn):
        return self.result

    async def query_batch(self, mpns, concurrency=3):
        return {mpn: self.result for mpn in mpns}

    def apply_to_bom_item(self, item, aggregated, db, save=True):
        if not aggregated.is_available:
            return False
        item.total_stock = aggregated.total_stock
        item.supplier_count = aggregated.supplier_count
        item.lead_time_days = aggregated.lead_time_days
        item.unit_price = aggregated.unit_price
        item.lifecycle_status = aggregated.lifecycle_status
        item.production_risk_level = "green"
        item.production_risk_score = 10
        item.supply_risk_reason = "LCSC 有库存，供应风险低"
        item.procurement_suggestion = "按需采购"
        if save:
            db.commit()
        return True


def _override_supply_service(result):
    from app.api import supply
    app.dependency_overrides[supply.get_supply_service] = lambda: StubSupplyService(result)


def _clear_overrides():
    app.dependency_overrides.clear()


def test_supply_query_does_not_write_database():
    _clean_supply_data()
    project_id, item_id = _seed_supply_project_with_item()
    _override_supply_service(AggregatedResult(
        mpn_queried="STM32F103C8T6",
        source_name="LCSC",
        is_available=True,
        match_status="hit",
        total_stock=120,
        supplier_count=1,
        unit_price=12.34,
        currency="CNY",
        lifecycle_status="Unknown",
    ))

    resp = client.get("/api/supply/query", params={"mpn": "STM32F103C8T6"})

    assert resp.status_code == 200
    assert resp.json()["match_status"] == "hit"
    db = SessionLocal()
    try:
        item = db.query(BomItem).filter(BomItem.id == item_id).first()
        assert item.total_stock == 7
        assert item.unit_price == 8.8
    finally:
        db.close()
        _clear_overrides()


def test_refresh_item_writes_supply_fields_but_keeps_market_risk():
    _clean_supply_data()
    project_id, item_id = _seed_supply_project_with_item()
    _override_supply_service(AggregatedResult(
        mpn_queried="STM32F103C8T6",
        source_name="LCSC",
        is_available=True,
        match_status="hit",
        total_stock=120,
        supplier_count=1,
        unit_price=12.34,
        currency="CNY",
        lifecycle_status="Unknown",
    ))

    resp = client.post(f"/api/supply/items/{item_id}/refresh")

    assert resp.status_code == 200
    data = resp.json()
    assert data["updated"] is True
    assert data["item"]["total_stock"] == 120
    db = SessionLocal()
    try:
        item = db.query(BomItem).filter(BomItem.id == item_id).first()
        assert item.total_stock == 120
        assert item.unit_price == 12.34
        assert item.risk_level == RiskLevel.YELLOW
        assert item.risk_score == 60
        assert item.risk_reason == "市场事件风险保留"
    finally:
        db.close()
        _clear_overrides()


def test_refresh_item_failure_does_not_clear_old_supply_fields():
    _clean_supply_data()
    project_id, item_id = _seed_supply_project_with_item()
    _override_supply_service(AggregatedResult(
        mpn_queried="STM32F103C8T6",
        source_name="LCSC",
        is_available=False,
        match_status="not_found",
        error_reason="LCSC 暂未命中该型号",
    ))

    resp = client.post(f"/api/supply/items/{item_id}/refresh")

    assert resp.status_code == 200
    assert resp.json()["updated"] is False
    db = SessionLocal()
    try:
        item = db.query(BomItem).filter(BomItem.id == item_id).first()
        assert item.total_stock == 7
        assert item.supplier_count == 1
        assert item.unit_price == 8.8
        assert item.lifecycle_status == "Active"
    finally:
        db.close()
        _clear_overrides()
```

- [ ] **Step 2: 运行 API 测试确认失败**

Run:

```powershell
py -3.11 -m pytest tests\test_supply_api.py -q
```

Expected: FAIL because `app.api.supply` and `/api/supply/*` routes do not exist.

- [ ] **Step 3: 重构 SupplyDataService 为 LCSC 单源**

In `backend/app/services/supply_data.py`, update dataclass and core service methods to include status fields and avoid Mouser by default:

```python
@dataclass
class AggregatedResult:
    mpn_queried: str
    source_name: str = "LCSC"
    match_status: str = "not_found"
    error_reason: str = ""
    raw_summary: str = ""
    total_stock: int = 0
    supplier_count: int = 0
    lead_time_days: Optional[int] = None
    unit_price: Optional[float] = None
    currency: str = "CNY"
    lifecycle_status: str = "Unknown"
    sources: list[SourceResult] = field(default_factory=list)
    is_available: bool = False
```

Replace `__init__`, `query_one`, and `query_batch` with LCSC-only behavior:

```python
class SupplyDataService:
    def __init__(self):
        self._lcsc = LCSCSource(request_delay=0.55)
        self._initialized = False

    async def initialize(self):
        if not self._initialized:
            lcsc_ok = await self._lcsc.health_check()
            logger.info(f"SupplyDataService initialized: LCSC={'OK' if lcsc_ok else 'FAIL'}")
            self._initialized = True

    async def shutdown(self):
        await self._lcsc.close()

    async def query_one(self, mpn: str) -> AggregatedResult:
        if not mpn:
            return AggregatedResult(
                mpn_queried=mpn,
                match_status="missing_mpn",
                error_reason="物料型号为空，无法查询供应数据",
            )
        result = await self._lcsc.query_by_mpn(mpn)
        if not result or not result.is_available:
            return AggregatedResult(
                mpn_queried=mpn,
                match_status=result.match_status if result else "request_failed",
                error_reason=result.error_reason if result else "LCSC 查询未返回结果",
                raw_summary=result.raw_summary if result else "",
                sources=[result] if result else [],
                is_available=False,
            )
        return AggregatedResult(
            mpn_queried=mpn,
            source_name="LCSC",
            match_status=result.match_status,
            error_reason=result.error_reason,
            raw_summary=result.raw_summary,
            total_stock=result.total_stock,
            supplier_count=result.supplier_count,
            lead_time_days=result.lead_time_days,
            unit_price=result.unit_price,
            currency=result.currency,
            lifecycle_status=result.lifecycle_status or "Unknown",
            sources=[result],
            is_available=True,
        )

    async def query_batch(self, mpns: list[str], concurrency: int = 3) -> dict[str, AggregatedResult]:
        semaphore = asyncio.Semaphore(max(1, min(concurrency, 5)))

        async def _query_one(mpn: str) -> AggregatedResult:
            async with semaphore:
                return await self.query_one(mpn)

        tasks = [_query_one(mpn) for mpn in mpns if mpn]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        output = {}
        for mpn, result in zip([mpn for mpn in mpns if mpn], results):
            if isinstance(result, Exception):
                logger.error(f"Batch query failed for '{mpn}': {result}")
                output[mpn] = AggregatedResult(
                    mpn_queried=mpn,
                    match_status="request_failed",
                    error_reason=str(result),
                )
            else:
                output[mpn] = result
        return output
```

- [ ] **Step 4: 更新 apply_to_bom_item 写入规则**

In `backend/app/services/supply_data.py`, replace `apply_to_bom_item` with this rule:

```python
def apply_to_bom_item(self, item: BomItem, aggregated: AggregatedResult, db: Session, save: bool = True) -> bool:
    if not aggregated.is_available:
        return False

    item.total_stock = aggregated.total_stock
    item.supplier_count = aggregated.supplier_count
    item.lead_time_days = aggregated.lead_time_days
    item.unit_price = aggregated.unit_price
    item.lifecycle_status = aggregated.lifecycle_status

    realtime_data = {
        "total_stock": aggregated.total_stock,
        "supplier_count": aggregated.supplier_count,
        "lead_time_days": aggregated.lead_time_days,
        "unit_price": aggregated.unit_price,
        "lifecycle_status": aggregated.lifecycle_status,
    }
    commonality_data = {
        "has_multi_source": aggregated.supplier_count >= 2,
        "is_major_brand": bool(item.normalized_brand or item.raw_brand),
        "is_standard_package": bool(item.raw_spec and any(pkg in item.raw_spec.lower() for pkg in ["0402", "0603", "0805", "1206", "sot-23", "soic", "qfn"])),
    }
    supply = evaluate_supply_risk(item, [], realtime_data, commonality_data)
    item.production_risk_level = supply.production_risk_level
    item.production_risk_score = supply.production_risk_score
    item.lead_time_risk_weeks = supply.lead_time_risk_weeks
    item.eol_status = supply.eol_status
    item.supply_risk_tags = supply.supply_risk_tags
    item.supply_risk_reason = supply.supply_risk_reason
    item.procurement_suggestion = supply.procurement_suggestion
    item.commonality_score = supply.commonality_score

    if save:
        db.commit()
    return True
```

Also add this import at the top:

```python
from app.services.supply_risk import evaluate_supply_risk
```

- [ ] **Step 5: 创建 supply API**

Create `backend/app/api/supply.py`:

```python
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.bom import BomItem, BomProject
from app.services.supply_data import AggregatedResult, SupplyDataService

router = APIRouter()
_service: SupplyDataService | None = None


def get_supply_service() -> SupplyDataService:
    global _service
    if _service is None:
        _service = SupplyDataService()
    return _service


def _result_payload(result: AggregatedResult) -> dict:
    return {
        "mpn_queried": result.mpn_queried,
        "source_name": result.source_name,
        "is_available": result.is_available,
        "match_status": result.match_status,
        "total_stock": result.total_stock,
        "supplier_count": result.supplier_count,
        "lead_time_days": result.lead_time_days,
        "unit_price": result.unit_price,
        "currency": result.currency,
        "lifecycle_status": result.lifecycle_status,
        "raw_summary": result.raw_summary,
        "error_reason": result.error_reason,
    }


def _item_supply_payload(item: BomItem) -> dict:
    return {
        "id": item.id,
        "row_number": item.row_number,
        "raw_part_number": item.raw_part_number,
        "total_stock": item.total_stock,
        "supplier_count": item.supplier_count,
        "lead_time_days": item.lead_time_days,
        "unit_price": item.unit_price,
        "lifecycle_status": item.lifecycle_status,
        "production_risk_level": item.production_risk_level,
        "production_risk_score": item.production_risk_score,
        "lead_time_risk_weeks": item.lead_time_risk_weeks,
        "eol_status": item.eol_status,
        "supply_risk_tags": item.supply_risk_tags,
        "supply_risk_reason": item.supply_risk_reason,
        "procurement_suggestion": item.procurement_suggestion,
        "commonality_score": item.commonality_score,
    }


@router.get("/query")
async def query_supply(mpn: str = Query(..., min_length=1), service: SupplyDataService = Depends(get_supply_service)):
    result = await service.query_one(mpn)
    return _result_payload(result)


@router.post("/items/{item_id}/refresh")
async def refresh_item_supply(item_id: int, db: Session = Depends(get_db), service: SupplyDataService = Depends(get_supply_service)):
    item = db.query(BomItem).filter(BomItem.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="BOM item not found")
    mpn = item.raw_part_number or ""
    result = await service.query_one(mpn)
    updated = service.apply_to_bom_item(item, result, db, save=True)
    db.refresh(item)
    return {"updated": updated, "result": _result_payload(result), "item": _item_supply_payload(item)}


@router.post("/projects/{project_id}/refresh")
async def refresh_project_supply(
    project_id: int,
    limit: int = Query(50, ge=1, le=100),
    concurrency: int = Query(3, ge=1, le=5),
    db: Session = Depends(get_db),
    service: SupplyDataService = Depends(get_supply_service),
):
    project = db.query(BomProject).filter(BomProject.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="BOM project not found")
    items = (
        db.query(BomItem)
        .filter(BomItem.bom_upload_id == project_id, BomItem.raw_part_number.isnot(None))
        .order_by(BomItem.row_number)
        .limit(limit)
        .all()
    )
    mpns = [item.raw_part_number for item in items if item.raw_part_number]
    results = await service.query_batch(mpns, concurrency=concurrency)
    item_results = []
    updated_count = 0
    not_found_count = 0
    failed_count = 0
    for item in items:
        result = results.get(item.raw_part_number)
        if result is None:
            result = AggregatedResult(mpn_queried=item.raw_part_number or "", match_status="request_failed", error_reason="查询结果缺失")
        updated = service.apply_to_bom_item(item, result, db, save=False)
        if updated:
            updated_count += 1
        elif result.match_status == "not_found":
            not_found_count += 1
        else:
            failed_count += 1
        item_results.append({"item_id": item.id, "updated": updated, "result": _result_payload(result), "item": _item_supply_payload(item)})
    db.commit()
    return {
        "project_id": project_id,
        "processed_count": len(items),
        "updated_count": updated_count,
        "not_found_count": not_found_count,
        "failed_count": failed_count,
        "items": item_results,
    }


@router.get("/projects/{project_id}/status")
def get_project_supply_status(project_id: int, db: Session = Depends(get_db)):
    project = db.query(BomProject).filter(BomProject.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="BOM project not found")
    items = db.query(BomItem).filter(BomItem.bom_upload_id == project_id).all()
    items_with_mpn = [item for item in items if item.raw_part_number]
    items_with_supply_data = [
        item for item in items_with_mpn
        if (item.total_stock is not None and item.total_stock > 0) or item.lead_time_days or item.unit_price or (item.lifecycle_status and item.lifecycle_status != "Unknown")
    ]
    zero_stock_count = sum(1 for item in items_with_mpn if item.total_stock == 0)
    long_lead_count = sum(1 for item in items_with_mpn if item.lead_time_days and item.lead_time_days > 56)
    eol_count = sum(1 for item in items_with_mpn if item.eol_status in {"confirmed", "suspected"} or item.lifecycle_status in {"EOL", "Obsolete", "NRND"})
    coverage_rate = len(items_with_supply_data) / len(items_with_mpn) if items_with_mpn else 0
    return {
        "project_id": project_id,
        "total_items": len(items),
        "items_with_mpn": len(items_with_mpn),
        "items_with_supply_data": len(items_with_supply_data),
        "zero_stock_count": zero_stock_count,
        "long_lead_count": long_lead_count,
        "eol_count": eol_count,
        "coverage_rate": coverage_rate,
    }
```

- [ ] **Step 6: 挂载 router**

In `backend/app/main.py`, update imports and router registration:

```python
from app.api import events, bom_upload, risk_analysis, bom_project, intel_watch, market_inbox, preferred_library, market_trends, supply
```

Add:

```python
app.include_router(supply.router, prefix="/api/supply", tags=["supply"])
```

- [ ] **Step 7: 运行 Task 2 测试**

Run:

```powershell
py -3.11 -m pytest tests\test_supply_api.py -q
```

Expected: PASS for provider and API tests.

- [ ] **Step 8: 提交 Task 2**

```powershell
git add backend\app\services\supply_data.py backend\app\api\supply.py backend\app\main.py tests\test_supply_api.py
git commit -m 'feat: add supply refresh api'
```

---

### Task 3: 项目状态、BOM 明细供应字段和分析结果行 ID

**Files:**
- Modify: `backend/app/api/bom_project.py`
- Modify: `backend/app/api/risk_analysis.py`
- Test: `tests/test_supply_api.py`

**Interfaces:**
- Consumes: `GET /api/supply/projects/{project_id}/status` from Task 2.
- Produces: `GET /api/bom/projects/{project_id}` item payload includes:
  - `total_stock`
  - `supplier_count`
  - `lead_time_days`
  - `unit_price`
  - `lifecycle_status`
  - `commonality_score`
- Produces: `POST /api/risk/analyze/{upload_id}` item payload includes:
  - `id`

- [ ] **Step 1: 添加项目状态和明细字段测试**

Append to `tests/test_supply_api.py`:

```python
def test_project_supply_status_counts_coverage_zero_stock_long_lead_and_eol():
    _clean_supply_data()
    project_id, item_id = _seed_supply_project_with_item()
    db = SessionLocal()
    try:
        item = db.query(BomItem).filter(BomItem.id == item_id).first()
        item.total_stock = 0
        item.lead_time_days = 70
        item.lifecycle_status = "EOL"
        item.eol_status = "confirmed"
        db.commit()
    finally:
        db.close()

    resp = client.get(f"/api/supply/projects/{project_id}/status")

    assert resp.status_code == 200
    data = resp.json()
    assert data["total_items"] == 1
    assert data["items_with_mpn"] == 1
    assert data["items_with_supply_data"] == 1
    assert data["zero_stock_count"] == 1
    assert data["long_lead_count"] == 1
    assert data["eol_count"] == 1
    assert data["coverage_rate"] == 1.0


def test_bom_project_detail_includes_supply_fields():
    _clean_supply_data()
    project_id, item_id = _seed_supply_project_with_item()

    resp = client.get(f"/api/bom/projects/{project_id}")

    assert resp.status_code == 200
    item = resp.json()["items"][0]
    assert item["total_stock"] == 7
    assert item["supplier_count"] == 1
    assert item["lead_time_days"] == 30
    assert item["unit_price"] == 8.8
    assert item["lifecycle_status"] == "Active"


def test_risk_analysis_items_include_id_for_row_supply_refresh(monkeypatch):
    _clean_supply_data()
    project_id, item_id = _seed_supply_project_with_item()

    async def fake_query_batch(mpns, concurrency=3):
        return {}

    class FakeSupplyService:
        async def query_batch(self, mpns, concurrency=3):
            return await fake_query_batch(mpns, concurrency)

    from app.api import risk_analysis
    monkeypatch.setattr(risk_analysis, "get_supply_data_service", lambda: FakeSupplyService())

    resp = client.post(f"/api/risk/analyze/{project_id}")

    assert resp.status_code == 200
    item = resp.json()["items"][0]
    assert item["id"] == item_id
```

This third test intentionally depends on `risk_analysis._item_payload()` returning `id`; without it the frontend row refresh cannot update freshly analyzed rows.

- [ ] **Step 2: 运行测试确认明细字段和行 ID 失败**

Run:

```powershell
py -3.11 -m pytest tests\test_supply_api.py::test_bom_project_detail_includes_supply_fields tests\test_supply_api.py::test_risk_analysis_items_include_id_for_row_supply_refresh -q
```

Expected: FAIL because `bom_project.py` item payload does not return all v3.9 supply fields and `risk_analysis.py` analysis item payload does not return `id`.

- [ ] **Step 3: 修改 BOM 项目明细返回字段**

In `backend/app/api/bom_project.py`, inside `get_project()` item dict, add:

```python
"total_stock": i.total_stock,
"supplier_count": i.supplier_count,
"lead_time_days": i.lead_time_days,
"unit_price": i.unit_price,
"lifecycle_status": i.lifecycle_status,
"commonality_score": i.commonality_score,
```

Place these near existing `production_risk_*` fields.

- [ ] **Step 4: 修改分析结果返回行 ID**

In `backend/app/api/risk_analysis.py`, inside `_item_payload()`, add the item database id at the top of the payload dict:

```python
payload = {
    "id": item.id,
    "row_number": item.row_number,
    "raw_part_number": item.raw_part_number,
```

Do not remove existing supply fields. This is required because `RiskDetailTable` refresh emits an updated item by database `id`, and `BomAnalyze.handleSupplyRefreshed()` replaces the matching row by `id`.

- [ ] **Step 5: 运行 Task 3 测试**

Run:

```powershell
py -3.11 -m pytest tests\test_supply_api.py -q
```

Expected: PASS.

- [ ] **Step 6: 提交 Task 3**

```powershell
git add backend\app\api\bom_project.py backend\app\api\risk_analysis.py tests\test_supply_api.py
git commit -m 'feat: expose bom supply data status'
```

---

### Task 4: 前端供应数据展示和刷新入口

**Files:**
- Create: `frontend/src/api/supply.js`
- Create or Verify: `frontend/src/api/bom.js`
- Modify: `frontend/src/components/RiskDetailTable.vue`
- Modify: `frontend/src/views/BomAnalyze.vue`
- Test: `frontend/src/components/__tests__/RiskDetailTable.test.js`
- Test: `frontend/src/views/__tests__/BomAnalyze.test.js`

**Interfaces:**
- Consumes backend API through Axios base `/api`:
  - `POST /supply/items/{itemId}/refresh`
  - `POST /supply/projects/{projectId}/refresh`
- Consumes analysis result item `id` from Task 3.
- Produces frontend API:
  - `refreshSupplyItem(itemId)`
  - `refreshSupplyProject(projectId, params)`
- Produces UI behavior:
  - Per-row refresh emits `supply-refreshed` with updated item payload.
  - Project refresh merges returned item payloads into `result.value.items` by `item.id`, so the current table updates without a full page reload.

- [ ] **Step 1: 创建前端 API client**

Create `frontend/src/api/supply.js`:

```javascript
import client from './client'

export function querySupply(mpn) {
  return client.get('/supply/query', { params: { mpn } })
}

export function refreshSupplyItem(itemId) {
  return client.post(`/supply/items/${itemId}/refresh`)
}

export function refreshSupplyProject(projectId, params = {}) {
  return client.post(`/supply/projects/${projectId}/refresh`, null, { params })
}

export function getSupplyProjectStatus(projectId) {
  return client.get(`/supply/projects/${projectId}/status`)
}
```

- [ ] **Step 2: 补齐或确认现有 BOM API client**

Check whether `frontend/src/api/bom.js` exists. If it is missing, create it with the API functions already imported by `BomAnalyze.vue`:

```javascript
import client from './client'

export function uploadBom(file, projectName = '') {
  const formData = new FormData()
  formData.append('file', file)
  if (projectName) formData.append('project_name', projectName)
  return client.post('/bom/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}

export function uploadBomBatch(files) {
  const formData = new FormData()
  files.forEach(file => formData.append('files', file))
  return client.post('/bom/upload-batch', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}

export function analyzeBom(uploadId) {
  return client.post(`/risk/analyze/${uploadId}`)
}

export function analyzeAll() {
  return client.post('/risk/analyze-all')
}

export function listBomProjects() {
  return client.get('/bom/projects')
}

export function getBomProject(projectId) {
  return client.get(`/bom/projects/${projectId}`)
}
```

`/bom/projects` and `/bom/projects/{projectId}` are served by `bom_project.router`, which is mounted under `/api/bom`.

If the file already exists, do not change it in this step.

- [ ] **Step 3: 写 RiskDetailTable 失败测试**

Create or update `frontend/src/components/__tests__/RiskDetailTable.test.js` with this supply-specific test:

```javascript
import { mount, flushPromises } from '@vue/test-utils'
import { describe, expect, it, vi, beforeEach } from 'vitest'
import RiskDetailTable from '../RiskDetailTable.vue'
import * as supplyApi from '../../api/supply'

vi.mock('../../api/supply', () => ({
  refreshSupplyItem: vi.fn()
}))

function mountTable(items) {
  return mount(RiskDetailTable, {
    props: { items },
    global: {
      stubs: {
        V32EvidencePanel: true,
        ElTable: { template: '<div><slot /></div>' },
        ElTableColumn: { template: '<div><slot :row="mockRow" /></div>', data: () => ({ mockRow: items[0] }) },
        ElTag: { template: '<span><slot /></span>' },
        ElButton: { template: '<button @click="$emit(\'click\')"><slot /></button>' },
        ElPopover: { template: '<div><slot name="reference" /><slot /></div>' }
      }
    }
  })
}

describe('RiskDetailTable supply data', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('shows supply fields and refreshes one row', async () => {
    supplyApi.refreshSupplyItem.mockResolvedValue({
      data: {
        updated: true,
        item: {
          id: 10,
          total_stock: 120,
          supplier_count: 1,
          lead_time_days: 14,
          unit_price: 12.34,
          lifecycle_status: 'Unknown',
          supply_risk_reason: 'LCSC 有库存，供应风险低'
        }
      }
    })
    const wrapper = mountTable([{
      id: 10,
      row_number: 1,
      raw_part_number: 'STM32F103C8T6',
      raw_brand: 'ST',
      raw_category: 'MCU',
      risk_level: 'yellow',
      total_stock: 7,
      supplier_count: 1,
      lead_time_days: 30,
      unit_price: 8.8,
      lifecycle_status: 'Active',
      production_risk_level: 'yellow',
      eol_status: 'none'
    }])

    expect(wrapper.text()).toContain('库存')
    expect(wrapper.text()).toContain('7')
    await wrapper.find('[data-testid="refresh-supply-item"]').trigger('click')
    await flushPromises()

    expect(supplyApi.refreshSupplyItem).toHaveBeenCalledWith(10)
    expect(wrapper.emitted('supply-refreshed')).toBeTruthy()
  })
})
```

- [ ] **Step 4: 运行前端测试确认失败**

Run:

```powershell
npm run test -- src/components/__tests__/RiskDetailTable.test.js
```

Expected: FAIL because supply API import and refresh UI do not exist.

- [ ] **Step 5: 修改 RiskDetailTable**

In `frontend/src/components/RiskDetailTable.vue`, import API and message:

```javascript
import { ElMessage } from 'element-plus'
import { refreshSupplyItem } from '../api/supply'
```

Add emit and state after props:

```javascript
const emit = defineEmits(['supply-refreshed'])
const refreshingSupplyIds = ref(new Set())
```

Add helper functions:

```javascript
function displayValue(value) {
  return value === null || value === undefined || value === '' ? '暂无' : value
}

function supplyText(row) {
  const stock = displayValue(row.total_stock)
  const suppliers = displayValue(row.supplier_count)
  const lead = row.lead_time_days ? `${row.lead_time_days}天` : '暂无交期'
  const price = row.unit_price ? `${row.unit_price}` : '暂无价格'
  return `库存 ${stock} / 来源 ${suppliers} / ${lead} / ${price}`
}

async function refreshRowSupply(row) {
  if (!row.id) return
  refreshingSupplyIds.value = new Set([...refreshingSupplyIds.value, row.id])
  try {
    const { data } = await refreshSupplyItem(row.id)
    if (data.updated) {
      ElMessage.success('供应数据已刷新')
      emit('supply-refreshed', data.item)
    } else {
      ElMessage.warning(data.result?.error_reason || '供应数据暂不可用')
    }
  } catch (error) {
    ElMessage.error(error?.response?.data?.detail || '供应数据刷新失败')
  } finally {
    const next = new Set(refreshingSupplyIds.value)
    next.delete(row.id)
    refreshingSupplyIds.value = next
  }
}
```

Add table columns near existing production risk columns:

```vue
<el-table-column label="供应数据" min-width="260">
  <template #default="{ row }">
    <div class="supply-cell">
      <span>{{ supplyText(row) }}</span>
      <span class="supply-life">生命周期：{{ displayValue(row.lifecycle_status) }}</span>
      <el-button
        size="small"
        link
        type="primary"
        data-testid="refresh-supply-item"
        :loading="refreshingSupplyIds.has(row.id)"
        @click="refreshRowSupply(row)"
      >
        刷新供应数据
      </el-button>
    </div>
  </template>
</el-table-column>
```

Add styles:

```css
.supply-cell {
  display: flex;
  flex-direction: column;
  gap: 4px;
  font-size: 12px;
}

.supply-life {
  color: #909399;
}
```

- [ ] **Step 6: 修改 BomAnalyze 项目级刷新**

In `frontend/src/views/BomAnalyze.vue`, import API:

```javascript
import { refreshSupplyProject } from '../api/supply'
```

Add state:

```javascript
const refreshingProjectSupply = ref(false)
const supplyRefreshSummary = ref(null)
```

Add handlers:

```javascript
function handleSupplyRefreshed(updatedItem) {
  if (!result.value?.items || !updatedItem?.id) return
  result.value.items = result.value.items.map(item => item.id === updatedItem.id ? { ...item, ...updatedItem } : item)
}

function applyProjectSupplyItems(items = []) {
  if (!result.value?.items?.length) return
  const updatedById = new Map(
    items
      .filter(entry => entry.updated && entry.item?.id)
      .map(entry => [entry.item.id, entry.item])
  )
  if (!updatedById.size) return
  result.value.items = result.value.items.map(item => {
    const updated = updatedById.get(item.id)
    return updated ? { ...item, ...updated } : item
  })
}

async function refreshCurrentProjectSupply() {
  if (!currentUploadId.value) return
  refreshingProjectSupply.value = true
  try {
    const { data } = await refreshSupplyProject(currentUploadId.value, { limit: 50, concurrency: 3 })
    supplyRefreshSummary.value = data
    applyProjectSupplyItems(data.items || [])
    ElMessage.success(`供应数据刷新完成：更新 ${data.updated_count} 条，失败 ${data.failed_count} 条`)
  } catch (error) {
    ElMessage.error(error?.response?.data?.detail || '项目供应数据刷新失败')
  } finally {
    refreshingProjectSupply.value = false
  }
}
```

Update RiskDetailTable usage:

```vue
<RiskDetailTable :items="filteredItems" @supply-refreshed="handleSupplyRefreshed" />
```

Add project refresh button near result header:

```vue
<el-button size="small" :loading="refreshingProjectSupply" @click="refreshCurrentProjectSupply">
  刷新供应数据
</el-button>
<el-alert
  v-if="supplyRefreshSummary"
  :title="`供应数据刷新：处理 ${supplyRefreshSummary.processed_count} 条，更新 ${supplyRefreshSummary.updated_count} 条，失败 ${supplyRefreshSummary.failed_count} 条`"
  type="info"
  show-icon
  :closable="false"
  style="margin: 12px 0"
/>
```

- [ ] **Step 7: 写 BomAnalyze 项目级刷新测试**

Create `frontend/src/views/__tests__/BomAnalyze.test.js` with this focused test file:

```javascript
import { mount, flushPromises } from '@vue/test-utils'
import { describe, expect, it, vi, beforeEach } from 'vitest'
import BomAnalyze from '../BomAnalyze.vue'
import * as bomApi from '../../api/bom'
import * as supplyApi from '../../api/supply'

vi.mock('../../api/bom', () => ({
  uploadBom: vi.fn(),
  uploadBomBatch: vi.fn(),
  analyzeBom: vi.fn(),
  analyzeAll: vi.fn()
}))

vi.mock('../../api/supply', () => ({
  refreshSupplyProject: vi.fn()
}))

const push = vi.fn()
vi.mock('vue-router', () => ({
  useRouter: () => ({ push })
}))

vi.mock('element-plus', () => ({
  ElMessage: { success: vi.fn(), error: vi.fn(), warning: vi.fn() }
}))

const stubs = {
  BomUploader: {
    emits: ['upload'],
    template: '<button data-testid="upload-one" @click="$emit(\'upload\', new File([\'x\'], \'bom.xlsx\'), \'demo\')">upload</button>'
  },
  ProgressSteps: true,
  RiskSummary: true,
  ManualEventQuickAdd: true,
  RiskDetailTable: {
    props: ['items'],
    emits: ['supply-refreshed'],
    template: '<div data-testid="risk-detail">{{ items.map(i => i.total_stock).join(\',\') }}</div>'
  },
  'el-alert': { props: ['title'], template: '<div>{{ title }}<slot /></div>' },
  'el-button': { props: ['loading'], emits: ['click'], template: '<button v-bind="$attrs" :disabled="loading" @click="$emit(\'click\')"><slot /></button>' },
  'el-divider': true,
  'el-tag': { template: '<span><slot /></span>' },
  'el-result': true,
  'el-icon': true
}

function mountPage() {
  return mount(BomAnalyze, { global: { stubs } })
}

describe('BomAnalyze supply refresh', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    push.mockReset()
  })

  it('refreshes project supply data and updates current table rows', async () => {
    bomApi.uploadBom.mockResolvedValue({ data: { upload_id: 77 } })
    bomApi.analyzeBom.mockResolvedValue({
      data: {
        upload_id: 77,
        total_items: 1,
        summary: { red: 0, yellow: 1, green: 0, gray: 0 },
        items: [{ id: 10, row_number: 1, raw_part_number: 'STM32F103C8T6', risk_level: 'yellow', total_stock: 7 }]
      }
    })
    supplyApi.refreshSupplyProject.mockResolvedValue({
      data: {
        processed_count: 1,
        updated_count: 1,
        failed_count: 0,
        items: [{ updated: true, item: { id: 10, total_stock: 120, supplier_count: 1, lifecycle_status: 'Unknown' } }]
      }
    })

    const wrapper = mountPage()
    await wrapper.find('[data-testid="upload-one"]').trigger('click')
    await flushPromises()
    await new Promise(resolve => setTimeout(resolve, 600))
    await flushPromises()

    expect(wrapper.text()).toContain('分析完成')
    expect(wrapper.text()).toContain('7')

    await wrapper.find('[data-testid="refresh-supply-project"]').trigger('click')
    await flushPromises()

    expect(supplyApi.refreshSupplyProject).toHaveBeenCalledWith(77, { limit: 50, concurrency: 3 })
    expect(wrapper.text()).toContain('供应数据刷新：处理 1 条，更新 1 条，失败 0 条')
    expect(wrapper.text()).toContain('120')
  })
})
```

- [ ] **Step 8: 给项目刷新按钮添加 test id**

In the project refresh button added to `BomAnalyze.vue`, include `data-testid="refresh-supply-project"`:

```vue
<el-button
  size="small"
  data-testid="refresh-supply-project"
  :loading="refreshingProjectSupply"
  @click="refreshCurrentProjectSupply"
>
  刷新供应数据
</el-button>
```

- [ ] **Step 9: 运行前端相关测试**

Run:

```powershell
npm run test -- src/components/__tests__/RiskDetailTable.test.js src/views/__tests__/BomAnalyze.test.js
```

Expected: PASS.

- [ ] **Step 10: 提交 Task 4**

```powershell
git add frontend\src\api\supply.js frontend\src\api\bom.js frontend\src\components\RiskDetailTable.vue frontend\src\views\BomAnalyze.vue frontend\src\components\__tests__\RiskDetailTable.test.js frontend\src\views\__tests__\BomAnalyze.test.js
git commit -m 'feat: show and refresh supply data in bom view'
```

---

### Task 5: 部署脚本、真实数据验证和 bundle

**Files:**
- Modify: `deploy-v3.2-mvp.ps1`
- Create temp only: `validate_v39_supply_real_data.py` in working folder during execution; do not commit temp script.

**Interfaces:**
- Consumes all prior backend and frontend interfaces.
- Produces updated deployment script and final bundle.

- [ ] **Step 1: 更新部署脚本复制后端文件**

In `deploy-v3.2-mvp.ps1`, add after existing API copy lines:

```powershell
Copy-Item (Join-Path $SRC "backend\app\api\supply.py") $targetApi -Force
```

Add compile file:

```powershell
"app\api\supply.py",
```

Add service source copies if not already covered:

```powershell
$targetSources = Join-Path $DST "backend\app\services\sources"
New-Item -ItemType Directory -Path $targetSources -Force | Out-Null
Copy-Item (Join-Path $SRC "backend\app\services\sources\base.py") $targetSources -Force
Copy-Item (Join-Path $SRC "backend\app\services\sources\lcsc.py") $targetSources -Force
Copy-Item (Join-Path $SRC "backend\app\services\supply_data.py") (Join-Path $DST "backend\app\services\supply_data.py") -Force
Copy-Item (Join-Path $SRC "backend\app\services\supply_risk.py") (Join-Path $DST "backend\app\services\supply_risk.py") -Force
```

- [ ] **Step 2: 更新部署脚本复制测试和前端文件**

Add test file to `$testFiles`:

```powershell
"test_supply_api.py",
```

Add frontend files to `$frontendFiles`:

```powershell
"src\api\supply.js",
"src\api\bom.js",
"src\components\RiskDetailTable.vue",
"src\components\__tests__\RiskDetailTable.test.js",
"src\views\BomAnalyze.vue",
"src\views\__tests__\BomAnalyze.test.js",
```

Add frontend test command arguments:

```powershell
src/components/__tests__/RiskDetailTable.test.js src/views/__tests__/BomAnalyze.test.js
```

Add installed capability output:

```powershell
Write-Host "  v3.9 LCSC supply data: real query, item refresh, project refresh, supply coverage status"
```

- [ ] **Step 3: 运行全量后端测试**

Run:

```powershell
py -3.11 -m pytest tests -q
```

Expected: PASS with all backend tests, including `tests/test_supply_api.py`.

- [ ] **Step 4: 运行前端相关测试**

Run:

```powershell
npm run test -- src/components/__tests__/RiskDetailTable.test.js src/views/__tests__/BomAnalyze.test.js src/views/__tests__/MarketTrends.test.js
```

Expected: PASS.

- [ ] **Step 5: 真实数据验证脚本**

Create a temporary script in the working folder named `validate_v39_supply_real_data.py` with this content:

```python
from pathlib import Path
import sys

repo_root = Path.cwd()
sys.path.insert(0, str(repo_root / "backend"))

from fastapi.testclient import TestClient
from app.database import init_db
from app.main import app

init_db()
client = TestClient(app)

mpns = ["STM32F103C8T6", "0603WAF1002T5E", "NO_SUCH_PART_V39_000"]
for mpn in mpns:
    resp = client.get("/api/supply/query", params={"mpn": mpn})
    print("query", mpn, resp.status_code, resp.json().get("match_status"), resp.json().get("error_reason", ""))

projects = client.get("/api/bom/projects").json().get("projects", [])
if projects:
    project_id = projects[0]["id"]
    status_resp = client.get(f"/api/supply/projects/{project_id}/status")
    print("status", project_id, status_resp.status_code, status_resp.json())
else:
    print("status", "no_project", "skip")
```

Run:

```powershell
py -3.11 'c:\Users\HAIER\.trae-cn\work\6a3a1656122fe7f887f6ea50\validate_v39_supply_real_data.py'
```

Expected: Each query returns HTTP 200 and a truthful `match_status` such as `hit`, `not_found`, `request_failed`, `timeout`, or `parse_failed`. If LCSC or network is unavailable, record the returned failure status rather than changing tests to fake success.

- [ ] **Step 6: 提交 Task 5 代码变更**

Commit the deployment script before generating the bundle so the bundle contains the final v3.9 commit:

```powershell
git add deploy-v3.2-mvp.ps1
git commit -m 'chore: deploy lcsc supply data v39'
```

- [ ] **Step 7: 更新 bundle**

Run from repo root after the deploy-script commit:

```powershell
git bundle create '..\BOM-Risk-Analyzer-v3.2-mvp.bundle' --all ; git bundle verify '..\BOM-Risk-Analyzer-v3.2-mvp.bundle'
```

Expected: bundle verification reports `is okay` and `master` / `HEAD` point to the final v3.9 commit.

If bundle is outside the git repository, do not add it to git; report its path and verification output in the final response.

---

## Self-Review

Spec coverage:

- LCSC 单源 provider：Task 1。
- 单物料查询不写库：Task 2。
- 单 BOM 物料刷新写入现有字段：Task 2。
- 未命中、失败、解析异常不清空旧字段：Task 1 and Task 2。
- BOM 项目批量刷新和状态接口：Task 2 and Task 3。
- BOM 明细供应字段展示：Task 3 and Task 4。
- 分析结果携带 `id`，支持前端按行刷新后合并：Task 3。
- 前端单行和项目级刷新：Task 4；项目级刷新会把后端返回的 item payload 合并回当前表格。
- 部署脚本、测试、真实数据验证、bundle：Task 5；bundle 在最终提交之后生成。
- 不启用 Mouser/DigiKey、不新增字段、不自动禁选、不改 MarketEvent：Global Constraints and Task 2 write rules。

Placeholder scan:

- No `TBD` or `TODO` placeholders are used.
- Every task has exact files, interfaces, commands, expected results, and commit command.

Type consistency:

- `SourceResult.match_status` is defined in Task 1 and consumed by Task 2.
- `AggregatedResult` contains the same status and supply fields returned by `api/supply.py`.
- Project refresh results include both `result` metadata and `item` supply payload; Task 4 consumes `entry.item.id` to update current table rows.
- Frontend `refreshSupplyItem` and `refreshSupplyProject` paths match backend routes after the Axios base `/api` prefix.
- `BomAnalyze.vue` already imports `../api/bom`; Task 4 explicitly creates or verifies that client before adding `BomAnalyze.test.js`.
