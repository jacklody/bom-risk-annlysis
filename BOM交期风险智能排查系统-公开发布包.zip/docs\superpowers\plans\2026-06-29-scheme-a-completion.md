# 方案 A 系统闭环补齐 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 补齐当前 BOM 风险预警系统的可用闭环：行情源、收件箱、事件中心、趋势预警、多源供应和 BOM 详情体验。

**Architecture:** 复用现有 FastAPI + SQLAlchemy + Vue 3 架构，不重构主链路；后端补齐结构化状态、影响反查、解析词库和可审计 payload，前端补齐页面展示、刷新、跳转和空态。外部授权类能力登记为待配置，不阻塞本地可验收闭环。

**Tech Stack:** Python 3.11、FastAPI、SQLAlchemy、pytest、httpx、BeautifulSoup、Vue 3、Element Plus、Axios、Vitest。

## Delivery Status

方案 A 已完成开发、回归测试、前端生产构建和后端启动验收。当前收尾状态：功能闭环完成，外部授权类来源按计划仅登记配置状态，不伪造成稳定自动抓取能力。

最近一轮验收结果：

- 后端关键回归：`70 passed`
- 前端 Vitest：`41 passed`
- 前端生产构建：`npm run build` 通过
- 后端启动验收：`/api/health`、BOM 项目列表、风险报告、事件中心、趋势预警摘要、媒体源接口均可访问

## Global Constraints

- 只做方案 A：当前系统闭环补齐。
- 微信公众号/外部授权类来源只登记状态，不伪造成稳定自动抓取。
- 公众号、媒体、传闻类来源保留可信度降权，不允许单一低可信源直接触发强红色风险。
- 供应源失败不清空旧供应字段。
- 单独刷新供应数据不改市场风险等级；完整 BOM 风险分析可以综合市场事件和供应风险。
- 密钥只允许保存在 `backend/.env`，文档只写变量名。
- 每个功能补齐必须有回归测试或接口/构建验证。

---

## File Structure

- Modify: `backend/app/knowledge/media_sources.py`：媒体源注册表与状态字典。
- Modify: `backend/app/services/media_crawler.py`：注册表驱动采集和待接入源状态。
- Modify: `backend/app/api/events.py`：媒体源、事件状态、影响反查、来源链路接口。
- Modify: `backend/app/api/market_inbox.py`、`backend/app/services/upstream/market_inbox_service.py`：收件箱解析、扫描、影响返回。
- Modify: `backend/app/services/upstream/market_notice_parser.py`、`category_classifier.py`、`brand_category_map.py`：品牌/品类/事件词库增强。
- Modify: `backend/app/api/market_trends.py`：趋势、验证、行动队列接口补齐。
- Modify: `backend/app/api/supply.py`、`backend/app/services/supply_data.py`：多源供应明细和失败状态可审计。
- Modify: `backend/app/api/risk_analysis.py`、`backend/app/services/supply_risk.py`：风险原因、标签、证据字段统一。
- Modify: `frontend/src/api/*.js`：补齐前端 API client。
- Modify: `frontend/src/views/*.vue`：事件中心、趋势预警、行情收件箱、BOM 详情展示收尾。
- Test: `tests/test_media_sources.py`、`tests/test_market_inbox_api.py`、`tests/test_market_events_api.py`、`tests/test_market_trends_api.py`、`tests/test_supply_api.py`、前端 Vitest。

---

### Task 1: 媒体源状态与采集闭环

**Files:**
- Modify: `backend/app/knowledge/media_sources.py`
- Modify: `backend/app/services/media_crawler.py`
- Modify: `backend/app/api/events.py`
- Test: `tests/test_media_sources.py`

**Interfaces:**
- Produces: `GET /api/events/media-sources`
- Produces: `POST /api/events/collect-media` with optional `source_id`
- Produces: 每个 source 返回 `source_id/name/crawler_strategy/status/confidence_base/notes`。

- [x] Step 1: 写测试：媒体源接口必须包含芯师爷、半导体行业观察、国际电子商情、满天芯、EEWorld、芯智讯、立创商城/JLCSearch。
- [x] Step 2: 写测试：manual_forward/wechat_feed/playwright_required 源不执行直接 HTTP 抓取，返回 `status=waiting_for_manual_forward` 或 `waiting_for_configuration`。
- [x] Step 3: 实现缺失字段和接口返回。
- [x] Step 4: 运行 `pytest tests/test_media_sources.py -q`。

### Task 2: 行情收件箱解析与历史 BOM 扫描增强

**Files:**
- Modify: `backend/app/services/upstream/market_notice_parser.py`
- Modify: `backend/app/services/upstream/category_classifier.py`
- Modify: `backend/app/services/upstream/market_inbox_service.py`
- Modify: `backend/app/api/market_inbox.py`
- Test: `tests/test_market_notice_parser.py`
- Test: `tests/test_market_inbox_api.py`

**Interfaces:**
- Produces: 收件箱提交返回 `signals/events_created/scan_summary/top_impacted_items`。
- Produces: 自动扫描按品牌 + 归一品类命中历史 BOM，避免同品类不同品牌误报。

- [x] Step 1: 补测试：薄膜电容、安规电容、铝电解、钽电容、MOSFET、IGBT、PCB、MCU、DRAM/SDRAM/NAND 的涨价/缺货/交期延长文本可解析。
- [x] Step 2: 补测试：低置信来源只进入待复核，不直接打红。
- [x] Step 3: 实现词库和扫描结果字段。
- [x] Step 4: 运行 `pytest tests/test_market_notice_parser.py tests/test_market_inbox_api.py -q`。

### Task 3: 事件中心增强运营闭环

**Files:**
- Modify: `backend/app/api/events.py`
- Modify: `backend/app/models/event.py`
- Modify: `frontend/src/api/events.js`
- Modify: `frontend/src/views/MarketEvents.vue`
- Test: `tests/test_market_events_api.py`
- Test: `frontend/src/views/__tests__/MarketEvents.test.js`

**Interfaces:**
- Produces: `PATCH /api/events/{event_id}/status`
- Produces: `GET /api/events/{event_id}/impact`
- Produces: `GET /api/events/{event_id}/source-signal`

- [x] Step 1: 写/补后端测试：启用、停用、影响项目、来源链路。
- [x] Step 2: 实现或修复后端接口。
- [x] Step 3: 补前端 API 和详情抽屉展示。
- [x] Step 4: 运行后端与前端事件测试。

### Task 4: 趋势预警与预测验证闭环

**Files:**
- Modify: `backend/app/api/market_trends.py`
- Modify: `backend/app/main.py`
- Modify: `frontend/src/api/marketTrends.js`
- Modify: `frontend/src/views/MarketTrends.vue`
- Modify: `frontend/src/router/index.js`
- Modify: `frontend/src/App.vue`
- Test: `tests/test_market_trends_api.py`
- Test: `frontend/src/views/__tests__/MarketTrends.test.js`

**Interfaces:**
- Produces: `GET /api/market-trends/summary`
- Produces: `GET /api/market-trends/timeline`
- Produces: `GET /api/market-trends/validation`
- Produces: `GET /api/market-trends/actions`

- [x] Step 1: 确认四个接口返回结构稳定。
- [x] Step 2: 补预测验证测试：事件是否在 BOM 风险结果中体现。
- [x] Step 3: 补主动预警队列跳转：事件、项目、物料可追踪。
- [x] Step 4: 前端页面补空态、刷新、days 切换。
- [x] Step 5: 运行趋势后端和前端测试。

### Task 5: 多源供应和 BOM 详情体验收尾

**Files:**
- Modify: `backend/app/api/supply.py`
- Modify: `backend/app/services/supply_data.py`
- Modify: `backend/app/api/risk_analysis.py`
- Modify: `backend/app/services/supply_risk.py`
- Modify: `frontend/src/views/BomProjectDetail.vue`
- Test: `tests/test_multi_source_supply.py`
- Test: `tests/test_supply_api.py`
- Test: `frontend/src/views/__tests__/BomProjectDetail.test.js`

**Interfaces:**
- Produces: 供应查询 payload 包含各源 `source/match_status/error_reason/stock/price/lead_time/lifecycle`。
- Produces: 风险报告高风险物料包含供应证据、行情证据、采购建议。

- [x] Step 1: 补测试：供应源失败原因展示但不清空旧数据。
- [x] Step 2: 补测试：BOM 详情切换项目不缓存旧项目。
- [x] Step 3: 前端展示供应证据、行情证据、涨价/缺货/交期/生命周期标签。
- [x] Step 4: 运行供应和 BOM 详情测试。

### Task 6: 全量验证和启动验收

**Files:**
- No feature files unless tests reveal failures.

**Interfaces:**
- Produces: 可运行服务和验收记录。

- [x] Step 1: 运行后端关键测试：`pytest tests/test_market_notice_parser.py tests/test_category_classifier.py tests/test_market_inbox_api.py tests/test_market_events_api.py tests/test_market_trends_api.py tests/test_multi_source_supply.py tests/test_supply_api.py -q`。
- [x] Step 2: 运行前端测试：`npm run test -- --run`。
- [x] Step 3: 运行前端构建：`npm run build`。
- [x] Step 4: 重启后端并验证 `/api/health`、BOM 项目列表、风险报告、事件中心、趋势预警、媒体源接口。

## Acceptance Record

本轮收尾基于 2026-06-29 的最新验证结果记录：

- 后端关键回归命令：`$env:PYTHONPATH='backend'; py -3.11 -m pytest tests/test_market_notice_parser.py tests/test_category_classifier.py tests/test_market_inbox_api.py tests/test_market_events_api.py tests/test_market_trends_api.py tests/test_multi_source_supply.py tests/test_supply_api.py -q`
- 后端结果：`70 passed in 24.58s`
- 前端测试命令：`npm run test -- --run`
- 前端测试结果：`41 passed`
- 前端构建命令：`npm run build`
- 前端构建结果：构建通过，保留 Rollup 纯注释和大 chunk 提示
- 启动验收：临时启动后端，验证健康检查、BOM 项目列表、风险报告、事件中心、趋势预警摘要和媒体源接口均可访问

## Self-Review

- Spec coverage: 方案 A 的六个模块均有任务覆盖，且任务步骤已完成。
- Placeholder scan: 无 TBD/TODO/稍后实现占位。
- Type consistency: 接口名称与现有项目路由和计划文档保持一致。
- Scope check: 外部授权类能力仅登记状态，不进入本轮自动化抓取。
- Delivery check: 方案 A 已具备可演示、可回归、可继续迭代的本地闭环。