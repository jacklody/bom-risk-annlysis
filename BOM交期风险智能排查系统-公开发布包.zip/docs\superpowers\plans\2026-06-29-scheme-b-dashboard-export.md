# 方案 B 风险仪表盘与 HTML 报告导出 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 交付方案 B B1 阶段：风险运营仪表盘、仪表盘聚合 API、项目详情 HTML 报告导出入口与 HTML 导出接口。

**Architecture:** 后端新增独立 dashboard API 与聚合服务，报告导出复用现有 `/api/risk/report/{project_id}` 数据结构生成静态 HTML。前端新增 `/dashboard` 页面与导航入口，并在项目详情页新增打开 HTML 报告的操作，保持现有 BOM、事件、趋势和供应链分析逻辑不变。

**Tech Stack:** FastAPI、SQLAlchemy、SQLite、pytest、Vue 3、Vue Router、Element Plus、axios、Vitest、Vite。

## Global Constraints

- 方案 B B1 只读取和组织现有数据，不改变风险判断规则。
- 不引入服务端无头浏览器、PDF 渲染依赖或新的外部授权数据源。
- HTML 报告不得包含密钥、环境变量值或内部调试信息。
- 仪表盘统计口径必须在页面上显示简短说明。
- 当前工作区已有大量未提交变更，实施时只触碰本计划列出的方案 B 相关文件。
- 不提交 git commit，除非用户明确要求。

---

## File Structure

- Create: `backend/app/services/dashboard_summary.py`
  - 负责汇总项目风险、品类风险、近期事件、趋势行动与供应源状态。
- Create: `backend/app/api/dashboard.py`
  - 暴露 `GET /api/dashboard/summary`。
- Modify: `backend/app/main.py`
  - 注册 dashboard router。
- Create: `tests/test_dashboard_api.py`
  - 验证仪表盘 API 结构、统计口径与空态。
- Create: `backend/app/services/risk_report_export.py`
  - 负责把现有项目风险报告 payload 渲染为安全的静态 HTML。
- Modify: `backend/app/api/risk_analysis.py`
  - 新增 `GET /api/risk/report/{project_id}/export.html`。
- Create: `tests/test_risk_report_export.py`
  - 验证 HTML 报告包含项目概况、高风险物料、供应证据、行情证据和采购建议。
- Create: `frontend/src/api/dashboard.js`
  - 封装 `getDashboardSummary()`。
- Modify: `frontend/src/api/bom.js`
  - 增加 `getProjectRiskReportHtmlUrl(projectId)`。
- Create: `frontend/src/views/RiskDashboard.vue`
  - 新增风险运营仪表盘页面。
- Modify: `frontend/src/router/index.js`
  - 增加 `/dashboard` 路由。
- Modify: `frontend/src/App.vue`
  - 增加“风险仪表盘”导航入口。
- Modify: `frontend/src/views/BomProjectDetail.vue`
  - 增加“打开 HTML 报告”按钮。
- Create: `frontend/src/views/__tests__/RiskDashboard.test.js`
  - 验证仪表盘模块展示、空态、错误重试与跳转。
- Modify: `frontend/src/views/__tests__/BomProjectDetail.test.js`
  - 验证报告导出按钮调用正确 URL。

---

### Task 1: Dashboard Summary API

**Files:**
- Create: `backend/app/services/dashboard_summary.py`
- Create: `backend/app/api/dashboard.py`
- Modify: `backend/app/main.py`
- Test: `tests/test_dashboard_api.py`

**Interfaces:**
- Consumes: `BomProject.to_summary()`, `BomItem`, `MarketEvent.to_dict()`, `SupplyDataService`, `market_trends._build_actions(db)`。
- Produces: `build_dashboard_summary(db: Session) -> dict` and `GET /api/dashboard/summary`。

- [ ] **Step 1: Write failing backend API tests**

Create `tests/test_dashboard_api.py` with tests that seed projects, BOM items and market events, then assert:

```python
from datetime import datetime, timedelta, timezone

from fastapi.testclient import TestClient

from app.database import SessionLocal, init_db
from app.main import app
from app.models.bom import BomItem, BomProject, RiskLevel
from app.models.event import EventType, MarketEvent, Severity

client = TestClient(app)


def _clean_dashboard_data():
    init_db()
    db = SessionLocal()
    db.query(BomItem).delete()
    db.query(BomProject).delete()
    db.query(MarketEvent).delete()
    db.commit()
    db.close()


def _seed_dashboard_project():
    db = SessionLocal()
    try:
        project = BomProject(
            filename="scheme-b-demo.xlsx",
            project_name="方案B演示项目",
            status="active",
            total_items=3,
            items_analyzed=3,
            items_red=1,
            items_yellow=1,
            items_green=1,
            items_gray=0,
            last_analysis_at=datetime.now(timezone.utc),
        )
        db.add(project)
        db.commit()
        db.refresh(project)
        event = MarketEvent(
            source_name="采购邮箱",
            source_url="test://dashboard-event",
            raw_title="ST MCU 交期延长",
            raw_text="ST MCU 交期延长，价格上涨",
            brand="ST",
            category="MCU",
            event_type=EventType.LEAD_TIME,
            severity=Severity.HIGH,
            confidence=0.86,
            created_at=datetime.now(timezone.utc) - timedelta(days=2),
            is_active=1,
        )
        db.add(event)
        db.commit()
        db.refresh(event)
        db.add_all([
            BomItem(
                bom_upload_id=project.id,
                row_number=1,
                raw_part_number="STM32F103C8T6",
                raw_brand="ST",
                raw_category="MCU",
                normalized_category="MCU",
                risk_level=RiskLevel.RED,
                risk_score=92,
                matched_event_ids=str(event.id),
                total_stock=0,
                supplier_count=1,
                lead_time_days=56,
                procurement_suggestion="建议锁单并准备替代料。",
            ),
            BomItem(
                bom_upload_id=project.id,
                row_number=2,
                raw_part_number="C-MLCC-001",
                raw_brand="TDK",
                raw_category="MLCC",
                normalized_category="MLCC",
                risk_level=RiskLevel.YELLOW,
                risk_score=66,
                matched_event_ids=str(event.id),
                total_stock=300,
                supplier_count=2,
                lead_time_days=28,
                procurement_suggestion="建议观察价格变化。",
            ),
            BomItem(
                bom_upload_id=project.id,
                row_number=3,
                raw_part_number="R-SAFE-001",
                raw_brand="Yageo",
                raw_category="电阻",
                normalized_category="电阻",
                risk_level=RiskLevel.GREEN,
                risk_score=20,
            ),
        ])
        db.commit()
        return project.id, event.id
    finally:
        db.close()


def test_dashboard_summary_returns_overview_project_category_event_and_actions():
    _clean_dashboard_data()
    project_id, event_id = _seed_dashboard_project()

    resp = client.get("/api/dashboard/summary")

    assert resp.status_code == 200
    data = resp.json()
    assert data["overview"]["project_count"] == 1
    assert data["overview"]["high_risk_project_count"] == 1
    assert data["overview"]["red_item_count"] == 1
    assert data["overview"]["active_event_count_30d"] == 1
    assert data["overview"]["pending_action_count"] >= 1
    assert data["project_risks"][0]["project_id"] == project_id
    assert data["project_risks"][0]["risk_counts"]["red"] == 1
    assert data["category_risks"][0]["category"] in {"MCU", "MLCC"}
    assert data["recent_events"][0]["id"] == event_id
    assert data["recent_events"][0]["impact_item_count"] == 2
    assert "supply_sources" in data
    assert data["generated_at"]


def test_dashboard_summary_empty_state_is_stable():
    _clean_dashboard_data()

    resp = client.get("/api/dashboard/summary")

    assert resp.status_code == 200
    data = resp.json()
    assert data["overview"]["project_count"] == 0
    assert data["project_risks"] == []
    assert data["category_risks"] == []
    assert data["recent_events"] == []
    assert data["trend_actions"] == []
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```powershell
py -3.11 -m pytest tests/test_dashboard_api.py -q
```

Expected: FAIL because `/api/dashboard/summary` is not registered.

- [ ] **Step 3: Implement dashboard service**

Create `backend/app/services/dashboard_summary.py` with:

```python
from collections import defaultdict
from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import Session

from app.api.market_trends import _build_actions
from app.models.bom import BomItem, BomProject
from app.models.event import MarketEvent
from app.services.supply_data import SupplyDataService

RISK_LEVELS = ("red", "yellow", "green", "gray")


def _now():
    return datetime.now(timezone.utc)


def _risk_value(item: BomItem) -> str:
    if not item.risk_level:
        return "gray"
    value = item.risk_level.value if hasattr(item.risk_level, "value") else str(item.risk_level)
    return value if value in RISK_LEVELS else "gray"


def _csv_id_set(csv_text: str | None) -> set[int]:
    ids: set[int] = set()
    if not csv_text:
        return ids
    for token in str(csv_text).split(","):
        token = token.strip()
        if not token:
            continue
        try:
            ids.add(int(token))
        except ValueError:
            continue
    return ids


def _build_event_impact(items: list[BomItem]) -> dict[int, dict]:
    impact: dict[int, dict] = defaultdict(lambda: {"project_ids": set(), "item_ids": set(), "risk_counts": {level: 0 for level in RISK_LEVELS}})
    for item in items:
        for event_id in _csv_id_set(item.matched_event_ids):
            row = impact[event_id]
            row["project_ids"].add(item.bom_upload_id)
            if item.id is not None:
                row["item_ids"].add(item.id)
            row["risk_counts"][_risk_value(item)] += 1
    return impact


def _project_risk_payload(project: BomProject) -> dict:
    total = project.total_items or 0
    red = project.items_red or 0
    yellow = project.items_yellow or 0
    return {
        "project_id": project.id,
        "project_name": project.project_name or project.filename,
        "filename": project.filename,
        "status": project.status,
        "total_items": total,
        "risk_counts": {
            "red": red,
            "yellow": yellow,
            "green": project.items_green or 0,
            "gray": project.items_gray or 0,
        },
        "risk_rate": round((red + yellow) / max(1, total) * 100, 1),
        "last_analysis_at": project.last_analysis_at.isoformat() if project.last_analysis_at else None,
    }


def _category_risks(items: list[BomItem], event_impact: dict[int, dict]) -> list[dict]:
    rows: dict[str, dict] = {}
    category_event_ids: dict[str, set[int]] = defaultdict(set)
    for item in items:
        category = item.normalized_category or item.raw_category or "未分类"
        if category not in rows:
            rows[category] = {"category": category, "red": 0, "yellow": 0, "green": 0, "gray": 0, "total": 0, "event_count": 0}
        level = _risk_value(item)
        rows[category][level] += 1
        rows[category]["total"] += 1
        category_event_ids[category].update(_csv_id_set(item.matched_event_ids))
    for category, event_ids in category_event_ids.items():
        rows[category]["event_count"] = len(event_ids & set(event_impact.keys()))
    return sorted(rows.values(), key=lambda row: (row["red"], row["yellow"], row["event_count"], row["total"]), reverse=True)[:10]


def _recent_events(events: list[MarketEvent], event_impact: dict[int, dict]) -> list[dict]:
    rows = []
    for event in events[:10]:
        impact = event_impact.get(event.id, {"project_ids": set(), "item_ids": set(), "risk_counts": {level: 0 for level in RISK_LEVELS}})
        rows.append({
            "id": event.id,
            "title": event.raw_title or event.raw_text or f"事件 {event.id}",
            "source_name": event.source_name,
            "brand": event.brand,
            "category": event.category,
            "event_type": event.event_type.value if event.event_type else None,
            "severity": event.severity.value if event.severity else None,
            "confidence": event.confidence,
            "impact_project_count": len(impact["project_ids"]),
            "impact_item_count": len(impact["item_ids"]),
            "risk_counts": impact["risk_counts"],
            "created_at": event.created_at.isoformat() if event.created_at else None,
        })
    return rows


def _supply_sources() -> list[dict]:
    service = SupplyDataService()
    sources = list(getattr(service, "_all_sources", None) or getattr(service, "_enabled_sources", None) or [])
    rows = []
    for source in sources:
        configured = bool(getattr(source, "is_configured", False))
        rows.append({
            "source": getattr(source, "source_name", "unknown"),
            "configured": configured,
            "status": "active" if configured else "not_configured",
            "error_reason": "" if configured else "数据源尚未配置或需要人工接入",
        })
    return rows


def build_dashboard_summary(db: Session) -> dict:
    projects = db.query(BomProject).order_by(BomProject.updated_at.desc()).limit(50).all()
    items = db.query(BomItem).all()
    since = _now() - timedelta(days=30)
    events = (
        db.query(MarketEvent)
        .filter(MarketEvent.is_active == 1)
        .order_by(MarketEvent.created_at.desc(), MarketEvent.id.desc())
        .all()
    )
    recent_30d_events = [event for event in events if event.created_at is None or event.created_at >= since]
    event_impact = _build_event_impact(items)
    trend_actions = _build_actions(db)[:10]
    return {
        "overview": {
            "project_count": len(projects),
            "high_risk_project_count": sum(1 for project in projects if (project.items_red or 0) > 0),
            "red_item_count": sum(1 for item in items if _risk_value(item) == "red"),
            "active_event_count_30d": len(recent_30d_events),
            "pending_action_count": len(trend_actions),
        },
        "project_risks": sorted([_project_risk_payload(project) for project in projects], key=lambda row: (row["risk_counts"]["red"], row["risk_counts"]["yellow"], row["last_analysis_at"] or ""), reverse=True),
        "category_risks": _category_risks(items, event_impact),
        "recent_events": _recent_events(events, event_impact),
        "trend_actions": trend_actions,
        "supply_sources": _supply_sources(),
        "generated_at": _now().isoformat(),
    }
```

- [ ] **Step 4: Implement API router and register it**

Create `backend/app/api/dashboard.py`:

```python
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.services.dashboard_summary import build_dashboard_summary

router = APIRouter()


@router.get("/summary")
def get_dashboard_summary(db: Session = Depends(get_db)):
    return build_dashboard_summary(db)
```

Modify `backend/app/main.py` to import and include the router:

```python
from app.api import events, bom_upload, risk_analysis, bom_project, intel_watch, market_inbox, preferred_library, market_trends, supply, market_intel, dashboard

app.include_router(dashboard.router, prefix="/api/dashboard", tags=["dashboard"])
```

- [ ] **Step 5: Run tests for Task 1**

Run:

```powershell
py -3.11 -m pytest tests/test_dashboard_api.py -q
```

Expected: PASS.

---

### Task 2: HTML Risk Report Export API

**Files:**
- Create: `backend/app/services/risk_report_export.py`
- Modify: `backend/app/api/risk_analysis.py`
- Test: `tests/test_risk_report_export.py`

**Interfaces:**
- Consumes: existing `project_risk_report(upload_id, db)` payload shape.
- Produces: `render_risk_report_html(report: dict) -> str` and `GET /api/risk/report/{project_id}/export.html`。

- [ ] **Step 1: Write failing report export tests**

Create `tests/test_risk_report_export.py` with:

```python
from datetime import datetime, timezone

from fastapi.testclient import TestClient

from app.database import SessionLocal, init_db
from app.main import app
from app.models.bom import BomItem, BomProject, RiskLevel
from app.models.event import EventType, MarketEvent, Severity

client = TestClient(app)


def _clean_report_data():
    init_db()
    db = SessionLocal()
    db.query(BomItem).delete()
    db.query(BomProject).delete()
    db.query(MarketEvent).delete()
    db.commit()
    db.close()


def _seed_report_project():
    db = SessionLocal()
    try:
        project = BomProject(
            filename="report-demo.xlsx",
            project_name="报告导出演示项目",
            status="active",
            total_items=1,
            items_analyzed=1,
            items_red=1,
            items_yellow=0,
            items_green=0,
            items_gray=0,
            last_analysis_at=datetime.now(timezone.utc),
        )
        db.add(project)
        db.commit()
        db.refresh(project)
        event = MarketEvent(
            source_name="供应商通知",
            source_url="test://report-event",
            raw_title="STM32 MCU 交期拉长",
            raw_text="STM32 MCU 交期拉长，建议提前锁单",
            brand="ST",
            category="MCU",
            event_type=EventType.LEAD_TIME,
            severity=Severity.HIGH,
            confidence=0.9,
            is_active=1,
        )
        db.add(event)
        db.commit()
        db.refresh(event)
        item = BomItem(
            bom_upload_id=project.id,
            row_number=1,
            raw_part_number="STM32F103C8T6",
            raw_brand="ST",
            raw_category="MCU",
            normalized_category="MCU",
            risk_level=RiskLevel.RED,
            risk_score=95,
            risk_reason="交期拉长并存在缺货风险",
            matched_event_ids=str(event.id),
            total_stock=0,
            supplier_count=1,
            lead_time_days=56,
            unit_price=12.5,
            lifecycle_status="Active",
            supply_sources_summary="lcsc:库存0; mouser:交期56天",
            supply_risk_tags="low_stock,long_lead_time",
            procurement_suggestion="建议锁单并准备替代料。",
        )
        db.add(item)
        db.commit()
        return project.id
    finally:
        db.close()


def test_risk_report_export_html_contains_project_supply_market_and_actions():
    _clean_report_data()
    project_id = _seed_report_project()

    resp = client.get(f"/api/risk/report/{project_id}/export.html")

    assert resp.status_code == 200
    assert "text/html" in resp.headers["content-type"]
    html = resp.text
    assert "报告导出演示项目" in html
    assert "STM32F103C8T6" in html
    assert "lcsc:库存0" in html
    assert "STM32 MCU 交期拉长" in html
    assert "建议锁单" in html
    assert "window.__" not in html


def test_risk_report_export_html_returns_404_for_missing_project():
    _clean_report_data()

    resp = client.get("/api/risk/report/999999/export.html")

    assert resp.status_code == 404
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```powershell
py -3.11 -m pytest tests/test_risk_report_export.py -q
```

Expected: FAIL because `export.html` route does not exist.

- [ ] **Step 3: Implement HTML renderer**

Create `backend/app/services/risk_report_export.py`:

```python
from html import escape


def _text(value) -> str:
    if value is None:
        return ""
    return escape(str(value))


def _risk_label(level: str | None) -> str:
    return {"red": "高风险", "yellow": "关注", "green": "安全", "gray": "无数据"}.get(level or "gray", "无数据")


def _render_rows(items: list[dict]) -> str:
    if not items:
        return "<tr><td colspan='8'>暂无高风险物料</td></tr>"
    rows = []
    for item in items:
        evidence = "；".join(_text(event.get("title")) for event in item.get("market_evidence") or [])
        rows.append(
            "<tr>"
            f"<td>{_text(item.get('part_number'))}</td>"
            f"<td>{_text(item.get('brand'))}</td>"
            f"<td>{_text(item.get('category'))}</td>"
            f"<td>{_text(_risk_label(item.get('risk_level')))}</td>"
            f"<td>{_text(item.get('total_stock'))}</td>"
            f"<td>{_text(item.get('lead_time_days'))}</td>"
            f"<td>{_text(item.get('supply_sources_summary'))}</td>"
            f"<td>{evidence}</td>"
            "</tr>"
        )
    return "".join(rows)


def _render_actions(actions: dict) -> str:
    rows = []
    for action in actions.get("urgent") or []:
        rows.append(f"<li><strong>紧急：</strong>{_text(action)}</li>")
    for action in actions.get("watch") or []:
        rows.append(f"<li><strong>关注：</strong>{_text(action)}</li>")
    if not rows:
        return "<li>暂无采购建议</li>"
    return "".join(rows)


def render_risk_report_html(report: dict) -> str:
    project = report.get("project") or {}
    summary = report.get("risk_summary") or {}
    items = report.get("high_risk_items") or []
    actions = report.get("actions") or {}
    title = _text(project.get("project_name") or project.get("filename") or "BOM风险报告")
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>{title}</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif; margin: 32px; color: #1f2937; background: #f8fafc; }}
.report {{ max-width: 1180px; margin: 0 auto; background: #fff; padding: 32px; border-radius: 16px; box-shadow: 0 10px 30px rgba(15, 23, 42, 0.08); }}
h1 {{ margin: 0 0 8px; font-size: 28px; }}
h2 {{ margin-top: 28px; font-size: 20px; border-left: 4px solid #2563eb; padding-left: 10px; }}
.meta, .cards {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-top: 16px; }}
.card {{ background: #f1f5f9; border-radius: 12px; padding: 14px; }}
.card span {{ display: block; color: #64748b; font-size: 13px; }}
.card strong {{ display: block; margin-top: 6px; font-size: 22px; }}
table {{ width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 13px; }}
th, td {{ border: 1px solid #e5e7eb; padding: 10px; text-align: left; vertical-align: top; }}
th {{ background: #f8fafc; }}
.notice {{ margin-top: 20px; color: #64748b; font-size: 12px; }}
@media print {{ body {{ margin: 0; background: #fff; }} .report {{ box-shadow: none; border-radius: 0; }} }}
</style>
</head>
<body>
<main class="report">
<h1>{title}</h1>
<p>项目风险报告 · 生成时间：{_text(report.get('last_analysis_at'))}</p>
<section class="meta">
<div class="card"><span>文件名</span><strong>{_text(project.get('filename'))}</strong></div>
<div class="card"><span>物料总数</span><strong>{_text(summary.get('total_items'))}</strong></div>
<div class="card"><span>风险率</span><strong>{_text(summary.get('risk_rate'))}%</strong></div>
<div class="card"><span>紧急风险</span><strong>{'是' if summary.get('has_urgent') else '否'}</strong></div>
</section>
<section class="cards">
<div class="card"><span>高风险</span><strong>{_text(summary.get('red'))}</strong></div>
<div class="card"><span>关注</span><strong>{_text(summary.get('yellow'))}</strong></div>
<div class="card"><span>安全</span><strong>{_text(summary.get('green'))}</strong></div>
<div class="card"><span>无数据</span><strong>{_text(summary.get('gray'))}</strong></div>
</section>
<h2>高风险物料与证据</h2>
<table>
<thead><tr><th>型号</th><th>品牌</th><th>品类</th><th>风险</th><th>库存</th><th>交期天数</th><th>供应证据</th><th>行情证据</th></tr></thead>
<tbody>{_render_rows(items)}</tbody>
</table>
<h2>采购建议</h2>
<ul>{_render_actions(actions)}</ul>
<p class="notice">本报告由系统已有 BOM、供应与行情证据生成，不包含密钥、环境变量或内部调试信息。可使用浏览器打印功能另存为 PDF。</p>
</main>
</body>
</html>"""
```

- [ ] **Step 4: Add export route**

Modify `backend/app/api/risk_analysis.py` imports:

```python
from fastapi.responses import HTMLResponse
from app.services.risk_report_export import render_risk_report_html
```

Add below `project_risk_report`:

```python
@router.get("/report/{upload_id}/export.html", response_class=HTMLResponse)
def export_project_risk_report_html(upload_id: int, db: Session = Depends(get_db)):
    report = project_risk_report(upload_id, db)
    html = render_risk_report_html(report)
    return HTMLResponse(content=html)
```

- [ ] **Step 5: Run tests for Task 2**

Run:

```powershell
py -3.11 -m pytest tests/test_risk_report_export.py -q
```

Expected: PASS.

---

### Task 3: Dashboard Frontend Page

**Files:**
- Create: `frontend/src/api/dashboard.js`
- Create: `frontend/src/views/RiskDashboard.vue`
- Modify: `frontend/src/router/index.js`
- Modify: `frontend/src/App.vue`
- Test: `frontend/src/views/__tests__/RiskDashboard.test.js`

**Interfaces:**
- Consumes: `GET /api/dashboard/summary` response from Task 1。
- Produces: route `/dashboard`, `getDashboardSummary()`。

- [ ] **Step 1: Write failing frontend test**

Create `frontend/src/views/__tests__/RiskDashboard.test.js`:

```javascript
import { mount, flushPromises } from '@vue/test-utils'
import { describe, expect, it, vi, beforeEach } from 'vitest'
import RiskDashboard from '../RiskDashboard.vue'
import * as dashboardApi from '../../api/dashboard'

vi.mock('../../api/dashboard', () => ({
  getDashboardSummary: vi.fn()
}))

const push = vi.fn()
vi.mock('vue-router', () => ({
  useRouter: () => ({ push })
}))

vi.mock('element-plus', () => ({
  ElMessage: { error: vi.fn() }
}))

const stubs = {
  'el-card': { template: '<section><slot name="header" /><slot /></section>' },
  'el-button': { emits: ['click'], template: '<button v-bind="$attrs" @click="$emit(\'click\')"><slot /></button>' },
  'el-table': { props: ['data'], template: '<div><slot /><div v-for="row in data" :key="row.id || row.project_id || row.category">{{ row.project_name || row.title || row.category || row.source }}</div></div>' },
  'el-table-column': { template: '<div />' },
  'el-tag': { template: '<span><slot /></span>' },
  'el-empty': { props: ['description'], template: '<div>{{ description }}</div>' },
  'el-progress': { template: '<div />' }
}

const summaryPayload = {
  overview: {
    project_count: 2,
    high_risk_project_count: 1,
    red_item_count: 3,
    active_event_count_30d: 4,
    pending_action_count: 5
  },
  project_risks: [{ project_id: 7, project_name: '方案B演示项目', risk_counts: { red: 1, yellow: 1, green: 2, gray: 0 }, risk_rate: 50, last_analysis_at: '2026-06-29T10:00:00' }],
  category_risks: [{ category: 'MCU', red: 1, yellow: 1, green: 0, gray: 0, total: 2, event_count: 1 }],
  recent_events: [{ id: 9, title: 'ST MCU 交期延长', source_name: '采购邮箱', severity: 'high', confidence: 0.86, impact_item_count: 2 }],
  trend_actions: [{ id: 'review_event:9', title: '建议复核高风险事件', priority: 'high', project_count: 1, item_count: 2, target_route: '/events', target_query: { event_ids: '9' } }],
  supply_sources: [{ source: 'lcsc', configured: true, status: 'active', error_reason: '' }],
  generated_at: '2026-06-29T10:00:00'
}

describe('RiskDashboard', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    push.mockReset()
  })

  it('展示仪表盘指标、项目风险、品类风险、事件、行动和供应源状态', async () => {
    dashboardApi.getDashboardSummary.mockResolvedValue({ data: summaryPayload })

    const wrapper = mount(RiskDashboard, { global: { stubs, directives: { loading: {} } } })
    await flushPromises()

    expect(wrapper.text()).toContain('风险仪表盘')
    expect(wrapper.text()).toContain('项目总数')
    expect(wrapper.text()).toContain('2')
    expect(wrapper.text()).toContain('方案B演示项目')
    expect(wrapper.text()).toContain('MCU')
    expect(wrapper.text()).toContain('ST MCU 交期延长')
    expect(wrapper.text()).toContain('建议复核高风险事件')
    expect(wrapper.text()).toContain('lcsc')
    expect(wrapper.text()).toContain('统计口径')
  })

  it('点击项目、事件和行动时带上下文跳转', async () => {
    dashboardApi.getDashboardSummary.mockResolvedValue({ data: summaryPayload })

    const wrapper = mount(RiskDashboard, { global: { stubs, directives: { loading: {} } } })
    await flushPromises()

    await wrapper.vm.openProject(summaryPayload.project_risks[0])
    expect(push).toHaveBeenCalledWith('/projects/7')

    await wrapper.vm.openEvent(summaryPayload.recent_events[0])
    expect(push).toHaveBeenCalledWith({ path: '/events', query: { event_ids: '9' } })

    await wrapper.vm.openAction(summaryPayload.trend_actions[0])
    expect(push).toHaveBeenCalledWith({ path: '/events', query: { event_ids: '9' } })
  })

  it('接口为空时显示空态', async () => {
    dashboardApi.getDashboardSummary.mockResolvedValue({ data: { ...summaryPayload, project_risks: [], category_risks: [], recent_events: [], trend_actions: [], supply_sources: [] } })

    const wrapper = mount(RiskDashboard, { global: { stubs, directives: { loading: {} } } })
    await flushPromises()

    expect(wrapper.text()).toContain('暂无项目风险数据')
    expect(wrapper.text()).toContain('暂无近期活跃事件')
  })
})
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```powershell
cd frontend; npm run test -- src/views/__tests__/RiskDashboard.test.js
```

Expected: FAIL because `RiskDashboard.vue` and `api/dashboard.js` do not exist.

- [ ] **Step 3: Implement dashboard API module**

Create `frontend/src/api/dashboard.js`:

```javascript
import client from './client'

export function getDashboardSummary() {
  return client.get('/dashboard/summary')
}
```

- [ ] **Step 4: Implement RiskDashboard page**

Create `frontend/src/views/RiskDashboard.vue` with a Vue 3 `<script setup>` component that:

```javascript
const summary = ref({
  overview: {},
  project_risks: [],
  category_risks: [],
  recent_events: [],
  trend_actions: [],
  supply_sources: []
})

const metricCards = computed(() => [
  { label: '项目总数', value: summary.value.overview?.project_count ?? 0, type: 'primary' },
  { label: '高风险项目', value: summary.value.overview?.high_risk_project_count ?? 0, type: 'danger' },
  { label: '红色物料', value: summary.value.overview?.red_item_count ?? 0, type: 'danger' },
  { label: '近30天事件', value: summary.value.overview?.active_event_count_30d ?? 0, type: 'warning' },
  { label: '需处理行动', value: summary.value.overview?.pending_action_count ?? 0, type: 'warning' }
])
```

Expose functions:

```javascript
function openProject(row) {
  router.push(`/projects/${row.project_id}`)
}

function openEvent(row) {
  router.push({ path: '/events', query: { event_ids: String(row.id) } })
}

function openAction(action) {
  router.push({ path: action.target_route || '/events', query: action.target_query || {} })
}
```

The template must include these visible headings: `风险仪表盘`, `项目风险分布`, `品类风险排行`, `近期活跃事件`, `趋势行动摘要`, `供应源健康状态`, `统计口径`。

- [ ] **Step 5: Register route and navigation**

Modify `frontend/src/router/index.js`:

```javascript
{
  path: '/dashboard',
  name: 'dashboard',
  component: () => import('../views/RiskDashboard.vue')
},
```

Modify `frontend/src/App.vue` to add a menu item:

```vue
<el-menu-item index="/dashboard">
  <el-icon><DataAnalysis /></el-icon>
  <span>风险仪表盘</span>
</el-menu-item>
```

- [ ] **Step 6: Run tests for Task 3**

Run:

```powershell
cd frontend; npm run test -- src/views/__tests__/RiskDashboard.test.js
```

Expected: PASS.

---

### Task 4: Project Detail HTML Report Entry

**Files:**
- Modify: `frontend/src/api/bom.js`
- Modify: `frontend/src/views/BomProjectDetail.vue`
- Modify: `frontend/src/views/__tests__/BomProjectDetail.test.js`

**Interfaces:**
- Consumes: `GET /api/risk/report/{project_id}/export.html` from Task 2。
- Produces: `getProjectRiskReportHtmlUrl(projectId)` and a project detail button that opens the HTML report in a new browser tab。

- [ ] **Step 1: Write failing frontend test**

Append to `frontend/src/views/__tests__/BomProjectDetail.test.js`:

```javascript
it('提供 HTML 风险报告导出入口并打开正确地址', async () => {
  const openSpy = vi.spyOn(window, 'open').mockImplementation(() => null)
  bomApi.getBomProject.mockResolvedValue({
    data: {
      project: {
        id: 7,
        project_name: '历史BOM-A',
        filename: 'history-a.xlsx',
        status: 'active',
        total_items: 1,
        items_red: 1,
        items_yellow: 0,
        items_green: 0,
        items_gray: 0,
        last_analysis_at: '2026-06-28T09:55:31'
      },
      items: [{ id: 99, row_number: 1, part_number: 'STM32F103C8T6', brand: 'ST', category: 'MCU', risk_level: 'red' }]
    }
  })

  const wrapper = mount(BomProjectDetail, { global: { stubs, directives: { loading: {} } } })
  await flushPromises()

  const exportButton = wrapper.find('[data-testid="open-html-report"]')
  expect(exportButton.exists()).toBe(true)
  await exportButton.trigger('click')

  expect(openSpy).toHaveBeenCalledWith('/api/risk/report/7/export.html', '_blank', 'noopener')
  openSpy.mockRestore()
})
```

The mock at the top of the file must include:

```javascript
getProjectRiskReportHtmlUrl: vi.fn((projectId) => `/api/risk/report/${projectId}/export.html`)
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```powershell
cd frontend; npm run test -- src/views/__tests__/BomProjectDetail.test.js
```

Expected: FAIL because the button and URL helper do not exist.

- [ ] **Step 3: Add URL helper**

Modify `frontend/src/api/bom.js`:

```javascript
export function getProjectRiskReportHtmlUrl(projectId) {
  return `/api/risk/report/${projectId}/export.html`
}
```

- [ ] **Step 4: Add button and action**

Modify `frontend/src/views/BomProjectDetail.vue` imports:

```javascript
import { getBomProject, getProjectRiskReport, getProjectRiskReportHtmlUrl } from '../api/bom'
```

Add button next to refresh:

```vue
<el-button data-testid="open-html-report" :disabled="!project" @click="openHtmlReport">
  打开HTML报告
</el-button>
```

Add function:

```javascript
function openHtmlReport() {
  if (!project.value?.id) return
  window.open(getProjectRiskReportHtmlUrl(project.value.id), '_blank', 'noopener')
}
```

- [ ] **Step 5: Run tests for Task 4**

Run:

```powershell
cd frontend; npm run test -- src/views/__tests__/BomProjectDetail.test.js
```

Expected: PASS.

---

### Task 5: Integrated Verification

**Files:**
- All files touched by Tasks 1-4.

**Interfaces:**
- Verifies backend API, frontend tests and production build.

- [ ] **Step 1: Run targeted backend tests**

Run:

```powershell
py -3.11 -m pytest tests/test_dashboard_api.py tests/test_risk_report_export.py -q
```

Expected: all tests pass.

- [ ] **Step 2: Run targeted frontend tests**

Run:

```powershell
cd frontend; npm run test -- src/views/__tests__/RiskDashboard.test.js src/views/__tests__/BomProjectDetail.test.js
```

Expected: all tests pass.

- [ ] **Step 3: Run frontend build**

Run:

```powershell
cd frontend; npm run build
```

Expected: build succeeds.

- [ ] **Step 4: Run existing backend test suite**

Run:

```powershell
py -3.11 -m pytest tests -q
```

Expected: existing backend tests still pass.

- [ ] **Step 5: Review git diff scope**

Run:

```powershell
git diff -- backend/app/services/dashboard_summary.py backend/app/api/dashboard.py backend/app/main.py tests/test_dashboard_api.py backend/app/services/risk_report_export.py backend/app/api/risk_analysis.py tests/test_risk_report_export.py frontend/src/api/dashboard.js frontend/src/api/bom.js frontend/src/views/RiskDashboard.vue frontend/src/router/index.js frontend/src/App.vue frontend/src/views/BomProjectDetail.vue frontend/src/views/__tests__/RiskDashboard.test.js frontend/src/views/__tests__/BomProjectDetail.test.js
```

Expected: diff only contains方案B B1相关改动。