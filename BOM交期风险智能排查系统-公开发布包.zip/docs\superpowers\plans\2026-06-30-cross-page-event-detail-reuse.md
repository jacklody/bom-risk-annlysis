# 跨页面复用市场事件详情 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 把统一市场事件详情组件接入趋势预警、行情收件箱和 BOM 项目详情，并抽取统一事件详情加载逻辑。

**Architecture:** 新增 `useMarketEventDetail()` composable 封装事件本体、影响项目、复核来源的分段容错加载。各页面复用 `MarketEventDetailDrawer` 和 composable，只保留自身业务入口按钮和跳转入口。

**Tech Stack:** Vue 3、Vue Router、Element Plus、Vitest、Vue Test Utils。

## Global Constraints

- 必须使用 TDD：先写失败测试并确认失败原因，再修改生产代码。
- 不改后端事件接口。
- 不调整主导航。
- 不合并趋势预警、行情收件箱、情报监控页面。
- 不继续开发风险仪表盘。
- 影响项目或复核来源加载失败不得阻断事件本体详情展示。

---

### Task 1: 抽取 useMarketEventDetail

**Files:**
- Create: `frontend/src/composables/useMarketEventDetail.js`
- Create: `frontend/src/composables/__tests__/useMarketEventDetail.test.js`
- Modify: `frontend/src/views/MarketEvents.vue`

**Interfaces:**
- Produces: `useMarketEventDetail()` returns `{ detailVisible, selectedEvent, eventImpact, sourceSignal, detailLoading, openEventDetail, closeEventDetail }`
- Consumes: `getEvent`, `getEventImpact`, `getEventSourceSignal`

- [ ] 写 composable 失败测试：成功加载事件本体后打开详情，并加载 impact/sourceSignal。
- [ ] 写 composable 失败测试：impact/sourceSignal 失败时仍展示事件本体。
- [ ] 运行测试确认缺少模块失败。
- [ ] 实现 `useMarketEventDetail.js`。
- [ ] 跑 composable 测试通过。
- [ ] MarketEvents 改用 composable 的状态和 `openEventDetail`。
- [ ] 跑 MarketEvents 测试通过。

### Task 2: 趋势预警页内打开事件详情

**Files:**
- Modify: `frontend/src/views/MarketTrends.vue`
- Modify: `frontend/src/views/__tests__/MarketTrends.test.js`

**Interfaces:**
- Consumes: `useMarketEventDetail`, `MarketEventDetailDrawer`
- Produces: 行动队列“查看事件”在当前页打开详情；新增“前往事件库”跳转

- [ ] 写失败测试：点击行动队列“查看事件”调用事件详情接口并显示事件详情。
- [ ] 保留或新增测试：点击“前往事件库”跳转 `/events?eventId=xx`。
- [ ] 运行测试确认失败。
- [ ] 接入 composable 和 `MarketEventDetailDrawer`。
- [ ] 修改按钮：`查看事件` 当前页打开，`前往事件库` 跳转。
- [ ] 跑 MarketTrends 测试通过。

### Task 3: 行情收件箱页内打开生成事件详情

**Files:**
- Modify: `frontend/src/views/MarketInbox.vue`
- Modify: `frontend/src/views/__tests__/MarketInbox.test.js`

**Interfaces:**
- Consumes: `useMarketEventDetail`, `MarketEventDetailDrawer`
- Produces: 溯源抽屉“查看市场事件”当前页打开详情；新增“前往事件库”跳转

- [ ] 写失败测试：点击“查看市场事件”调用事件详情接口并显示详情。
- [ ] 写测试：点击“前往事件库”仍跳转 `/events?eventId=xx`。
- [ ] 运行测试确认失败。
- [ ] 接入 composable 和 `MarketEventDetailDrawer`。
- [ ] 修改按钮行为。
- [ ] 跑 MarketInbox 测试通过。

### Task 4: BOM 项目详情接入事件详情

**Files:**
- Modify: `frontend/src/views/BomProjectDetail.vue`
- Modify: `frontend/src/views/__tests__/BomProjectDetail.test.js`

**Interfaces:**
- Consumes: riskReport.high_risk_items[].market_evidence[].id
- Produces: 行情证据“查看详情”当前页打开统一事件详情

- [ ] 写失败测试：风险报告行情证据点击“查看详情”调用事件详情接口并显示详情。
- [ ] 运行测试确认失败。
- [ ] 接入 composable 和 `MarketEventDetailDrawer`。
- [ ] 为每条 `market_evidence` 增加“查看详情”按钮。
- [ ] 跑 BomProjectDetail 测试通过。

### Task 5: 文档和最终验证

**Files:**
- Modify: `docs/当前系统界面与功能说明书.md`

**Interfaces:**
- Produces: 更新后的系统说明书

- [ ] 更新说明书：趋势预警、行情收件箱、BOM 项目详情均支持页内事件详情。
- [ ] 运行目标测试：`npm run test -- --run src/composables/__tests__/useMarketEventDetail.test.js src/components/__tests__/MarketEventDetailDrawer.test.js src/views/__tests__/MarketEvents.test.js src/views/__tests__/MarketTrends.test.js src/views/__tests__/MarketInbox.test.js src/views/__tests__/BomProjectDetail.test.js`
- [ ] 运行前端构建：`npm run build`
