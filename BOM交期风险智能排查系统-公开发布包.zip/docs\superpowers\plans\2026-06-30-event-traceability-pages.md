# 事件溯源二三级页面与导出修复 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 修复导出不可用，并补齐市场事件、趋势预警、行情收件箱、情报监控的二三级详情和溯源链路。

**Architecture:** 前端优先沿用现有页面和抽屉详情模式，新增少量 API helper 和详情状态。市场事件作为统一事实中心，其他模块通过事件 ID、来源 URL、原始通知或采集记录回链到市场事件和信息源。

**Tech Stack:** Vue 3、Vue Router、Element Plus、Vitest、FastAPI、SQLAlchemy、Pytest。

## Global Constraints

- 必须使用 TDD：先写失败测试并确认失败原因，再修改生产代码。
- 风险仪表盘暂不扩展数据逻辑。
- 不引入新的外部依赖。
- 市场事件详情必须容错：影响项目或来源接口失败不阻断事件详情打开。
- 输出系统功能说明书和功能整合建议。

---

### Task 1: 修复 BOM HTML/Excel 导出

**Files:**
- Modify: `frontend/src/views/BomProjectDetail.vue`
- Modify: `frontend/src/views/__tests__/BomProjectDetail.test.js`

**Interfaces:**
- Consumes: `projectId` route param, `/api/risk/report/{id}/export.html`, `/api/risk/report/{id}/export.xlsx`
- Produces: `openHtmlReport()` and `downloadExcelReport()` stable behavior

- [ ] 新增失败测试：点击 HTML 导出打开 `/api/risk/report/1/export.html`。
- [ ] 新增失败测试：点击 Excel 导出设置 `window.location.href` 或创建下载链接到 `/api/risk/report/1/export.xlsx`。
- [ ] 运行前端测试确认失败。
- [ ] 修改导出函数，HTML 使用新窗口打开，Excel 使用稳定下载方式。
- [ ] 运行测试确认通过。

### Task 2: 修复市场事件详情并补齐溯源信息

**Files:**
- Modify: `frontend/src/views/MarketEvents.vue`
- Modify: `frontend/src/views/__tests__/MarketEvents.test.js`

**Interfaces:**
- Consumes: `getEvent(eventId)`, `getEventImpact(eventId)`, `getEventSourceSignal(eventId)`
- Produces: `openDetail(row)` always opens event drawer when event body loads

- [ ] 新增失败测试：影响项目接口失败时，点击查看详情仍显示事件标题。
- [ ] 新增失败测试：详情展示来源链接、风险等级和触发条件。
- [ ] 运行测试确认失败。
- [ ] 修改详情加载为分段容错，事件本体先打开，影响项目和来源失败时置空并提示。
- [ ] 补齐详情 UI 字段：来源链接、风险等级、触发条件、影响项目、复核来源。
- [ ] 运行测试确认通过。

### Task 3: 行情收件箱待复核队列增加溯源详情

**Files:**
- Modify: `frontend/src/views/MarketInbox.vue`
- Modify: `frontend/src/views/__tests__/MarketInbox.test.js`

**Interfaces:**
- Consumes: existing queue item fields: signal, notice, generated_event_id
- Produces: `openSignalTrace(item)` drawer

- [ ] 新增失败测试：点击“查看溯源”展示信号、原始通知、复核状态。
- [ ] 新增失败测试：有 `generated_event_id` 时显示“查看市场事件”入口并跳转。
- [ ] 运行测试确认失败。
- [ ] 增加溯源抽屉状态、打开函数和跳转函数。
- [ ] 在待复核队列操作区增加“查看溯源”。
- [ ] 运行测试确认通过。

### Task 4: 趋势预警补齐事件跳转和触发条件

**Files:**
- Modify: `frontend/src/views/MarketTrends.vue`
- Modify: `frontend/src/views/__tests__/MarketTrends.test.js`

**Interfaces:**
- Consumes: trend overview active/high risk/review/action events
- Produces: event detail navigation with risk level and trigger reason visible

- [ ] 新增失败测试：活跃事件列表点击“查看事件”跳转市场事件并带事件 ID。
- [ ] 新增失败测试：行动队列展示触发原因。
- [ ] 运行测试确认失败。
- [ ] 修改跳转函数，统一传递 `{ eventId }` query。
- [ ] 在趋势预警列表展示风险等级和触发原因。
- [ ] 运行测试确认通过。

### Task 5: 情报监控补齐二三级详情入口

**Files:**
- Modify: `frontend/src/views/IntelWatch.vue`
- Modify: `frontend/src/views/__tests__/IntelWatch.test.js`

**Interfaces:**
- Consumes: watch history, media sources, collection runs, event summary
- Produces: details drawers for watch command, media source, run record, event summary

- [ ] 新增失败测试：媒体源可点击打开详情。
- [ ] 新增失败测试：采集运行记录可点击打开详情。
- [ ] 新增失败测试：关注指令历史可点击打开详情。
- [ ] 运行测试确认失败。
- [ ] 增加详情抽屉状态和打开函数。
- [ ] 在对应列表增加详情按钮。
- [ ] 运行测试确认通过。

### Task 6: 系统功能说明书和整合建议

**Files:**
- Create: `docs/当前系统界面与功能说明书.md`

**Interfaces:**
- Produces: current UI/function manual and consolidation recommendation

- [ ] 编写系统页面清单、主要功能、二三级链路、导出说明。
- [ ] 写明市场事件、趋势预警、情报监控、行情收件箱的边界。
- [ ] 给出整合建议：保留市场事件为事实中心，趋势预警为分析行动层，情报监控为采集配置层，行情收件箱为人工复核入口。
- [ ] 运行后端目标测试、前端目标测试和前端构建。
