# 统一市场事件详情组件 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 把市场事件详情抽成可复用组件，并支持 `/events?eventId=xx` 自动打开事件详情。

**Architecture:** 新增 `MarketEventDetailDrawer.vue` 作为纯展示组件，父页面负责加载事件本体、影响项目和复核来源。`MarketEvents.vue` 保留列表、筛选、状态更新和路由解析逻辑，并通过 `eventId` query 调用统一打开函数。

**Tech Stack:** Vue 3、Vue Router、Element Plus、Vitest、Vue Test Utils。

## Global Constraints

- 必须使用 TDD：先写失败测试并确认失败原因，再修改生产代码。
- 不改后端事件接口。
- 不调整主导航。
- 不继续开发风险仪表盘。
- 影响项目或复核来源加载失败不得阻断事件本体详情展示。

---

### Task 1: 新增 MarketEventDetailDrawer 组件

**Files:**
- Create: `frontend/src/components/MarketEventDetailDrawer.vue`
- Create: `frontend/src/components/__tests__/MarketEventDetailDrawer.test.js`

**Interfaces:**
- Consumes props: `modelValue`, `event`, `impact`, `sourceSignal`, `operatingStatus`
- Emits: `update:modelValue`, `status-change`
- Produces reusable market event detail drawer

- [ ] **Step 1: Write failing component test**

Create `frontend/src/components/__tests__/MarketEventDetailDrawer.test.js` with tests that mount the component and assert it renders:

```js
import { mount } from '@vue/test-utils'
import MarketEventDetailDrawer from '../MarketEventDetailDrawer.vue'

const stubs = {
  'el-drawer': { props: ['modelValue', 'title'], template: '<section v-if="modelValue"><h2>{{ title }}</h2><slot /></section>' },
  'el-button': { props: ['loading'], emits: ['click'], template: '<button :disabled="loading" @click="$emit(\'click\')"><slot /></button>' }
}

const event = {
  id: 1,
  brand: 'TDK',
  category: 'high_cap_mlcc',
  event_type: 'price_increase',
  severity: 'high',
  confidence: 0.91,
  source_name: 'TDK代理商邮件',
  source_url: 'mail://tdk-notice-001',
  raw_title: 'TDK高容MLCC缺货涨价通知',
  raw_text_excerpt: 'TDK 高容MLCC 缺货，预计涨价 10%-20%，交期延长至 16 周',
  estimated_lead_time_impact_weeks: 16,
  estimated_price_impact_pct: 20,
  cross_validated: 0,
  created_at: '2026-06-27T10:00:00+00:00',
  is_active: 1
}

const impact = {
  project_count: 1,
  item_count: 2,
  risk_counts: { red: 1, yellow: 1, green: 0, gray: 0 },
  projects: [{ project_id: 10, project_name: '真实项目A', affected_item_count: 2, highest_risk_level: 'red' }]
}

const sourceSignal = {
  signal: { review_status: 'confirmed', reviewed_by: 'purchaser', review_notes: '电话复核属实', evidence_text: '供应商确认缺货涨价' },
  raw_notice: { source_type: 'email', source_name: '采购邮箱', sender: 'buyer@example.com', title: 'TDK MLCC 缺货涨价邮件', raw_text_excerpt: '供应商确认 TDK 高容 MLCC 缺货，交期 16 周。' }
}

describe('MarketEventDetailDrawer', () => {
  it('renders event source impact and audit context', () => {
    const wrapper = mount(MarketEventDetailDrawer, { props: { modelValue: true, event, impact, sourceSignal, operatingStatus: false }, global: { stubs } })
    const text = wrapper.text()
    expect(text).toContain('事件详情')
    expect(text).toContain('风险等级：高')
    expect(text).toContain('触发条件：严重度 高，置信度 91%，交期影响 16 周，价格影响 20%')
    expect(text).toContain('mail://tdk-notice-001')
    expect(text).toContain('真实项目A')
    expect(text).toContain('电话复核属实')
  })

  it('emits status-change when clicking disable', async () => {
    const wrapper = mount(MarketEventDetailDrawer, { props: { modelValue: true, event, impact: null, sourceSignal: null, operatingStatus: false }, global: { stubs } })
    await wrapper.find('[data-testid="events-disable"]').trigger('click')
    expect(wrapper.emitted('status-change')[0]).toEqual(['disable'])
  })
})
```

- [ ] **Step 2: Run test to verify it fails**

Run: `npm run test -- --run src/components/__tests__/MarketEventDetailDrawer.test.js`
Expected: FAIL because component file does not exist.

- [ ] **Step 3: Implement component**

Create `frontend/src/components/MarketEventDetailDrawer.vue` using the existing detail markup from `MarketEvents.vue`. Define props and emits. Move helper functions into the component: `displayValue`, `noticeSourceText`, `formatPercent`, `formatImpact`, `formatDate`, `labelFor`, `riskText`, `eventTriggerText`, `isActive`.

- [ ] **Step 4: Run component test**

Run: `npm run test -- --run src/components/__tests__/MarketEventDetailDrawer.test.js`
Expected: PASS.

### Task 2: 接入 MarketEvents 并保持原有详情行为

**Files:**
- Modify: `frontend/src/views/MarketEvents.vue`
- Modify: `frontend/src/views/__tests__/MarketEvents.test.js`

**Interfaces:**
- Consumes: `MarketEventDetailDrawer`
- Produces: `openDetail(row)` still loads event, impact and source signal; `changeEventStatus(action)` unchanged

- [ ] **Step 1: Update failing import/stub test expectations**

In `MarketEvents.test.js`, add stub for `MarketEventDetailDrawer` only if needed, or let real component render with existing Element Plus stubs. Keep existing tests intact.

- [ ] **Step 2: Refactor MarketEvents template**

Replace inline `<el-drawer>` with:

```vue
<MarketEventDetailDrawer
  v-model="detailVisible"
  :event="selectedEvent"
  :impact="eventImpact"
  :source-signal="sourceSignal"
  :operating-status="operatingStatus"
  @status-change="changeEventStatus"
/>
```

Import component from `../components/MarketEventDetailDrawer.vue`.

- [ ] **Step 3: Remove moved helper functions and CSS**

Remove helpers that only component uses. Keep helpers used by table/filter: `displayValue`, `formatPercent`, `formatImpact`, `formatDate`, `labelFor`, `severityTag`, `parseQueryIds`, `buildParams`, `openProject`.

- [ ] **Step 4: Run MarketEvents tests**

Run: `npm run test -- --run src/views/__tests__/MarketEvents.test.js`
Expected: PASS.

### Task 3: 支持 eventId query 自动打开详情

**Files:**
- Modify: `frontend/src/views/MarketEvents.vue`
- Modify: `frontend/src/views/__tests__/MarketEvents.test.js`

**Interfaces:**
- Produces: `openDetailById(eventId: string | number): Promise<void>`
- `loadEvents()` opens detail after list load when `route.query.eventId` exists

- [ ] **Step 1: Add failing test**

Add test to `MarketEvents.test.js`:

```js
it('automatically opens event detail from eventId route query', async () => {
  routeQuery = { eventId: '88' }
  api.listEvents.mockResolvedValue({ data: { total: 0, events: [] } })
  api.getEvent.mockResolvedValue({ data: { ...sampleEvent, id: 88, raw_title: '自动打开事件' } })

  const wrapper = mountMarketEvents()
  await flushPromises()

  expect(api.getEvent).toHaveBeenCalledWith('88')
  expect(wrapper.text()).toContain('事件详情')
  expect(wrapper.text()).toContain('自动打开事件')
})
```

- [ ] **Step 2: Run test to verify it fails**

Run: `npm run test -- --run src/views/__tests__/MarketEvents.test.js`
Expected: FAIL because `eventId` query is ignored.

- [ ] **Step 3: Implement `openDetailById`**

Extract shared loader:

```js
async function openDetailById(eventId) {
  selectedEvent.value = null
  eventImpact.value = null
  sourceSignal.value = null
  try {
    const { data: eventData } = await getEvent(eventId)
    selectedEvent.value = eventData
    detailVisible.value = true
  } catch (error) {
    ElMessage.error(error?.response?.data?.detail || '事件详情加载失败')
    return
  }
  try { eventImpact.value = (await getEventImpact(eventId)).data } catch { eventImpact.value = null }
  try { sourceSignal.value = (await getEventSourceSignal(eventId)).data } catch { sourceSignal.value = null }
}

async function openDetail(row) {
  return openDetailById(row.id)
}
```

Update `loadEvents()` after assigning list:

```js
if (route.query?.eventId) await openDetailById(route.query.eventId)
```

- [ ] **Step 4: Run tests**

Run: `npm run test -- --run src/views/__tests__/MarketEvents.test.js`
Expected: PASS.

### Task 4: Validate cross-page eventId chain

**Files:**
- Test: `frontend/src/views/__tests__/MarketInbox.test.js`
- Test: `frontend/src/views/__tests__/MarketTrends.test.js`

**Interfaces:**
- Existing outputs: `router.push({ path: '/events', query: { eventId } })`

- [ ] **Step 1: Run existing cross-page tests**

Run: `npm run test -- --run src/views/__tests__/MarketInbox.test.js src/views/__tests__/MarketTrends.test.js`
Expected: PASS. These already assert eventId query is sent.

### Task 5: Update docs and final verification

**Files:**
- Modify: `docs/当前系统界面与功能说明书.md`

**Interfaces:**
- Produces: updated manual noting reusable event detail drawer and eventId auto-open chain

- [ ] **Step 1: Update manual**

Add note under 市场事件 and 二三级链路: `/events?eventId=xx` 自动打开事件详情，详情组件已统一。

- [ ] **Step 2: Run target tests**

Run:
`npm run test -- --run src/components/__tests__/MarketEventDetailDrawer.test.js src/views/__tests__/MarketEvents.test.js src/views/__tests__/MarketInbox.test.js src/views/__tests__/MarketTrends.test.js`
Expected: PASS.

- [ ] **Step 3: Run frontend build**

Run: `npm run build`
Expected: PASS.
