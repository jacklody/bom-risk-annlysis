# 方案 B B6 通知渠道配置与发送适配 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在方案 B B5 通知记录和重复抑制基础上，实现安全的通知通道状态、测试发送适配、未配置真实通道阻断和前端展示。

**Architecture:** 后端在现有 `dashboard_notification` 服务中增加通道状态与发送适配边界，扩展通知记录审计字段，并继续复用 `/api/dashboard/notification/dispatch`。前端在风险仪表盘内加载通道状态，展示可用/未配置通道，并增加测试发送入口。

**Tech Stack:** FastAPI、SQLAlchemy、Pytest、Vue 3、Element Plus、Vitest、Axios。

## Global Constraints

- 必须使用 TDD：生产代码前先写失败测试，并确认失败原因正确。
- B6 不直接接入真实 SMTP、飞书或企业微信密钥。
- 真实通道未配置时必须返回阻断状态，不能外发。
- 保留 B5 `idempotency_key` 重复抑制行为。
- 不改变风险评分、风险变化摘要、报告导出逻辑。
- 不引入后台队列、定时器或新外部依赖。

---

## File Structure

- Modify: `backend/app/models/dashboard_notification.py`  
  扩展通知执行记录字段和 `to_dict()` 输出。
- Modify: `backend/app/services/dashboard_notification.py`  
  增加通道状态、发送适配器、发送结果落库逻辑。
- Modify: `backend/app/api/dashboard.py`  
  增加通道状态 API。
- Modify: `tests/test_dashboard_api.py`  
  增加 B6 后端行为测试。
- Modify: `frontend/src/api/dashboard.js`  
  增加通道状态 API helper。
- Modify: `frontend/src/views/RiskDashboard.vue`  
  展示通道状态、测试发送按钮和增强历史字段。
- Modify: `frontend/src/views/__tests__/RiskDashboard.test.js`  
  增加 B6 前端测试。
- Modify: `docs/方案B-B1阶段交付说明.md`  
  更新为 B1-B6 交付说明。

---

### Task 1: 后端通知通道状态 API

**Files:**
- Modify: `backend/app/services/dashboard_notification.py`
- Modify: `backend/app/api/dashboard.py`
- Test: `tests/test_dashboard_api.py`

**Interfaces:**
- Produces: `list_notification_channels() -> dict`
- Produces API: `GET /api/dashboard/notification/channels`

- [ ] **Step 1: Write the failing test**

在 `tests/test_dashboard_api.py` 末尾追加：

```python
def test_dashboard_notification_channels_returns_safe_channel_statuses():
    _clean_dashboard_data()

    resp = client.get("/api/dashboard/notification/channels")

    assert resp.status_code == 200
    channels = resp.json()["channels"]
    by_channel = {row["channel"]: row for row in channels}
    assert by_channel["manual"]["enabled"] is True
    assert by_channel["manual"]["configured"] is True
    assert by_channel["manual"]["external_delivery"] is False
    assert by_channel["mock"]["enabled"] is True
    assert by_channel["mock"]["configured"] is True
    assert by_channel["mock"]["external_delivery"] is True
    assert by_channel["email"]["enabled"] is False
    assert by_channel["email"]["configured"] is False
    assert by_channel["email"]["status"] == "not_configured"
    assert by_channel["feishu"]["status"] == "not_configured"
    assert by_channel["wecom"]["status"] == "not_configured"
```

- [ ] **Step 2: Run test to verify it fails**

Run from repo root:

```powershell
$env:PYTHONPATH='backend'; py -3.11 -m pytest tests/test_dashboard_api.py::test_dashboard_notification_channels_returns_safe_channel_statuses -q
```

Expected: FAIL with 404 or missing endpoint.

- [ ] **Step 3: Add service function**

In `backend/app/services/dashboard_notification.py`, add before dispatch function:

```python
def list_notification_channels() -> dict:
    return {
        "channels": [
            {
                "channel": "manual",
                "label": "人工通知",
                "enabled": True,
                "configured": True,
                "external_delivery": False,
                "status": "available",
                "message": "可生成通知内容，由人工复制发送。",
            },
            {
                "channel": "mock",
                "label": "测试通道",
                "enabled": True,
                "configured": True,
                "external_delivery": True,
                "status": "available",
                "message": "仅用于验证发送流程，不会触达外部系统。",
            },
            {
                "channel": "email",
                "label": "邮件",
                "enabled": False,
                "configured": False,
                "external_delivery": True,
                "status": "not_configured",
                "message": "邮件通道尚未配置，发送会被阻断。",
            },
            {
                "channel": "feishu",
                "label": "飞书",
                "enabled": False,
                "configured": False,
                "external_delivery": True,
                "status": "not_configured",
                "message": "飞书通道尚未配置，发送会被阻断。",
            },
            {
                "channel": "wecom",
                "label": "企业微信",
                "enabled": False,
                "configured": False,
                "external_delivery": True,
                "status": "not_configured",
                "message": "企业微信通道尚未配置，发送会被阻断。",
            },
        ]
    }
```

- [ ] **Step 4: Add API route**

In `backend/app/api/dashboard.py`, extend imports:

```python
from app.services.dashboard_notification import (
    build_dashboard_notification_preview,
    list_dashboard_notification_history,
    list_notification_channels,
    prepare_dashboard_notification_dispatch,
)
```

Add route before preview route:

```python
@router.get("/notification/channels")
def get_dashboard_notification_channels():
    return list_notification_channels()
```

- [ ] **Step 5: Run test to verify it passes**

```powershell
$env:PYTHONPATH='backend'; py -3.11 -m pytest tests/test_dashboard_api.py::test_dashboard_notification_channels_returns_safe_channel_statuses -q
```

Expected: PASS.

---

### Task 2: 后端发送结果审计字段与安全发送适配

**Files:**
- Modify: `backend/app/models/dashboard_notification.py`
- Modify: `backend/app/services/dashboard_notification.py`
- Test: `tests/test_dashboard_api.py`

**Interfaces:**
- Produces: `DashboardNotificationRecord.to_dict()` includes `provider`, `recipient_summary`, `failure_reason`, `retry_count`, `last_attempt_at`, `delivered_at`
- Produces: dispatch statuses `sent`, `blocked`, `prepared`, `skipped`, `suppressed`

- [ ] **Step 1: Write failing tests**

Append to `tests/test_dashboard_api.py`:

```python
def test_dashboard_notification_mock_channel_marks_record_as_sent():
    _clean_dashboard_data()
    _seed_dashboard_project()

    resp = client.post(
        "/api/dashboard/notification/dispatch",
        json={"channel": "mock", "idempotency_key": "mock-risk-20260630"},
    )
    history = client.get("/api/dashboard/notification/history")

    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "sent"
    assert data["channel"] == "mock"
    assert data["delivered"] is True
    assert data["external_delivery"] is True
    assert data["failure_reason"] is None
    assert data["recipient_summary"] == "测试收件人"
    assert data["delivered_at"]

    rows = history.json()["records"]
    record = next(row for row in rows if row["id"] == data["record_id"])
    assert record["status"] == "sent"
    assert record["provider"] == "mock"
    assert record["delivered"] is True
    assert record["external_delivery"] is True
    assert record["recipient_summary"] == "测试收件人"
    assert record["retry_count"] == 0
    assert record["delivered_at"]


def test_dashboard_notification_unconfigured_real_channel_is_blocked_without_delivery():
    _clean_dashboard_data()
    _seed_dashboard_project()

    resp = client.post(
        "/api/dashboard/notification/dispatch",
        json={"channel": "email", "idempotency_key": "email-risk-20260630"},
    )
    history = client.get("/api/dashboard/notification/history")

    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "blocked"
    assert data["channel"] == "email"
    assert data["delivered"] is False
    assert data["external_delivery"] is False
    assert data["failure_reason"] == "email 通道尚未配置，已阻断外发。"
    assert data["recipient_summary"] == "未配置收件人"
    assert data["delivered_at"] is None

    rows = history.json()["records"]
    record = next(row for row in rows if row["id"] == data["record_id"])
    assert record["status"] == "blocked"
    assert record["provider"] == "email"
    assert record["delivered"] is False
    assert record["external_delivery"] is False
    assert record["failure_reason"] == "email 通道尚未配置，已阻断外发。"
```

- [ ] **Step 2: Run tests to verify they fail**

```powershell
$env:PYTHONPATH='backend'; py -3.11 -m pytest tests/test_dashboard_api.py::test_dashboard_notification_mock_channel_marks_record_as_sent tests/test_dashboard_api.py::test_dashboard_notification_unconfigured_real_channel_is_blocked_without_delivery -q
```

Expected: FAIL because fields/statuses are missing.

- [ ] **Step 3: Extend model fields**

In `backend/app/models/dashboard_notification.py`, update imports if needed and add columns after `external_delivery`:

```python
    provider = Column(String(64), nullable=True)
    recipient_summary = Column(String(512), nullable=True)
    failure_reason = Column(Text, nullable=True)
    retry_count = Column(Integer, default=0, nullable=False)
    last_attempt_at = Column(DateTime, nullable=True)
    delivered_at = Column(DateTime, nullable=True)
```

Update `to_dict()`:

```python
            "provider": self.provider,
            "recipient_summary": self.recipient_summary,
            "failure_reason": self.failure_reason,
            "retry_count": self.retry_count or 0,
            "last_attempt_at": self.last_attempt_at.isoformat() if self.last_attempt_at else None,
            "delivered_at": self.delivered_at.isoformat() if self.delivered_at else None,
```

- [ ] **Step 4: Add send adapter helper**

In `backend/app/services/dashboard_notification.py`, add before dispatch:

```python
def _send_with_channel(channel: str, preview: dict) -> dict:
    normalized_channel = channel or "manual"
    attempted_at = datetime.now(timezone.utc)
    if normalized_channel == "manual":
        if preview["ready"]:
            return {
                "status": "prepared",
                "delivered": False,
                "external_delivery": False,
                "provider": "manual",
                "recipient_summary": "人工发送",
                "failure_reason": None,
                "message": "通知内容已准备完成，请在正式通知通道接入后发送。",
                "last_attempt_at": attempted_at,
                "delivered_at": None,
            }
        return {
            "status": "skipped",
            "delivered": False,
            "external_delivery": False,
            "provider": "manual",
            "recipient_summary": "人工发送",
            "failure_reason": None,
            "message": "暂无可通知的风险变化，已跳过发送准备。",
            "last_attempt_at": attempted_at,
            "delivered_at": None,
        }
    if normalized_channel == "mock":
        if preview["ready"]:
            return {
                "status": "sent",
                "delivered": True,
                "external_delivery": True,
                "provider": "mock",
                "recipient_summary": "测试收件人",
                "failure_reason": None,
                "message": "测试通知已发送，未触达外部系统。",
                "last_attempt_at": attempted_at,
                "delivered_at": attempted_at,
            }
        return {
            "status": "skipped",
            "delivered": False,
            "external_delivery": False,
            "provider": "mock",
            "recipient_summary": "测试收件人",
            "failure_reason": None,
            "message": "暂无可通知的风险变化，已跳过测试发送。",
            "last_attempt_at": attempted_at,
            "delivered_at": None,
        }
    return {
        "status": "blocked",
        "delivered": False,
        "external_delivery": False,
        "provider": normalized_channel,
        "recipient_summary": "未配置收件人",
        "failure_reason": f"{normalized_channel} 通道尚未配置，已阻断外发。",
        "message": f"{normalized_channel} 通道尚未配置，已阻断外发。",
        "last_attempt_at": attempted_at,
        "delivered_at": None,
    }
```

- [ ] **Step 5: Update dispatch persistence**

In `prepare_dashboard_notification_dispatch`, replace status/message assignment and record creation with:

```python
    preview = build_dashboard_notification_preview(db, channel=channel)
    send_result = _send_with_channel(preview["channel"], preview)
    record = DashboardNotificationRecord(
        channel=preview["channel"],
        status=send_result["status"],
        idempotency_key=idempotency_key,
        subject=preview["subject"],
        body=preview["body"],
        preview_json=json.dumps(preview, ensure_ascii=False),
        delivered=1 if send_result["delivered"] else 0,
        external_delivery=1 if send_result["external_delivery"] else 0,
        message=send_result["message"],
        provider=send_result["provider"],
        recipient_summary=send_result["recipient_summary"],
        failure_reason=send_result["failure_reason"],
        retry_count=0,
        last_attempt_at=send_result["last_attempt_at"],
        delivered_at=send_result["delivered_at"],
    )
```

Update return object after `db.refresh(record)`:

```python
    return {
        "status": record.status,
        "channel": preview["channel"],
        "delivered": bool(record.delivered),
        "external_delivery": bool(record.external_delivery),
        "deduplicated": False,
        "record_id": record.id,
        "preview": preview,
        "message": record.message,
        "provider": record.provider,
        "recipient_summary": record.recipient_summary,
        "failure_reason": record.failure_reason,
        "retry_count": record.retry_count or 0,
        "last_attempt_at": record.last_attempt_at.isoformat() if record.last_attempt_at else None,
        "delivered_at": record.delivered_at.isoformat() if record.delivered_at else None,
        "prepared_at": record.created_at.isoformat() if record.created_at else _now_iso(),
    }
```

- [ ] **Step 6: Run tests to verify they pass**

```powershell
$env:PYTHONPATH='backend'; py -3.11 -m pytest tests/test_dashboard_api.py::test_dashboard_notification_mock_channel_marks_record_as_sent tests/test_dashboard_api.py::test_dashboard_notification_unconfigured_real_channel_is_blocked_without_delivery -q
```

Expected: PASS.

---

### Task 3: 前端通道状态与测试发送入口

**Files:**
- Modify: `frontend/src/api/dashboard.js`
- Modify: `frontend/src/views/RiskDashboard.vue`
- Test: `frontend/src/views/__tests__/RiskDashboard.test.js`

**Interfaces:**
- Produces: `getDashboardNotificationChannels() -> client.get('/dashboard/notification/channels')`
- Consumes: `dispatchDashboardNotification({ channel: 'mock' })`

- [ ] **Step 1: Write failing frontend test**

In `frontend/src/views/__tests__/RiskDashboard.test.js`, extend dashboard API mock with `getDashboardNotificationChannels: vi.fn()`.

Add fixture:

```javascript
const notificationChannels = {
  channels: [
    { channel: 'manual', label: '人工通知', enabled: true, configured: true, external_delivery: false, status: 'available' },
    { channel: 'mock', label: '测试通道', enabled: true, configured: true, external_delivery: true, status: 'available' },
    { channel: 'email', label: '邮件', enabled: false, configured: false, external_delivery: true, status: 'not_configured' }
  ]
}
```

In `beforeEach`, add:

```javascript
dashboardApi.getDashboardNotificationChannels.mockResolvedValue({ data: notificationChannels })
```

Add test:

```javascript
it('展示通知通道状态并支持发送测试通知', async () => {
  dashboardApi.getDashboardSummary.mockResolvedValue({ data: summaryPayload })
  dashboardApi.getDashboardNotificationPreview.mockResolvedValue({ data: notificationPreview })
  dashboardApi.dispatchDashboardNotification.mockResolvedValue({
    data: {
      status: 'sent',
      message: '测试通知已发送，未触达外部系统。',
      preview: notificationPreview
    }
  })

  const wrapper = mount(RiskDashboard, { global: { stubs, directives: { loading: {} } } })
  await flushPromises()

  expect(dashboardApi.getDashboardNotificationChannels).toHaveBeenCalled()
  expect(wrapper.text()).toContain('通知通道')
  expect(wrapper.text()).toContain('测试通道')
  expect(wrapper.text()).toContain('未配置')

  await wrapper.find('[data-testid="send-test-notification"]').trigger('click')

  expect(dashboardApi.dispatchDashboardNotification).toHaveBeenCalledWith({ channel: 'mock' })
})
```

- [ ] **Step 2: Run frontend test to verify it fails**

```powershell
npm run test -- --run src/views/__tests__/RiskDashboard.test.js
```

Expected: FAIL because API helper/UI are missing.

- [ ] **Step 3: Add API helper**

In `frontend/src/api/dashboard.js`, add:

```javascript
export function getDashboardNotificationChannels() {
  return client.get('/dashboard/notification/channels')
}
```

- [ ] **Step 4: Update RiskDashboard imports and state**

In `RiskDashboard.vue`, update import:

```javascript
import { dispatchDashboardNotification, getDashboardNotificationChannels, getDashboardNotificationHistory, getDashboardNotificationPreview, getDashboardSummary } from '../api/dashboard'
```

Add state:

```javascript
const notificationChannels = ref([])
const testNotificationSending = ref(false)
```

- [ ] **Step 5: Load channel statuses**

Update `loadSummary()` Promise.all:

```javascript
const [{ data }, previewResp, historyResp, channelsResp] = await Promise.all([
  getDashboardSummary(),
  getDashboardNotificationPreview('manual'),
  getDashboardNotificationHistory(20),
  getDashboardNotificationChannels()
])
summary.value = data
notificationPreview.value = previewResp.data
notificationHistory.value = historyResp.data?.records || []
notificationChannels.value = channelsResp.data?.channels || []
```

- [ ] **Step 6: Add test send function**

Add after `prepareNotification()`:

```javascript
async function sendTestNotification() {
  testNotificationSending.value = true
  try {
    const { data } = await dispatchDashboardNotification({ channel: 'mock' })
    ElMessage.success(data?.message || '测试通知已发送')
    notificationPreview.value = data?.preview || notificationPreview.value
    const historyResp = await getDashboardNotificationHistory(20)
    notificationHistory.value = historyResp.data?.records || []
  } catch (error) {
    ElMessage.error(error?.response?.data?.detail || '测试通知发送失败')
  } finally {
    testNotificationSending.value = false
  }
}
```

Update expose:

```javascript
defineExpose({ openProject, openEvent, openAction, loadSummary, prepareNotification, sendTestNotification })
```

- [ ] **Step 7: Add template block**

Add after notification preview box:

```vue
<div class="notification-channel-box">
  <div class="channel-header">
    <h4>通知通道</h4>
    <el-button
      type="success"
      plain
      data-testid="send-test-notification"
      :loading="testNotificationSending"
      :disabled="notificationPreview.ready === false"
      @click="sendTestNotification"
    >
      发送测试通知
    </el-button>
  </div>
  <div class="channel-list">
    <div v-for="channel in notificationChannels" :key="channel.channel" class="channel-row">
      <span>{{ channel.label }}</span>
      <span>{{ channel.configured ? '已配置' : '未配置' }}</span>
      <span>{{ channel.external_delivery ? '外发通道' : '人工处理' }}</span>
    </div>
  </div>
</div>
```

- [ ] **Step 8: Add styles**

Add near notification styles:

```css
.notification-channel-box { padding: 12px; margin-bottom: 12px; border-radius: 10px; background: #f6ffed; }
.channel-header { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 8px; }
.channel-header h4 { margin: 0; color: #303133; }
.channel-list { display: flex; flex-direction: column; gap: 6px; }
.channel-row { display: grid; grid-template-columns: 1fr 90px 90px; gap: 10px; padding: 8px 0; border-top: 1px solid #e1f3d8; color: #606266; }
```

- [ ] **Step 9: Run frontend test to verify it passes**

```powershell
npm run test -- --run src/views/__tests__/RiskDashboard.test.js
```

Expected: PASS.

---

### Task 4: 交付文档与目标验证

**Files:**
- Modify: `docs/方案B-B1阶段交付说明.md`

**Interfaces:**
- Produces: B1-B6 delivery note

- [ ] **Step 1: Update delivery doc title and scope**

Change title to:

```markdown
# 方案 B B1-B6 阶段交付说明
```

Update scope paragraph to mention B6:

```markdown
方案 B 已完成 B1 风险仪表盘、HTML 报告导出，B2 Excel 报告导出，B3 风险变化摘要，B4 通知预览与手动通知准备，B5 通知执行记录、历史查询和重复通知抑制，以及 B6 通知渠道状态、安全发送适配和测试通道能力。
```

- [ ] **Step 2: Add B6 section**

Add after B5 section:

```markdown
### 通知渠道配置与安全发送适配

B6 新增通知通道状态查询和安全发送适配边界：

- `GET /api/dashboard/notification/channels` 返回人工通知、测试通道以及邮件、飞书、企业微信等真实通道占位状态。
- `POST /api/dashboard/notification/dispatch` 支持 `mock` 测试通道，可验证发送成功、执行记录落库和前端历史刷新。
- 未配置的真实通道会返回 `blocked`，不会标记为已发送，也不会触达外部系统。
- 通知执行记录新增 provider、收件人摘要、失败原因、重试次数、最近尝试时间和实际发送时间等审计字段。
- 前端“风险变化摘要”新增通知通道状态展示和“发送测试通知”入口。
```

- [ ] **Step 3: Run backend target tests**

```powershell
$env:PYTHONPATH='backend'; py -3.11 -m pytest tests/test_risk_report_export.py tests/test_dashboard_api.py -q
```

Expected: all pass.

- [ ] **Step 4: Run frontend target tests**

```powershell
npm run test -- --run src/views/__tests__/BomProjectDetail.test.js src/views/__tests__/RiskDashboard.test.js
```

Expected: all pass.

- [ ] **Step 5: Run frontend build**

```powershell
npm run build
```

Expected: build succeeds. Existing Vite large chunk and third-party PURE annotation warnings may remain non-blocking.
