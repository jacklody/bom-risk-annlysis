# 方案 B B7 SMTP 邮件通知通道 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在 B6 通知适配器基础上接入 SMTP 邮件真实发送通道，并保证未配置时安全阻断、发送结果可审计。

**Architecture:** 后端通过 `Settings` 读取 SMTP 配置，在 `dashboard_notification` 服务内增加邮件配置状态、SMTP 发送函数和失败处理。前端继续复用通知通道状态接口，在邮件通道可用时展示发送入口，并调用现有 dispatch API。

**Tech Stack:** FastAPI、SQLAlchemy、Pydantic Settings、Python 标准库 smtplib/email、Pytest、Vue 3、Element Plus、Vitest、Axios。

## Global Constraints

- 必须使用 TDD：生产代码前先写失败测试，并确认失败原因正确。
- SMTP 密码不得出现在 API 响应、通知历史、前端页面或文档示例以外的运行输出中。
- 未配置或未启用 SMTP 时必须安全阻断，不外发。
- B7 不实现前端录入 SMTP 密码。
- B7 不引入后台队列、定时任务或新外部依赖。
- 保留 B1-B6 现有 manual、mock、history、idempotency_key 行为。

---

## File Structure

- Modify: `backend/app/config.py`  
  增加 SMTP 邮件通知配置项。
- Modify: `backend/app/services/dashboard_notification.py`  
  增加邮件通道配置判断、SMTP 发送函数和 email 分支。
- Modify: `tests/test_dashboard_api.py`  
  增加 SMTP 未配置、配置成功、发送失败测试。
- Modify: `frontend/src/views/RiskDashboard.vue`  
  增加邮件发送按钮。
- Modify: `frontend/src/views/__tests__/RiskDashboard.test.js`  
  增加邮件通道前端测试。
- Modify: `docs/方案B-B1阶段交付说明.md`  
  更新为 B1-B7。

---

### Task 1: SMTP 配置项与邮件通道状态

**Files:**
- Modify: `backend/app/config.py`
- Modify: `backend/app/services/dashboard_notification.py`
- Test: `tests/test_dashboard_api.py`

**Interfaces:**
- Produces settings fields: `notification_email_enabled`, `notification_email_smtp_host`, `notification_email_smtp_port`, `notification_email_username`, `notification_email_password`, `notification_email_sender`, `notification_email_recipients`, `notification_email_use_tls`, `notification_email_timeout`
- Produces helper: `_email_config_status() -> dict`

- [ ] **Step 1: Write failing test for configured email channel**

Append to `tests/test_dashboard_api.py`:

```python
def test_dashboard_notification_email_channel_available_when_smtp_configured(monkeypatch):
    from app.config import settings

    monkeypatch.setattr(settings, "notification_email_enabled", True)
    monkeypatch.setattr(settings, "notification_email_smtp_host", "smtp.example.com")
    monkeypatch.setattr(settings, "notification_email_smtp_port", 587)
    monkeypatch.setattr(settings, "notification_email_sender", "notice@example.com")
    monkeypatch.setattr(settings, "notification_email_recipients", "buyer@example.com,pm@example.com")

    resp = client.get("/api/dashboard/notification/channels")

    assert resp.status_code == 200
    by_channel = {row["channel"]: row for row in resp.json()["channels"]}
    assert by_channel["email"]["enabled"] is True
    assert by_channel["email"]["configured"] is True
    assert by_channel["email"]["status"] == "available"
    assert by_channel["email"]["message"] == "邮件通道已配置，可发送真实邮件通知。"
```

- [ ] **Step 2: Run test to verify it fails**

```powershell
$env:PYTHONPATH='backend'; py -3.11 -m pytest tests/test_dashboard_api.py::test_dashboard_notification_email_channel_available_when_smtp_configured -q
```

Expected: FAIL because settings fields or email channel status logic are missing.

- [ ] **Step 3: Add settings**

In `backend/app/config.py`, add before `model_config`:

```python
    # 邮件通知 — SMTP 通道，默认关闭，必须显式配置后才允许外发
    notification_email_enabled: bool = False
    notification_email_smtp_host: str = ""
    notification_email_smtp_port: int = 587
    notification_email_username: str = ""
    notification_email_password: str = ""
    notification_email_sender: str = ""
    notification_email_recipients: str = ""
    notification_email_use_tls: bool = True
    notification_email_timeout: float = 10.0
```

- [ ] **Step 4: Add email config helpers**

In `backend/app/services/dashboard_notification.py`, add imports:

```python
from app.config import settings
```

Add before `list_notification_channels()`:

```python
def _parse_email_recipients() -> list[str]:
    return [item.strip() for item in (settings.notification_email_recipients or "").split(",") if item.strip()]


def _email_recipient_summary(recipients: list[str]) -> str:
    return f"{len(recipients)} 个收件人" if recipients else "未配置收件人"


def _email_config_status() -> dict:
    recipients = _parse_email_recipients()
    configured = bool(
        settings.notification_email_enabled
        and settings.notification_email_smtp_host
        and settings.notification_email_smtp_port > 0
        and settings.notification_email_sender
        and recipients
    )
    return {
        "configured": configured,
        "enabled": configured,
        "recipients": recipients,
        "recipient_summary": _email_recipient_summary(recipients),
    }
```

- [ ] **Step 5: Update email channel status**

In `list_notification_channels()`, assign before return:

```python
    email_status = _email_config_status()
```

Replace the email channel dict with:

```python
            {
                "channel": "email",
                "label": "邮件",
                "enabled": email_status["enabled"],
                "configured": email_status["configured"],
                "external_delivery": True,
                "status": "available" if email_status["configured"] else "not_configured",
                "message": "邮件通道已配置，可发送真实邮件通知。" if email_status["configured"] else "邮件通道尚未配置，发送会被阻断。",
            },
```

- [ ] **Step 6: Run test to verify it passes**

```powershell
$env:PYTHONPATH='backend'; py -3.11 -m pytest tests/test_dashboard_api.py::test_dashboard_notification_email_channel_available_when_smtp_configured -q
```

Expected: PASS.

---

### Task 2: SMTP 发送成功与失败处理

**Files:**
- Modify: `backend/app/services/dashboard_notification.py`
- Test: `tests/test_dashboard_api.py`

**Interfaces:**
- Produces helper: `_send_email_notification(preview: dict) -> dict`
- Consumes: existing `_send_with_channel(channel: str, preview: dict) -> dict`

- [ ] **Step 1: Write failing SMTP success test**

Append to `tests/test_dashboard_api.py`:

```python
def test_dashboard_notification_email_dispatch_sends_smtp_and_records_history(monkeypatch):
    from app.config import settings
    import app.services.dashboard_notification as notification_service

    _clean_dashboard_data()
    _seed_dashboard_project()

    sent_messages = []

    class FakeSMTP:
        def __init__(self, host, port, timeout):
            self.host = host
            self.port = port
            self.timeout = timeout

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def starttls(self):
            self.started_tls = True

        def login(self, username, password):
            self.username = username
            self.password = password

        def send_message(self, message):
            sent_messages.append(message)

    monkeypatch.setattr(settings, "notification_email_enabled", True)
    monkeypatch.setattr(settings, "notification_email_smtp_host", "smtp.example.com")
    monkeypatch.setattr(settings, "notification_email_smtp_port", 587)
    monkeypatch.setattr(settings, "notification_email_username", "notice@example.com")
    monkeypatch.setattr(settings, "notification_email_password", "secret-token")
    monkeypatch.setattr(settings, "notification_email_sender", "notice@example.com")
    monkeypatch.setattr(settings, "notification_email_recipients", "buyer@example.com,pm@example.com")
    monkeypatch.setattr(settings, "notification_email_use_tls", True)
    monkeypatch.setattr(notification_service.smtplib, "SMTP", FakeSMTP)

    resp = client.post(
        "/api/dashboard/notification/dispatch",
        json={"channel": "email", "idempotency_key": "email-smtp-success-20260630"},
    )
    history = client.get("/api/dashboard/notification/history")

    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "sent"
    assert data["channel"] == "email"
    assert data["delivered"] is True
    assert data["external_delivery"] is True
    assert data["provider"] == "email"
    assert data["recipient_summary"] == "2 个收件人"
    assert data["failure_reason"] is None
    assert data["delivered_at"]
    assert len(sent_messages) == 1
    assert sent_messages[0]["Subject"] == "BOM风险变化提醒：新增红色风险1项，黄色风险2项"
    assert sent_messages[0]["From"] == "notice@example.com"
    assert sent_messages[0]["To"] == "buyer@example.com, pm@example.com"
    assert "secret-token" not in str(history.json())

    rows = history.json()["records"]
    record = next(row for row in rows if row["id"] == data["record_id"])
    assert record["status"] == "sent"
    assert record["provider"] == "email"
    assert record["recipient_summary"] == "2 个收件人"
```

- [ ] **Step 2: Write failing SMTP failure test**

Append to `tests/test_dashboard_api.py`:

```python
def test_dashboard_notification_email_dispatch_records_smtp_failure(monkeypatch):
    from app.config import settings
    import app.services.dashboard_notification as notification_service

    _clean_dashboard_data()
    _seed_dashboard_project()

    class FailingSMTP:
        def __init__(self, host, port, timeout):
            pass

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def starttls(self):
            pass

        def login(self, username, password):
            pass

        def send_message(self, message):
            raise RuntimeError("network down")

    monkeypatch.setattr(settings, "notification_email_enabled", True)
    monkeypatch.setattr(settings, "notification_email_smtp_host", "smtp.example.com")
    monkeypatch.setattr(settings, "notification_email_smtp_port", 587)
    monkeypatch.setattr(settings, "notification_email_sender", "notice@example.com")
    monkeypatch.setattr(settings, "notification_email_recipients", "buyer@example.com")
    monkeypatch.setattr(settings, "notification_email_use_tls", True)
    monkeypatch.setattr(notification_service.smtplib, "SMTP", FailingSMTP)

    resp = client.post(
        "/api/dashboard/notification/dispatch",
        json={"channel": "email", "idempotency_key": "email-smtp-failed-20260630"},
    )

    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "failed"
    assert data["delivered"] is False
    assert data["external_delivery"] is True
    assert data["provider"] == "email"
    assert data["recipient_summary"] == "1 个收件人"
    assert data["failure_reason"] == "SMTP发送失败：network down"
    assert data["delivered_at"] is None
```

- [ ] **Step 3: Run tests to verify they fail**

```powershell
$env:PYTHONPATH='backend'; py -3.11 -m pytest tests/test_dashboard_api.py::test_dashboard_notification_email_dispatch_sends_smtp_and_records_history tests/test_dashboard_api.py::test_dashboard_notification_email_dispatch_records_smtp_failure -q
```

Expected: FAIL because SMTP send helper is missing.

- [ ] **Step 4: Add SMTP imports**

In `backend/app/services/dashboard_notification.py`, add imports:

```python
import smtplib
from email.message import EmailMessage
```

- [ ] **Step 5: Add email send helper**

Add before `_send_with_channel()`:

```python
def _send_email_notification(preview: dict) -> dict:
    attempted_at = datetime.now(timezone.utc)
    email_status = _email_config_status()
    if not email_status["configured"]:
        return {
            "status": "blocked",
            "delivered": False,
            "external_delivery": False,
            "provider": "email",
            "recipient_summary": "未配置收件人",
            "failure_reason": "email 通道尚未配置，已阻断外发。",
            "message": "email 通道尚未配置，已阻断外发。",
            "last_attempt_at": attempted_at,
            "delivered_at": None,
        }

    recipients = email_status["recipients"]
    recipient_summary = email_status["recipient_summary"]
    message = EmailMessage()
    message["Subject"] = preview["subject"]
    message["From"] = settings.notification_email_sender
    message["To"] = ", ".join(recipients)
    message.set_content(preview["body"])

    try:
        with smtplib.SMTP(
            settings.notification_email_smtp_host,
            settings.notification_email_smtp_port,
            timeout=settings.notification_email_timeout,
        ) as smtp:
            if settings.notification_email_use_tls:
                smtp.starttls()
            if settings.notification_email_username and settings.notification_email_password:
                smtp.login(settings.notification_email_username, settings.notification_email_password)
            smtp.send_message(message)
    except Exception as exc:
        failure_reason = f"SMTP发送失败：{exc}"
        return {
            "status": "failed",
            "delivered": False,
            "external_delivery": True,
            "provider": "email",
            "recipient_summary": recipient_summary,
            "failure_reason": failure_reason,
            "message": failure_reason,
            "last_attempt_at": attempted_at,
            "delivered_at": None,
        }

    return {
        "status": "sent",
        "delivered": True,
        "external_delivery": True,
        "provider": "email",
        "recipient_summary": recipient_summary,
        "failure_reason": None,
        "message": "邮件通知已发送。",
        "last_attempt_at": attempted_at,
        "delivered_at": attempted_at,
    }
```

- [ ] **Step 6: Route email channel to SMTP helper**

In `_send_with_channel()`, add before final fallback return:

```python
    if normalized_channel == "email":
        if not preview["ready"]:
            return {
                "status": "skipped",
                "delivered": False,
                "external_delivery": False,
                "provider": "email",
                "recipient_summary": _email_config_status()["recipient_summary"],
                "failure_reason": None,
                "message": "暂无可通知的风险变化，已跳过邮件发送。",
                "last_attempt_at": attempted_at,
                "delivered_at": None,
            }
        return _send_email_notification(preview)
```

- [ ] **Step 7: Run tests to verify they pass**

```powershell
$env:PYTHONPATH='backend'; py -3.11 -m pytest tests/test_dashboard_api.py::test_dashboard_notification_email_dispatch_sends_smtp_and_records_history tests/test_dashboard_api.py::test_dashboard_notification_email_dispatch_records_smtp_failure -q
```

Expected: PASS.

---

### Task 3: 前端邮件发送入口

**Files:**
- Modify: `frontend/src/views/RiskDashboard.vue`
- Test: `frontend/src/views/__tests__/RiskDashboard.test.js`

**Interfaces:**
- Consumes: existing `notificationChannels` rows with `channel`, `configured`, `enabled`
- Consumes: `dispatchDashboardNotification({ channel: 'email' })`

- [ ] **Step 1: Write failing frontend test**

In `frontend/src/views/__tests__/RiskDashboard.test.js`, add configured email fixture near existing `notificationChannels`:

```javascript
const notificationChannelsWithEmail = {
  channels: [
    { channel: 'manual', label: '人工通知', enabled: true, configured: true, external_delivery: false, status: 'available' },
    { channel: 'mock', label: '测试通道', enabled: true, configured: true, external_delivery: true, status: 'available' },
    { channel: 'email', label: '邮件', enabled: true, configured: true, external_delivery: true, status: 'available' }
  ]
}
```

Add test:

```javascript
it('邮件通道已配置时支持发送邮件通知', async () => {
  dashboardApi.getDashboardSummary.mockResolvedValue({ data: summaryPayload })
  dashboardApi.getDashboardNotificationPreview.mockResolvedValue({ data: notificationPreview })
  dashboardApi.getDashboardNotificationChannels.mockResolvedValue({ data: notificationChannelsWithEmail })
  dashboardApi.dispatchDashboardNotification.mockResolvedValue({
    data: {
      status: 'sent',
      message: '邮件通知已发送。',
      preview: notificationPreview
    }
  })

  const wrapper = mount(RiskDashboard, { global: { stubs, directives: { loading: {} } } })
  await flushPromises()

  expect(wrapper.text()).toContain('发送邮件通知')

  await wrapper.find('[data-testid="send-email-notification"]').trigger('click')

  expect(dashboardApi.dispatchDashboardNotification).toHaveBeenCalledWith({ channel: 'email' })
})
```

- [ ] **Step 2: Run frontend test to verify it fails**

```powershell
npm run test -- --run src/views/__tests__/RiskDashboard.test.js
```

Expected: FAIL because email button/function is missing.

- [ ] **Step 3: Add computed email channel availability**

In `RiskDashboard.vue`, ensure import includes `computed`, then add:

```javascript
const emailChannelAvailable = computed(() => notificationChannels.value.some(
  channel => channel.channel === 'email' && channel.enabled && channel.configured
))
```

- [ ] **Step 4: Add send email function**

Add after `sendTestNotification()`:

```javascript
async function sendEmailNotification() {
  testNotificationSending.value = true
  try {
    const { data } = await dispatchDashboardNotification({ channel: 'email' })
    ElMessage.success(data?.message || '邮件通知已发送')
    notificationPreview.value = data?.preview || notificationPreview.value
    const historyResp = await getDashboardNotificationHistory(20)
    notificationHistory.value = historyResp.data?.records || []
  } catch (error) {
    ElMessage.error(error?.response?.data?.detail || '邮件通知发送失败')
  } finally {
    testNotificationSending.value = false
  }
}
```

Update expose:

```javascript
defineExpose({ openProject, openEvent, openAction, loadSummary, prepareNotification, sendTestNotification, sendEmailNotification })
```

- [ ] **Step 5: Add email button**

In `.channel-header`, after test notification button, add:

```vue
<el-button
  v-if="emailChannelAvailable"
  type="warning"
  plain
  data-testid="send-email-notification"
  :loading="testNotificationSending"
  :disabled="notificationPreview.ready === false"
  @click="sendEmailNotification"
>
  发送邮件通知
</el-button>
```

- [ ] **Step 6: Run frontend test to verify it passes**

```powershell
npm run test -- --run src/views/__tests__/RiskDashboard.test.js
```

Expected: PASS.

---

### Task 4: 交付文档与目标验证

**Files:**
- Modify: `docs/方案B-B1阶段交付说明.md`

**Interfaces:**
- Produces: B1-B7 delivery note

- [ ] **Step 1: Update delivery doc title and scope**

Change title to:

```markdown
# 方案 B B1-B7 阶段交付说明
```

Update scope paragraph to mention B7 SMTP 邮件通知通道。

- [ ] **Step 2: Add B7 section**

Add after B6 section:

```markdown
### SMTP 邮件通知通道

B7 将邮件作为首个真实通知通道接入：

- 后端新增 SMTP 邮件通知配置项，支持通过 `.env` 或环境变量启用。
- `GET /api/dashboard/notification/channels` 可根据 SMTP 配置返回邮件通道是否可用。
- `POST /api/dashboard/notification/dispatch` 支持 `channel=email`，配置完整时发送真实邮件。
- SMTP 发送成功记录为 `sent`，失败记录为 `failed` 并保存失败原因。
- SMTP 未配置或未启用时继续返回 `blocked`，不会外发。
- 前端在邮件通道可用时展示“发送邮件通知”入口。
- SMTP 密码不会进入 API 响应、通知历史或前端页面。
```

- [ ] **Step 3: Run backend target tests**

```powershell
$env:PYTHONPATH='backend'; py -3.11 -m pytest tests/test_risk_report_export.py tests/test_dashboard_api.py -q
```

Expected: all pass.

- [ ] **Step 4: Run frontend target tests**

```powershell
npm run test -- --run src/views/__tests__/BomProjectDetail.test.js src/views/__tests__/RiskDashboard.test.js
```

Expected: all pass.

- [ ] **Step 5: Run frontend build**

```powershell
npm run build
```

Expected: build succeeds. Existing Vite large chunk and third-party PURE annotation warnings may remain non-blocking.
