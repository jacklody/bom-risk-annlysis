# 风险链路驾驶舱 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 新增“风险链路驾驶舱”作为系统默认首页，把行情/事件、上游材料链、BOM 类别、具体料号影响和执行策略串成一条可解释的风险链路。

**Architecture:** 后端新增一个只读聚合接口 `/api/risk-chain/dashboard`，先复用现有事件、材料和 BOM 风险能力，并提供稳定的驾驶舱数据结构。前端新增 `RiskChainDashboard.vue` 和 `riskChain.js`，将现有分散页面收敛到一个主入口；旧页面保留为二级入口或详情入口。

**Tech Stack:** FastAPI、Pydantic、SQLAlchemy、pytest、Vue 3、Vue Router、Element Plus、Axios、Vitest。

## Global Constraints

- 不推倒重做现有系统；保留 BOM 上传、BOM 项目、市场事件、行情收件箱、原材料追踪、趋势验证、优选库等既有能力。
- 默认首页从上传分析改为风险链路驾驶舱。
- 主菜单收敛为五类入口：风险链路驾驶舱、BOM 项目分析、行情与事件中心、材料链路库、策略与优选库。
- 每个高风险 BOM 料号需要能解释：由哪个外部信号触发、经过哪些上游材料链路、影响哪个 BOM 类别、建议采取什么策略。
- 来源等级分为 S/A/B/C：S/A 可作为高置信判断依据，B/C 默认作为观察或待核实信号。
- 第一阶段先实现 MVP 聚合视图，不新增复杂爬虫，不引入图数据库，不重写现有风险算法。
- 所有新增接口必须有测试；前端新增页面至少覆盖渲染、空状态和关键字段展示。

---

## File Structure

### Backend

- Create: `backend/app/api/risk_chain.py`
  - 职责：提供风险链路驾驶舱聚合接口，返回摘要、行情/事件、材料链、BOM 影响和策略建议。
- Modify: `backend/app/main.py`
  - 职责：注册 `risk_chain` router。
- Create: `backend/tests/test_risk_chain_api.py`
  - 职责：验证接口结构、来源等级、材料链、BOM 影响和策略建议字段。

### Frontend

- Create: `frontend/src/api/riskChain.js`
  - 职责：封装 `/api/risk-chain/dashboard` 请求。
- Create: `frontend/src/views/RiskChainDashboard.vue`
  - 职责：实现新版主入口页面，包含顶部摘要、行情/事件流、材料链路、BOM 影响、策略建议和证据抽屉。
- Modify: `frontend/src/router/index.js`
  - 职责：把 `/` 指向风险链路驾驶舱，保留上传分析为 `/analyze`。
- Modify: `frontend/src/App.vue`
  - 职责：收敛主菜单为五类入口。
- Create: `frontend/src/views/__tests__/RiskChainDashboard.test.js`
  - 职责：验证驾驶舱页面能渲染聚合数据、空状态和证据抽屉。

---

### Task 1: 后端风险链路聚合接口

**Files:**
- Create: `backend/app/api/risk_chain.py`
- Modify: `backend/app/main.py`
- Test: `backend/tests/test_risk_chain_api.py`

**Interfaces:**
- Produces: `GET /api/risk-chain/dashboard`
- Produces response shape:

```json
{
  "summary": {
    "highRiskBomCount": 3,
    "affectedItemCount": 12,
    "affectedCategoryCount": 5,
    "highConfidenceSignalCount": 8,
    "pendingActionCount": 16
  },
  "signals": [],
  "materialChains": [],
  "bomImpacts": [],
  "strategies": []
}
```

- Later frontend consumes this exact camelCase shape.

- [ ] **Step 1: Write the failing backend API test**

Create `backend/tests/test_risk_chain_api.py`:

```python
from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_risk_chain_dashboard_returns_core_sections():
    response = client.get("/api/risk-chain/dashboard")

    assert response.status_code == 200
    data = response.json()

    assert set(data.keys()) == {
        "summary",
        "signals",
        "materialChains",
        "bomImpacts",
        "strategies",
    }
    assert data["summary"]["highRiskBomCount"] >= 0
    assert data["summary"]["affectedItemCount"] >= 0
    assert data["summary"]["affectedCategoryCount"] >= 0
    assert data["summary"]["highConfidenceSignalCount"] >= 0
    assert data["summary"]["pendingActionCount"] >= 0


def test_risk_chain_dashboard_contains_traceable_sample_signal():
    response = client.get("/api/risk-chain/dashboard")

    assert response.status_code == 200
    data = response.json()
    signal = data["signals"][0]

    assert signal["id"]
    assert signal["title"]
    assert signal["signalType"] in ["price", "shortage", "tariff", "trade", "ban", "disaster", "strike", "shutdown"]
    assert signal["sourceLevel"] in ["S", "A", "B", "C"]
    assert 0 <= signal["confidenceScore"] <= 100
    assert isinstance(signal["linkedMaterials"], list)
    assert isinstance(signal["linkedCategories"], list)


def test_risk_chain_dashboard_contains_material_chain_and_bom_impact():
    response = client.get("/api/risk-chain/dashboard")

    assert response.status_code == 200
    data = response.json()

    material_chain = data["materialChains"][0]
    assert material_chain["category"]
    assert isinstance(material_chain["nodes"], list)
    assert len(material_chain["nodes"]) >= 2
    assert material_chain["nodes"][0]["name"]

    impact = data["bomImpacts"][0]
    assert impact["itemCode"]
    assert impact["category"]
    assert impact["riskLevel"] in ["red", "orange", "yellow", "green"]
    assert impact["reasonSummary"]
    assert isinstance(impact["linkedSignalIds"], list)
    assert isinstance(impact["linkedMaterials"], list)


def test_risk_chain_dashboard_contains_strategy_actions():
    response = client.get("/api/risk-chain/dashboard")

    assert response.status_code == 200
    data = response.json()
    strategy = data["strategies"][0]

    assert strategy["id"]
    assert strategy["strategyType"] in ["price", "lead_time", "alternative", "trade", "watch"]
    assert strategy["title"]
    assert strategy["detail"]
    assert strategy["priority"] in ["P0", "P1", "P2"]
    assert strategy["ownerRole"] in ["采购", "研发", "项目经理", "供应链"]
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```powershell
pytest backend/tests/test_risk_chain_api.py -v
```

Expected: FAIL with 404 for `/api/risk-chain/dashboard` or import error for missing router.

- [ ] **Step 3: Create backend API module**

Create `backend/app/api/risk_chain.py`:

```python
from typing import List, Literal

from fastapi import APIRouter
from pydantic import BaseModel, Field

router = APIRouter(prefix="/api/risk-chain", tags=["risk-chain"])


SourceLevel = Literal["S", "A", "B", "C"]
RiskLevel = Literal["red", "orange", "yellow", "green"]
SignalType = Literal[
    "price",
    "shortage",
    "tariff",
    "trade",
    "ban",
    "disaster",
    "strike",
    "shutdown",
]
StrategyType = Literal["price", "lead_time", "alternative", "trade", "watch"]
Priority = Literal["P0", "P1", "P2"]
OwnerRole = Literal["采购", "研发", "项目经理", "供应链"]


class RiskChainSummary(BaseModel):
    highRiskBomCount: int = 0
    affectedItemCount: int = 0
    affectedCategoryCount: int = 0
    highConfidenceSignalCount: int = 0
    pendingActionCount: int = 0


class MarketSignal(BaseModel):
    id: str
    title: str
    signalType: SignalType
    severity: RiskLevel
    sourceName: str
    sourceLevel: SourceLevel
    confidenceScore: int = Field(ge=0, le=100)
    occurredAt: str
    summary: str
    linkedMaterials: List[str]
    linkedCategories: List[str]


class MaterialNode(BaseModel):
    name: str
    materialType: str
    riskLevel: RiskLevel
    evidence: str
    priceChangeText: str
    confidenceScore: int = Field(ge=0, le=100)


class MaterialChain(BaseModel):
    id: str
    category: str
    title: str
    summary: str
    nodes: List[MaterialNode]


class BomImpact(BaseModel):
    id: str
    bomProjectName: str
    itemCode: str
    itemName: str
    category: str
    riskLevel: RiskLevel
    priceImpactText: str
    leadTimeImpactText: str
    reasonSummary: str
    linkedSignalIds: List[str]
    linkedMaterials: List[str]
    suggestedStrategyIds: List[str]


class ActionStrategy(BaseModel):
    id: str
    strategyType: StrategyType
    priority: Priority
    title: str
    detail: str
    ownerRole: OwnerRole
    triggerReason: str
    expectedEffect: str


class RiskChainDashboard(BaseModel):
    summary: RiskChainSummary
    signals: List[MarketSignal]
    materialChains: List[MaterialChain]
    bomImpacts: List[BomImpact]
    strategies: List[ActionStrategy]


@router.get("/dashboard", response_model=RiskChainDashboard)
def get_risk_chain_dashboard() -> RiskChainDashboard:
    """返回风险链路驾驶舱 MVP 数据。

    第一阶段先提供稳定数据契约和高质量示例链路，后续再接入真实事件、材料价格和 BOM 风险计算结果。
    """
    signals = [
        MarketSignal(
            id="sig-pcb-copper-001",
            title="PCB 成本上行预警",
            signalType="price",
            severity="red",
            sourceName="交易所/行业数据综合",
            sourceLevel="A",
            confidenceScore=86,
            occurredAt="2026-07-07",
            summary="铜价上涨叠加树脂供应偏紧，可能推高 PCB 与连接器类物料成本。",
            linkedMaterials=["铜箔", "环氧树脂", "玻纤布"],
            linkedCategories=["PCB", "连接器", "线缆"],
        ),
        MarketSignal(
            id="sig-tariff-connector-001",
            title="进口连接器关税风险",
            signalType="tariff",
            severity="orange",
            sourceName="政策公告/供应商反馈",
            sourceLevel="B",
            confidenceScore=72,
            occurredAt="2026-07-07",
            summary="部分进口连接器可能受到关税成本变化影响，需要确认供应地和贸易条款。",
            linkedMaterials=["铜材", "镀层材料", "工程塑料"],
            linkedCategories=["连接器"],
        ),
    ]

    material_chains = [
        MaterialChain(
            id="chain-pcb-001",
            category="PCB",
            title="PCB → CCL → 铜箔/树脂/玻纤布",
            summary="PCB 成本主要通过覆铜板、铜箔、环氧树脂和玻纤布向下游传导。",
            nodes=[
                MaterialNode(name="PCB/FPC", materialType="finished_category", riskLevel="red", evidence="BOM 类别命中", priceChangeText="受影响", confidenceScore=90),
                MaterialNode(name="覆铜板 CCL", materialType="intermediate", riskLevel="red", evidence="行业成本结构", priceChangeText="成本上行", confidenceScore=86),
                MaterialNode(name="铜箔", materialType="upstream_material", riskLevel="red", evidence="铜价上涨", priceChangeText="+8~12%", confidenceScore=88),
                MaterialNode(name="环氧树脂", materialType="upstream_material", riskLevel="orange", evidence="供应偏紧", priceChangeText="+5~9%", confidenceScore=78),
                MaterialNode(name="玻纤布", materialType="upstream_material", riskLevel="orange", evidence="产能扰动", priceChangeText="+3~6%", confidenceScore=74),
            ],
        )
    ]

    strategies = [
        ActionStrategy(
            id="act-lock-pcb-001",
            strategyType="price",
            priority="P0",
            title="锁定关键 PCB 价格",
            detail="对红色 PCB 料号确认供应商报价有效期，优先锁定 4~8 周需求。",
            ownerRole="采购",
            triggerReason="铜箔和树脂价格同时上行，价格风险已传导到 PCB 类别。",
            expectedEffect="降低短期涨价暴露，保障重点项目交付。",
        ),
        ActionStrategy(
            id="act-alt-connector-001",
            strategyType="alternative",
            priority="P1",
            title="启动连接器二供确认",
            detail="筛选受关税影响连接器料号，确认可替代品牌、供应地和认证周期。",
            ownerRole="研发",
            triggerReason="进口连接器存在关税和交期不确定性。",
            expectedEffect="降低单一供应地和单一品牌依赖。",
        ),
    ]

    bom_impacts = [
        BomImpact(
            id="impact-pcb-8l-001",
            bomProjectName="示例控制板 BOM",
            itemCode="PCB-8L-HDI-001",
            itemName="8层 HDI 主控板",
            category="PCB",
            riskLevel="red",
            priceImpactText="预计 +8~15%",
            leadTimeImpactText="预计 +7 天",
            reasonSummary="铜箔、环氧树脂和玻纤布成本上行，经 CCL 传导到 PCB。",
            linkedSignalIds=["sig-pcb-copper-001"],
            linkedMaterials=["覆铜板 CCL", "铜箔", "环氧树脂", "玻纤布"],
            suggestedStrategyIds=["act-lock-pcb-001"],
        ),
        BomImpact(
            id="impact-conn-usbc-001",
            bomProjectName="示例控制板 BOM",
            itemCode="CONN-USB-C-009",
            itemName="USB-C 连接器",
            category="连接器",
            riskLevel="orange",
            priceImpactText="预计 +3~6%",
            leadTimeImpactText="预计 +3~5 天",
            reasonSummary="铜材、镀层材料和进口关税风险共同影响连接器成本。",
            linkedSignalIds=["sig-pcb-copper-001", "sig-tariff-connector-001"],
            linkedMaterials=["铜材", "镀层材料", "工程塑料"],
            suggestedStrategyIds=["act-alt-connector-001"],
        ),
    ]

    return RiskChainDashboard(
        summary=RiskChainSummary(
            highRiskBomCount=1,
            affectedItemCount=len(bom_impacts),
            affectedCategoryCount=len({impact.category for impact in bom_impacts}),
            highConfidenceSignalCount=len([s for s in signals if s.sourceLevel in ["S", "A"]]),
            pendingActionCount=len(strategies),
        ),
        signals=signals,
        materialChains=material_chains,
        bomImpacts=bom_impacts,
        strategies=strategies,
    )
```

- [ ] **Step 4: Register router in `backend/app/main.py`**

Change import line:

```python
from app.api import events, bom_upload, risk_analysis, bom_project, intel_watch, market_inbox, preferred_library, market_trends, supply, market_intel, dashboard, material_alerts, material_ws, risk_chain
```

Add router after existing dashboard/material routers:

```python
app.include_router(risk_chain.router)
```

- [ ] **Step 5: Run backend test**

Run:

```powershell
pytest backend/tests/test_risk_chain_api.py -v
```

Expected: PASS all tests in `test_risk_chain_api.py`.

- [ ] **Step 6: Commit**

```powershell
git add backend/app/api/risk_chain.py backend/app/main.py backend/tests/test_risk_chain_api.py
git commit -m "feat: add risk chain dashboard api"
```

---

### Task 2: Frontend API Client

**Files:**
- Create: `frontend/src/api/riskChain.js`
- Test: included indirectly by Task 3 view test using module mock

**Interfaces:**
- Consumes: `GET /api/risk-chain/dashboard`
- Produces: `getRiskChainDashboard(): Promise<AxiosResponse<RiskChainDashboard>>`

- [ ] **Step 1: Create API client**

Create `frontend/src/api/riskChain.js`:

```javascript
import client from './client'

export function getRiskChainDashboard() {
  return client.get('/risk-chain/dashboard')
}
```

- [ ] **Step 2: Verify import works**

Run:

```powershell
npm run test -- RiskChainDashboard.test.js --runInBand
```

Expected before Task 3: may fail because test/page does not exist. This step confirms no syntax issue after Task 3 is created.

- [ ] **Step 3: Commit after Task 3 test passes**

Do not commit this alone if Task 3 has not been implemented. Commit together with the dashboard page.

---

### Task 3: 风险链路驾驶舱页面

**Files:**
- Create: `frontend/src/views/RiskChainDashboard.vue`
- Create: `frontend/src/views/__tests__/RiskChainDashboard.test.js`
- Uses: `frontend/src/api/riskChain.js`

**Interfaces:**
- Consumes: `getRiskChainDashboard()` from Task 2
- Displays sections: summary, signals, materialChains, bomImpacts, strategies, evidence drawer

- [ ] **Step 1: Write failing frontend test**

Create `frontend/src/views/__tests__/RiskChainDashboard.test.js`:

```javascript
import { describe, it, expect, vi, beforeEach } from 'vitest'
import { mount, flushPromises } from '@vue/test-utils'
import ElementPlus from 'element-plus'
import RiskChainDashboard from '../RiskChainDashboard.vue'

vi.mock('../../api/riskChain', () => ({
  getRiskChainDashboard: vi.fn()
}))

import { getRiskChainDashboard } from '../../api/riskChain'

const dashboardData = {
  summary: {
    highRiskBomCount: 1,
    affectedItemCount: 2,
    affectedCategoryCount: 2,
    highConfidenceSignalCount: 1,
    pendingActionCount: 2
  },
  signals: [
    {
      id: 'sig-pcb-copper-001',
      title: 'PCB 成本上行预警',
      signalType: 'price',
      severity: 'red',
      sourceName: '交易所/行业数据综合',
      sourceLevel: 'A',
      confidenceScore: 86,
      occurredAt: '2026-07-07',
      summary: '铜价上涨叠加树脂供应偏紧。',
      linkedMaterials: ['铜箔', '环氧树脂'],
      linkedCategories: ['PCB']
    }
  ],
  materialChains: [
    {
      id: 'chain-pcb-001',
      category: 'PCB',
      title: 'PCB → CCL → 铜箔/树脂/玻纤布',
      summary: 'PCB 成本通过 CCL 向下游传导。',
      nodes: [
        { name: 'PCB/FPC', materialType: 'finished_category', riskLevel: 'red', evidence: 'BOM 类别命中', priceChangeText: '受影响', confidenceScore: 90 },
        { name: '铜箔', materialType: 'upstream_material', riskLevel: 'red', evidence: '铜价上涨', priceChangeText: '+8~12%', confidenceScore: 88 }
      ]
    }
  ],
  bomImpacts: [
    {
      id: 'impact-pcb-8l-001',
      bomProjectName: '示例控制板 BOM',
      itemCode: 'PCB-8L-HDI-001',
      itemName: '8层 HDI 主控板',
      category: 'PCB',
      riskLevel: 'red',
      priceImpactText: '预计 +8~15%',
      leadTimeImpactText: '预计 +7 天',
      reasonSummary: '铜箔、树脂经 CCL 传导到 PCB。',
      linkedSignalIds: ['sig-pcb-copper-001'],
      linkedMaterials: ['铜箔', '环氧树脂'],
      suggestedStrategyIds: ['act-lock-pcb-001']
    }
  ],
  strategies: [
    {
      id: 'act-lock-pcb-001',
      strategyType: 'price',
      priority: 'P0',
      title: '锁定关键 PCB 价格',
      detail: '优先锁定 4~8 周需求。',
      ownerRole: '采购',
      triggerReason: '铜箔和树脂价格上行。',
      expectedEffect: '降低短期涨价暴露。'
    }
  ]
}

describe('RiskChainDashboard', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('renders risk chain dashboard sections', async () => {
    getRiskChainDashboard.mockResolvedValue({ data: dashboardData })

    const wrapper = mount(RiskChainDashboard, {
      global: { plugins: [ElementPlus] }
    })
    await flushPromises()

    expect(wrapper.text()).toContain('风险链路驾驶舱')
    expect(wrapper.text()).toContain('PCB 成本上行预警')
    expect(wrapper.text()).toContain('PCB → CCL → 铜箔/树脂/玻纤布')
    expect(wrapper.text()).toContain('PCB-8L-HDI-001')
    expect(wrapper.text()).toContain('锁定关键 PCB 价格')
  })

  it('renders empty state when no data exists', async () => {
    getRiskChainDashboard.mockResolvedValue({
      data: {
        summary: { highRiskBomCount: 0, affectedItemCount: 0, affectedCategoryCount: 0, highConfidenceSignalCount: 0, pendingActionCount: 0 },
        signals: [],
        materialChains: [],
        bomImpacts: [],
        strategies: []
      }
    })

    const wrapper = mount(RiskChainDashboard, {
      global: { plugins: [ElementPlus] }
    })
    await flushPromises()

    expect(wrapper.text()).toContain('暂无风险链路数据')
  })

  it('opens evidence drawer from bom impact', async () => {
    getRiskChainDashboard.mockResolvedValue({ data: dashboardData })

    const wrapper = mount(RiskChainDashboard, {
      global: { plugins: [ElementPlus] },
      attachTo: document.body
    })
    await flushPromises()

    await wrapper.find('[data-test="open-evidence-impact-pcb-8l-001"]').trigger('click')
    await flushPromises()

    expect(document.body.textContent).toContain('证据链路')
    expect(document.body.textContent).toContain('铜箔、树脂经 CCL 传导到 PCB。')
  })
})
```

- [ ] **Step 2: Run frontend test to verify it fails**

Run:

```powershell
npm run test -- RiskChainDashboard.test.js
```

Expected: FAIL because `RiskChainDashboard.vue` does not exist.

- [ ] **Step 3: Create dashboard page**

Create `frontend/src/views/RiskChainDashboard.vue`:

```vue
<template>
  <div class="risk-chain-page">
    <div class="page-header">
      <div>
        <p class="eyebrow">Risk Chain Cockpit</p>
        <h1>风险链路驾驶舱</h1>
        <p class="subtitle">从行情事件到上游材料链，再落到 BOM 具体型号和执行策略。</p>
      </div>
      <el-button type="primary" :loading="loading" @click="loadDashboard">刷新链路</el-button>
    </div>

    <el-alert
      v-if="error"
      type="error"
      :title="error"
      show-icon
      class="section-gap"
    />

    <el-empty v-if="isEmpty && !loading" description="暂无风险链路数据" />

    <template v-else>
      <div class="metric-grid section-gap">
        <el-card v-for="metric in metrics" :key="metric.label" shadow="never" class="metric-card">
          <div class="metric-value">{{ metric.value }}</div>
          <div class="metric-label">{{ metric.label }}</div>
        </el-card>
      </div>

      <div class="chain-layout section-gap">
        <el-card shadow="never" class="panel-card">
          <template #header><span>行情 / 事件流</span></template>
          <div v-for="signal in dashboard.signals" :key="signal.id" class="signal-card" :class="signal.severity">
            <div class="row-between">
              <strong>{{ signal.title }}</strong>
              <el-tag :type="sourceTagType(signal.sourceLevel)" size="small">{{ signal.sourceLevel }}级来源</el-tag>
            </div>
            <p>{{ signal.summary }}</p>
            <div class="tag-row">
              <el-tag v-for="material in signal.linkedMaterials" :key="material" size="small" effect="plain">{{ material }}</el-tag>
            </div>
            <div class="meta-line">{{ signal.sourceName }} · 置信度 {{ signal.confidenceScore }}%</div>
          </div>
        </el-card>

        <el-card shadow="never" class="panel-card wide">
          <template #header><span>上游材料链路</span></template>
          <div v-for="chain in dashboard.materialChains" :key="chain.id" class="material-chain">
            <h3>{{ chain.title }}</h3>
            <p>{{ chain.summary }}</p>
            <div class="node-list">
              <div v-for="node in chain.nodes" :key="node.name" class="chain-node" :class="node.riskLevel">
                <div class="node-main">
                  <strong>{{ node.name }}</strong>
                  <span>{{ node.priceChangeText }}</span>
                </div>
                <div class="meta-line">{{ node.evidence }} · 置信度 {{ node.confidenceScore }}%</div>
              </div>
            </div>
          </div>
        </el-card>

        <el-card shadow="never" class="panel-card">
          <template #header><span>BOM 影响结果</span></template>
          <div v-for="impact in dashboard.bomImpacts" :key="impact.id" class="impact-card">
            <div class="row-between">
              <strong>{{ impact.itemCode }}</strong>
              <el-tag :type="riskTagType(impact.riskLevel)" size="small">{{ riskText(impact.riskLevel) }}</el-tag>
            </div>
            <p>{{ impact.reasonSummary }}</p>
            <div class="impact-values">
              <span>{{ impact.priceImpactText }}</span>
              <span>{{ impact.leadTimeImpactText }}</span>
            </div>
            <el-button
              size="small"
              text
              type="primary"
              :data-test="`open-evidence-${impact.id}`"
              @click="openEvidence(impact)"
            >
              查看证据链路
            </el-button>
          </div>
        </el-card>
      </div>

      <el-card shadow="never" class="section-gap">
        <template #header><span>建议执行策略</span></template>
        <div class="strategy-grid">
          <div v-for="strategy in dashboard.strategies" :key="strategy.id" class="strategy-card">
            <div class="row-between">
              <strong>{{ strategy.title }}</strong>
              <el-tag size="small">{{ strategy.priority }}</el-tag>
            </div>
            <p>{{ strategy.detail }}</p>
            <div class="meta-line">责任角色：{{ strategy.ownerRole }} · {{ strategy.expectedEffect }}</div>
          </div>
        </div>
      </el-card>
    </template>

    <el-drawer v-model="evidenceVisible" title="证据链路" size="42%">
      <template v-if="selectedImpact">
        <h3>{{ selectedImpact.itemCode }} · {{ selectedImpact.itemName }}</h3>
        <p class="drawer-reason">{{ selectedImpact.reasonSummary }}</p>
        <el-divider />
        <h4>关联行情 / 事件</h4>
        <el-tag v-for="signalId in selectedImpact.linkedSignalIds" :key="signalId" class="drawer-tag">{{ signalId }}</el-tag>
        <h4>关联上游材料</h4>
        <el-tag v-for="material in selectedImpact.linkedMaterials" :key="material" class="drawer-tag" effect="plain">{{ material }}</el-tag>
        <h4>建议策略</h4>
        <el-tag v-for="strategyId in selectedImpact.suggestedStrategyIds" :key="strategyId" class="drawer-tag" type="success">{{ strategyId }}</el-tag>
      </template>
    </el-drawer>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { getRiskChainDashboard } from '../api/riskChain'

const loading = ref(false)
const error = ref('')
const evidenceVisible = ref(false)
const selectedImpact = ref(null)

const dashboard = reactive({
  summary: {
    highRiskBomCount: 0,
    affectedItemCount: 0,
    affectedCategoryCount: 0,
    highConfidenceSignalCount: 0,
    pendingActionCount: 0
  },
  signals: [],
  materialChains: [],
  bomImpacts: [],
  strategies: []
})

const metrics = computed(() => [
  { label: '高风险 BOM', value: dashboard.summary.highRiskBomCount },
  { label: '受影响料号', value: dashboard.summary.affectedItemCount },
  { label: '受影响类别', value: dashboard.summary.affectedCategoryCount },
  { label: '高置信事件', value: dashboard.summary.highConfidenceSignalCount },
  { label: '待执行动作', value: dashboard.summary.pendingActionCount }
])

const isEmpty = computed(() => (
  dashboard.signals.length === 0 &&
  dashboard.materialChains.length === 0 &&
  dashboard.bomImpacts.length === 0 &&
  dashboard.strategies.length === 0
))

function assignDashboard(data) {
  dashboard.summary = data.summary || dashboard.summary
  dashboard.signals = data.signals || []
  dashboard.materialChains = data.materialChains || []
  dashboard.bomImpacts = data.bomImpacts || []
  dashboard.strategies = data.strategies || []
}

async function loadDashboard() {
  loading.value = true
  error.value = ''
  try {
    const { data } = await getRiskChainDashboard()
    assignDashboard(data)
  } catch (err) {
    error.value = '风险链路驾驶舱数据加载失败，请检查后端服务。'
  } finally {
    loading.value = false
  }
}

function openEvidence(impact) {
  selectedImpact.value = impact
  evidenceVisible.value = true
}

function riskText(level) {
  return { red: '红色', orange: '橙色', yellow: '黄色', green: '绿色' }[level] || level
}

function riskTagType(level) {
  return { red: 'danger', orange: 'warning', yellow: 'warning', green: 'success' }[level] || 'info'
}

function sourceTagType(level) {
  return { S: 'success', A: 'primary', B: 'warning', C: 'info' }[level] || 'info'
}

onMounted(loadDashboard)
</script>

<style scoped>
.risk-chain-page {
  color: #1f2937;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 20px;
}

.eyebrow {
  margin: 0 0 4px;
  color: #5b4bb7;
  font-size: 12px;
  font-weight: 700;
  letter-spacing: .08em;
  text-transform: uppercase;
}

h1 {
  margin: 0;
  font-size: 30px;
  line-height: 1.2;
}

.subtitle {
  margin: 8px 0 0;
  color: #667085;
}

.section-gap {
  margin-top: 20px;
}

.metric-grid {
  display: grid;
  grid-template-columns: repeat(5, minmax(0, 1fr));
  gap: 12px;
}

.metric-card {
  border-radius: 14px;
}

.metric-value {
  font-size: 28px;
  line-height: 1.2;
  font-weight: 700;
  color: #5b4bb7;
}

.metric-label {
  color: #667085;
  font-size: 13px;
  margin-top: 4px;
}

.chain-layout {
  display: grid;
  grid-template-columns: 1.05fr 1.35fr 1.1fr;
  gap: 14px;
}

.panel-card {
  border-radius: 14px;
}

.signal-card,
.impact-card,
.strategy-card {
  border: 1px solid #d9deea;
  border-radius: 12px;
  padding: 12px;
  margin-bottom: 10px;
  background: #fff;
}

.signal-card.red,
.chain-node.red {
  border-left: 4px solid #b42318;
}

.signal-card.orange,
.chain-node.orange {
  border-left: 4px solid #b54708;
}

.row-between,
.node-main {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  align-items: flex-start;
}

.signal-card p,
.impact-card p,
.strategy-card p,
.material-chain p {
  margin: 8px 0;
  color: #667085;
  font-size: 13px;
}

.tag-row {
  display: flex;
  gap: 6px;
  flex-wrap: wrap;
}

.meta-line {
  margin-top: 8px;
  color: #667085;
  font-size: 12px;
}

.material-chain h3 {
  margin: 0 0 4px;
  font-size: 16px;
}

.node-list {
  margin-top: 12px;
}

.chain-node {
  border: 1px solid #d9deea;
  border-radius: 12px;
  padding: 11px;
  margin-bottom: 10px;
  background: #f8fafc;
}

.impact-values {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  color: #5b4bb7;
  font-size: 13px;
  font-weight: 600;
  margin: 8px 0;
}

.strategy-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
}

.drawer-reason {
  color: #667085;
}

.drawer-tag {
  margin: 4px 6px 4px 0;
}

@media (max-width: 1100px) {
  .metric-grid,
  .chain-layout,
  .strategy-grid {
    grid-template-columns: 1fr;
  }
}
</style>
```

- [ ] **Step 4: Run frontend test**

Run:

```powershell
npm run test -- RiskChainDashboard.test.js
```

Expected: PASS.

- [ ] **Step 5: Commit**

```powershell
git add frontend/src/api/riskChain.js frontend/src/views/RiskChainDashboard.vue frontend/src/views/__tests__/RiskChainDashboard.test.js
git commit -m "feat: add risk chain dashboard view"
```

---

### Task 4: 路由默认页和菜单收敛

**Files:**
- Modify: `frontend/src/router/index.js`
- Modify: `frontend/src/App.vue`

**Interfaces:**
- Produces route `/` → `RiskChainDashboard.vue`
- Produces route `/analyze` → `BomAnalyze.vue`
- Keeps existing routes for old pages.

- [ ] **Step 1: Update router**

Modify `frontend/src/router/index.js` so the first routes become:

```javascript
const routes = [
  {
    path: '/',
    name: 'risk-chain-dashboard',
    component: () => import('../views/RiskChainDashboard.vue')
  },
  {
    path: '/analyze',
    name: 'analyze',
    component: () => import('../views/BomAnalyze.vue')
  },
  {
    path: '/dashboard',
    name: 'dashboard',
    component: () => import('../views/RiskDashboard.vue')
  },
  // keep the existing remaining routes unchanged
]
```

- [ ] **Step 2: Update menu in `App.vue`**

Replace existing menu items with five primary entries and minimal secondary entries:

```vue
<el-menu-item index="/">
  <el-icon><DataAnalysis /></el-icon>
  <span>风险链路驾驶舱</span>
</el-menu-item>
<el-menu-item index="/projects">
  <el-icon><Folder /></el-icon>
  <span>BOM项目分析</span>
</el-menu-item>
<el-sub-menu index="market-center">
  <template #title>
    <el-icon><Bell /></el-icon>
    <span>行情与事件中心</span>
  </template>
  <el-menu-item index="/events">市场事件</el-menu-item>
  <el-menu-item index="/market-inbox">行情收件箱</el-menu-item>
  <el-menu-item index="/market-trends">趋势验证</el-menu-item>
  <el-menu-item index="/watch">情报监控</el-menu-item>
</el-sub-menu>
<el-menu-item index="/materials">
  <el-icon><Coin /></el-icon>
  <span>材料链路库</span>
</el-menu-item>
<el-menu-item index="/preferred-library">
  <el-icon><Star /></el-icon>
  <span>策略与优选库</span>
</el-menu-item>
```

Also update logo text:

```vue
<span>BOM风险链路引擎</span>
```

- [ ] **Step 3: Add active route handling for nested market menu**

In `App.vue`, replace `activeRoute` computed with:

```javascript
const activeRoute = computed(() => route.path)
```

No change is needed if this already exists.

- [ ] **Step 4: Run existing frontend tests**

Run:

```powershell
npm run test -- RiskChainDashboard.test.js BomAnalyze.test.js RiskDashboard.test.js
```

Expected: PASS.

- [ ] **Step 5: Commit**

```powershell
git add frontend/src/router/index.js frontend/src/App.vue
git commit -m "feat: make risk chain dashboard the main entry"
```

---

### Task 5: 前后端集成验证

**Files:**
- No new files required unless a small test script already exists in the repo.

**Interfaces:**
- Verifies backend `/api/risk-chain/dashboard`
- Verifies frontend `/` renders dashboard
- Verifies old pages still reachable

- [ ] **Step 1: Run backend tests**

Run:

```powershell
pytest backend/tests/test_risk_chain_api.py backend/tests/test_material_mapping.py -v
```

Expected: PASS.

- [ ] **Step 2: Run frontend tests**

Run:

```powershell
npm run test -- RiskChainDashboard.test.js BomAnalyze.test.js RiskDashboard.test.js MarketEvents.test.js
```

Expected: PASS.

- [ ] **Step 3: Start system**

Run from selected project root:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "d:\1项目清单\交期风险排查\start-bom-system.ps1"
```

Expected:

```text
Backend OK.
Frontend OK.
Material page or dashboard URL opens in browser.
```

- [ ] **Step 4: Verify API manually**

Run:

```powershell
Invoke-WebRequest -Uri "http://127.0.0.1:8000/api/risk-chain/dashboard" -UseBasicParsing
```

Expected: HTTP 200 with JSON containing `summary`, `signals`, `materialChains`, `bomImpacts`, `strategies`.

- [ ] **Step 5: Verify pages manually**

Open:

```text
http://127.0.0.1:9000/#/
http://127.0.0.1:9000/#/projects
http://127.0.0.1:9000/#/events
http://127.0.0.1:9000/#/materials
http://127.0.0.1:9000/#/preferred-library
```

Expected:

- `/` shows 风险链路驾驶舱。
- Existing pages still load.
- Sidebar shows five primary menu groups.
- Clicking BOM impact opens evidence drawer.

- [ ] **Step 6: Commit final verification note if repo uses docs updates**

If project keeps delivery notes, create or update a short handoff note:

```powershell
git status --short
git log --oneline -5
```

Expected: working tree clean after commits.

---

## Self-Review

**Spec coverage:**

- 新首页结构：Task 3 implements `RiskChainDashboard.vue`.
- 菜单收敛：Task 4 modifies `App.vue`.
- 后端统一聚合接口：Task 1 adds `/api/risk-chain/dashboard`.
- 来源置信度：Task 1 response includes `sourceLevel` and `confidenceScore`; Task 3 displays both.
- 材料链路：Task 1 returns `materialChains`; Task 3 displays chain nodes.
- BOM 型号影响：Task 1 returns `bomImpacts`; Task 3 displays item-level results.
- 策略建议：Task 1 returns `strategies`; Task 3 displays strategy cards.
- 证据抽屉：Task 3 implements drawer and test.
- 不破坏现有页面：Task 4 keeps old routes; Task 5 verifies old pages.

**Placeholder scan:** No TBD/TODO/fill-later placeholders remain. Each task has concrete files, code and commands.

**Type consistency:** Backend returns camelCase fields. Frontend test and page consume the same camelCase fields. Route path `/` and API path `/risk-chain/dashboard` match `client` baseURL `/api`.
