# Risk Chain Multi Category Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将风险链路驾驶舱从 PCB 单示例扩展为覆盖 IC、被动件、连接器线缆、磁性件、电池电源、显示光电、结构散热等电子物料类别的多类别链路库。

**Architecture:** 后端新增风险链路知识库，集中维护高置信来源、上游材料节点、类别链路模板、模拟信号、策略和 BOM 影响样例。`/api/risk-chain/dashboard` 作为聚合接口读取知识库输出稳定结构；前端驾驶舱增加类别筛选、来源链接展示、材料节点来源展示和证据抽屉扩展。

**Tech Stack:** Python 3.10、FastAPI、Pydantic、pytest、Vue 3、Element Plus、Vitest。

## Global Constraints

- 不直接把 PCB 以外链路散落硬编码在页面组件里。
- 每个核心类别至少有一条上游链路和一个 S/A 级来源链接。
- 前端应能筛选“全部、IC/半导体、PCB/FPC、被动件、连接器线缆、磁性件、电池电源、显示光电、结构散热”。
- 证据抽屉必须展示来源名称、等级、链接和命中材料。
- 保持现有 `/api/risk-chain/material-chain` 接口可用。

---

## File Structure

- Create: `backend/app/knowledge/risk_chain_library.py`
  - 维护 `SOURCE_LIBRARY`、`CATEGORY_CHAIN_TEMPLATES`、`MARKET_SIGNAL_TEMPLATES`、`BOM_IMPACT_TEMPLATES`、`ACTION_STRATEGY_TEMPLATES`。
- Modify: `backend/app/api/risk_chain.py`
  - 补充 dashboard 数据模型和 `/dashboard` 接口，读取知识库返回多类别数据。
- Modify: `backend/tests/test_risk_chain_api.py`
  - 增加多类别覆盖、来源链接、证据字段测试。
- Modify: `frontend/src/views/RiskChainDashboard.vue`
  - 增加类别筛选、来源链接展示、材料节点来源展示、证据抽屉扩展。
- Modify: `frontend/src/views/__tests__/RiskChainDashboard.test.js`
  - 增加分类筛选和来源链接渲染测试。

---

### Task 1: 后端知识库与 dashboard 合同

**Files:**
- Create: `backend/app/knowledge/risk_chain_library.py`
- Modify: `backend/app/api/risk_chain.py`
- Test: `backend/tests/test_risk_chain_api.py`

**Interfaces:**
- Produces: `GET /api/risk-chain/dashboard`
- Produces fields: `summary.categoryCoverageCount`、`categoryFilters`、`signals[].sourceUrl`、`signals[].sourceType`、`materialChains[].sourceLinks`、`materialChains[].group`、`bomImpacts[].impactBreakdown`

- [ ] Step 1: Add failing backend tests for multi-category dashboard.
- [ ] Step 2: Create `risk_chain_library.py` with sources and templates.
- [ ] Step 3: Add Pydantic models and `/dashboard` endpoint.
- [ ] Step 4: Run `python -m pytest tests/test_risk_chain_api.py -v`.

### Task 2: 前端分类筛选和证据链接

**Files:**
- Modify: `frontend/src/views/RiskChainDashboard.vue`
- Modify: `frontend/src/views/__tests__/RiskChainDashboard.test.js`

**Interfaces:**
- Consumes: `getRiskChainDashboard()` with new dashboard fields.
- Produces: category filter buttons and source link display.

- [ ] Step 1: Add failing frontend tests for category filters and source links.
- [ ] Step 2: Extend dashboard state with `categoryFilters` and `selectedCategory`.
- [ ] Step 3: Filter signals, chains, impacts and strategies by selected category.
- [ ] Step 4: Display source links in signal cards, material chains, and evidence drawer.
- [ ] Step 5: Run `npm run test -- RiskChainDashboard.test.js`.

### Task 3: Verification

**Files:**
- Backend and frontend tests.

- [ ] Step 1: Run backend risk chain tests.
- [ ] Step 2: Run frontend dashboard tests.
- [ ] Step 3: Run frontend build.
- [ ] Step 4: Confirm output and summarize changed files.
