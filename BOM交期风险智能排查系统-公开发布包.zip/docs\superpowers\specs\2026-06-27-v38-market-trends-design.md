# v3.8 行情趋势视图与预测验证设计

创建日期：2026-06-27

## 需求识别

| 维度 | 判断 |
|---|---|
| 需求类型 | 小型功能迭代，新模块 |
| 复杂度 | 中等 |
| 主要读者 | 工程、测试、产品验收 |
| 行业场景 | 电子料 BOM 交期与行情风险管理 |
| 风险等级 | 中等，涉及风险判断口径但不自动改业务数据 |

本阶段接在 v3.7 MarketEvents 增强运营版之后。系统已经能从行情收件箱复核信号生成 `MarketEvent`，能管理事件启用状态，能反查事件影响到的 BOM 项目和物料。C 项要把这些离散事件变成趋势判断、预测验证结果和主动预警建议，让采购或项目负责人知道哪些品牌、品类、项目正在积累风险，以及下一步应该优先处理什么。

## 目标

v3.8 建立一个只读的“趋势预警”页面和配套 API，用现有事件、复核信号和 BOM 命中结果生成趋势统计、预测验证口径和主动预警行动队列。

本阶段不接真实供应商 API，不自动执行停用事件、重扫 BOM、修改风险等级等动作。主动预警只给出建议和跳转入口，由人决定是否处理。

## 范围边界

包含内容：

- 趋势概览：活跃事件、高严重度事件、近 7 天和 30 天新增事件、受影响项目和物料数量。
- 趋势分布：按品牌、品类、严重度和日期聚合市场事件。
- 预测验证：基于事件是否命中 BOM、是否造成红黄风险、是否有复核来源，给出“已命中风险、暂未命中、待复核”的统计。
- 主动预警行动队列：生成建议复核、建议重扫 BOM、建议关注品类、建议验证预测、建议人工判断是否停用等动作。
- 前端新增“趋势预警”页面，展示概览卡片、趋势分布和行动队列。
- 部署脚本、后端测试、前端测试、目标项目部署和真实数据验证同步更新。

不包含内容：

- 不接 Mouser、DigiKey、LCSC 或其他供应商真实 API。
- 不新增外部数据抓取、邮箱监听、微信监听或网页爬取。
- 不新增预测模型训练，也不引入机器学习依赖。
- 不自动停用事件，不自动修改 BOM 风险等级，不自动重扫 BOM。
- 不新增数据库字段，不新增预测验证表；避免 SQLite 迁移。
- 不改变现有风险扫描算法和 BOM 上传分析流程。

## 数据来源

v3.8 只读取已有表和字段：

| 数据 | 用途 |
|---|---|
| `MarketEvent` | 趋势统计、严重度分布、品牌和品类聚合、事件活跃状态 |
| `ExtractedMarketSignal` | 判断事件是否来自行情收件箱复核、复核状态和证据文本 |
| `RawMarketNotice` | 展示来源说明时使用，不读取完整原文 |
| `BomProject` | 判断项目状态、最后分析时间、风险物料统计 |
| `BomItem` | 从 `matched_event_ids` 反查事件命中的物料和项目 |

`matched_event_ids` 仍按逗号分隔 ID 精确拆分，避免事件 `1` 误命中 `11` 或 `101`。趋势统计只读这些结果，不重新运行 BOM 风险扫描。

## 后端能力

新增模块 `backend/app/api/market_trends.py`，在 `app/main.py` 中挂载到 `/api/market-trends`。

### 趋势概览

`GET /api/market-trends/summary`

返回字段：

| 字段 | 含义 |
|---|---|
| `active_event_count` | 活跃市场事件数 |
| `high_severity_event_count` | 严重度为 `critical` 或 `high` 的活跃事件数 |
| `new_events_7d` | 近 7 天新增事件数 |
| `new_events_30d` | 近 30 天新增事件数 |
| `affected_project_count` | 被活跃事件命中的 BOM 项目数 |
| `affected_item_count` | 被活跃事件命中的 BOM 物料数 |
| `red_item_count` | 命中事件的红色风险物料数 |
| `yellow_item_count` | 命中事件的黄色风险物料数 |
| `action_count` | 主动预警行动数量 |
| `generated_at` | 统计生成时间 |

### 趋势分布

`GET /api/market-trends/timeline?days=30`

`days` 只允许 `7`、`30`、`90`，默认 `30`。返回：

- `daily_events`：按日期聚合的事件数量和高严重度数量。
- `brand_rank`：品牌维度事件数量、影响项目数、影响物料数。
- `category_rank`：品类维度事件数量、影响项目数、影响物料数。
- `severity_counts`：按严重度统计事件数量。

排序规则：

1. 影响物料数多的排前。
2. 影响物料数相同，事件数多的排前。
3. 仍相同，按名称升序。

### 预测验证

`GET /api/market-trends/validation`

预测验证不判断“行情是否真的发生”，只判断系统内的预警是否已经在 BOM 风险结果中体现。

状态定义：

| 状态 | 判定 |
|---|---|
| `risk_hit` | 事件命中至少一个 BOM 物料，且命中物料中存在红色或黄色风险 |
| `not_hit_yet` | 事件未命中任何 BOM 物料 |
| `needs_review` | 事件严重度高但置信度低于 0.75，或没有复核来源 |

返回字段：

- `risk_hit_count`
- `not_hit_yet_count`
- `needs_review_count`
- `hit_rate`
- `review_needed_rate`
- `events`

`hit_rate = risk_hit_count / active_event_count`。当活跃事件数为 0 时，返回 `0`。

### 主动预警行动队列

`GET /api/market-trends/actions`

返回按优先级排序的建议动作。动作不会改变数据库，只告诉用户建议处理什么。

动作类型：

| 类型 | 触发条件 | 优先级 |
|---|---|---|
| `review_event` | 高严重度事件没有复核来源，或置信度低于 0.75 但影响物料数大于 0 | 高 |
| `rescan_bom` | 活跃高风险事件创建时间晚于项目 `last_analysis_at`，或项目从未分析 | 高 |
| `watch_category` | 同一品牌和品类下，近 30 天活跃事件数不少于 2 | 中 |
| `validate_prediction` | 事件已经命中 BOM 物料，需要确认命中物料和风险等级是否符合业务判断 | 中 |
| `consider_disable_event` | 低置信度事件没有复核来源，且未命中任何 BOM 物料 | 低 |

动作字段：

| 字段 | 含义 |
|---|---|
| `id` | 前端渲染用稳定 ID，格式为 `{action_type}:{event_id 或 brand/category}` |
| `action_type` | 动作类型 |
| `priority` | `high`、`medium`、`low` |
| `title` | 简短标题 |
| `reason` | 触发原因 |
| `brand` | 关联品牌，可为空 |
| `category` | 关联品类，可为空 |
| `event_ids` | 关联事件 ID 列表 |
| `project_count` | 影响项目数 |
| `item_count` | 影响物料数 |
| `target_route` | 前端建议跳转路径，例如 `/events` |

优先级排序：高、中、低。同优先级下，影响物料数多的排前。

## 前端页面

新增 `frontend/src/views/MarketTrends.vue`，路由为 `/market-trends`，侧边栏名称为“趋势预警”。

页面结构：

1. 顶部概览卡片：展示事件、项目、物料、行动数量。
2. 趋势分布区域：展示品牌排行、品类排行、严重度分布和按日事件数量。先使用表格和轻量卡片，不引入图表库。
3. 预测验证区域：展示命中风险、暂未命中、待复核和命中率。
4. 主动预警行动队列：展示动作类型、优先级、品牌、品类、影响项目数、影响物料数、建议原因和“查看事件”入口。

空数据规则：

- 没有事件时显示“暂无趋势数据”。
- 没有行动建议时显示“暂无主动预警动作”。
- 字段为空时显示“暂无”。
- API 加载失败时保留页面结构并显示错误提示。

交互规则：

- 页面加载时并行请求 summary、timeline、validation、actions。
- 点击“刷新”重新请求四个接口。
- `days` 切换为 7、30、90 时只重新请求 timeline。
- 点击行动队列中的“查看事件”跳转到 `/events`，本阶段不强制带筛选参数，避免改造 MarketEvents 页面查询协议。

## 前端 API

新增 `frontend/src/api/marketTrends.js`：

- `getTrendSummary()` → `GET /market-trends/summary`
- `getTrendTimeline(params)` → `GET /market-trends/timeline`
- `getTrendValidation()` → `GET /market-trends/validation`
- `getTrendActions()` → `GET /market-trends/actions`

## 测试要求

后端新增 `tests/test_market_trends_api.py`，覆盖：

- summary 能统计活跃事件、高风险事件、近 7/30 天事件和受影响物料。
- timeline 能按品牌、品类、严重度和日期聚合。
- validation 能区分 `risk_hit`、`not_hit_yet`、`needs_review`。
- actions 能生成 `review_event`、`rescan_bom`、`watch_category`、`validate_prediction`、`consider_disable_event`。
- 所有接口只读，不修改事件、BOM 项目和 BOM 物料。

前端新增 `frontend/src/views/__tests__/MarketTrends.test.js`，覆盖：

- 页面加载后展示概览、趋势分布、预测验证和行动队列。
- 刷新按钮会重新请求数据。
- days 切换只刷新趋势分布。
- 空数据时显示“暂无趋势数据”和“暂无主动预警动作”。
- 点击“查看事件”跳转到 `/events`。

部署脚本更新：

- 复制 `backend/app/api/market_trends.py`。
- 复制 `tests/test_market_trends_api.py`。
- 复制 `frontend/src/api/marketTrends.js`。
- 复制 `frontend/src/views/MarketTrends.vue`。
- 复制 `frontend/src/views/__tests__/MarketTrends.test.js`。
- 前端测试命令加入 MarketTrends 测试。
- 输出能力说明增加 v3.8 趋势预警。

## 验收口径

代码验收：

- 后端相关测试通过。
- 前端相关测试通过。
- 部署脚本在目标项目执行通过。
- 目标项目前端 build 通过。
- bundle 更新并验证通过。

真实数据验收：

在目标项目运行 TestClient 验证：

- `GET /api/market-trends/summary` 返回 200。
- `GET /api/market-trends/timeline` 返回 200。
- `GET /api/market-trends/validation` 返回 200。
- `GET /api/market-trends/actions` 返回 200。
- 如果目标数据库有事件，输出 action 数量和命中率。
- 如果目标数据库没有事件，不伪造业务数据，只报告“暂无真实趋势数据”。

## 设计自检

范围覆盖：设计覆盖趋势概览、趋势分布、预测验证、主动预警行动队列、前端页面、测试、部署和真实数据验证。

边界一致：设计不接供应商 API，不新增数据库字段，不自动改数据，不提前进入 D 项。

字段一致：后端接口字段与前端页面、测试口径一致；行动类型和优先级值在后端、前端和测试中使用同一套字符串。

歧义处理：预测验证明确为“系统内预警是否在 BOM 风险结果中体现”，不是外部市场事实验证。主动预警明确为建议队列，不自动执行。