# v3.10 多源供应数据聚合设计文档

**版本**：v3.10  
**日期**：2026-06-28  
**依赖**：v3.9 LCSC 单源供应数据接入  

## 1. 目标

将已验证的四个供应数据源（DigiKey、Mouser、观芯台、LCSC）并行接入 SupplyDataService，采用最优值合并策略，补齐 v3.9 的库存/价格/交期/生命周期四个维度的覆盖盲区。

## 2. 数据源清单

| 序号 | 数据源 | 认证 | 库存 | 价格 | 交期 | 生命周期 | API 类型 |
|------|--------|------|------|------|------|------|------|
| 1 | DigiKey | OAuth2 Client/Secret | ✅ | ✅ | ✅ | ✅ | REST V4 |
| 2 | Mouser | API Key (Header) | ✅ | ✅ | ✅ | ✅ | REST V1 |
| 3 | 观芯台 (guanxintai.com) | 免登录 | ✅ | ✅ | ✅ | ❌ | HTML 解析 |
| 4 | LCSC | jlcsearch 免费 | ✅ | ✅ | ❌ | ❌ | REST |
| 5 | Nexar/Octopart | JWT (评估中) | — | — | — | — | GraphQL (待开通) |

Range 1-4 为 v3.10 实际接入，Range 5 预留。

## 3. 合并策略：最优值合并 (Best-of-All)

对每一料号的 N 个源查询结果，逐维取最优值：

| 维度 | 合并规则 |
|------|----------|
| `total_stock` | `max(各源)` |
| `supplier_count` | 统计 `total_stock > 0` 的源数量 |
| `lead_time_days` | `min(各源有效值)` |
| `unit_price` | `min(各源有效值)` |
| `currency` | 取最低单价对应的源币种 |
| `lifecycle_status` | 取最可靠源的值（DigiKey > Mouser > 其他） |
| `is_available` | 任一源命中即为 `True` |
| `sources` | 保留所有源的原始 `SourceResult` 列表 |
| `raw_summary` | 拼接各源摘要，如 "LCSC:库存120 Mouser:交期14天 DigiKey:在售" |

合并后写入 BomItem 的字段不变（v3.9 已定义的 `total_stock`/`supplier_count`/`lead_time_days`/`unit_price`/`lifecycle_status`）。

## 4. 新增 Provider

### 4.1 DigiKeySource (`backend/app/services/sources/digikey.py`)

- 继承 `BaseSource`，实现 `query_by_mpn(mpn) -> SourceResult`
- OAuth2 Client Credentials 方式获取 token：
  ```
  POST https://api.digikey.com/v1/oauth2/token
  grant_type=client_credentials
  ```
- 搜索端点：
  ```
  POST https://api.digikey.com/products/v4/search/keyword
  Headers: Authorization Bearer, X-DIGIKEY-Client-Id, X-DIGIKEY-Locale-*
  Body: {"Keywords": "<mpn>", "Limit": 3}
  ```
- 解析字段映射到 `SourceResult`：
  - `total_stock` ← `Product.QuantityAvailable`
  - `unit_price` ← `Product.UnitPrice`
  - `lead_time_days` ← `Product.ManufacturerLeadWeeks * 7`
  - `lifecycle_status` ← `Product.ProductStatus.Status`
  - `manufacturer` ← `Product.Manufacturer.Name`
- Token 缓存复用 10 分钟（expires_in=600）
- 客户端生命周期复用 LCSCSource 已验证的跨 event-loop 重建模式

### 4.2 MouserSource 重构 (`backend/app/services/sources/mouser.py`)

现有 `mouser.py` 已有完整解析逻辑，需修正两处以对齐 v3.9 标准：

1. **状态化返回**：从 `Optional[SourceResult]` 改为 `SourceResult`，与 LCSC 一致：
   - `match_status="hit"` / `match_status="not_found"` / `match_status="timeout"`
   - 不返回 `None`
2. **API 调用格式**：Mouser 当前要求 Key 在 **header** 而非 query param：
   ```
   POST https://api.mouser.com/api/v1/search/keyword
   Headers: apiKey=xxx, Content-Type: application/json
   Body: {"SearchByKeywordRequest": {"keyword": "<mpn>", "records": 3}}
   ```
3. 响应解析保持不变（库存正则、工厂交期正则、生命周期字段、价格阶梯）
4. 客户端生命周期对齐 LCSC 的跨 loop 重建模式

### 4.3 观芯台 Source (`backend/app/services/sources/guanxintai.py`)

- 免认证，直接 HTTP GET 网页并解析 HTML 表格
- 搜索 URL：`https://www.guanxintai.com/index?keyword={mpn}`
- 解析目标：
  - 表格中的价格（含税）、库存、交期、渠道名
- 输出到 `SourceResult`：
  - `source="guanxintai"`
  - `total_stock` ← 聚合各渠道库存（取最大）
  - `unit_price` ← 最低含税单价
  - `lead_time_display` ← "立即发货" 或批次信息
- 反爬处理：标准 User-Agent，3s 请求间隔

## 5. SupplyDataService 改造

### 5.1 多源并行查询

```python
class SupplyDataService:
    def __init__(self):
        self._sources = [
            self._lcsc,      # 免费
            self._mouser,    # API Key
            self._digikey,   # OAuth2
            self._guanxintai # 网页
        ]
        self._enabled_sources = [s for s in self._sources if s.is_configured]

    async def query_one(self, mpn: str) -> AggregatedResult:
        tasks = [s.query_by_mpn(mpn) for s in self._enabled_sources]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return self._merge_best(results)
```

### 5.2 最优值合并

```python
def _merge_best(self, source_results: list[SourceResult]) -> AggregatedResult:
    hits = [r for r in source_results if isinstance(r, SourceResult) and r.is_available]
    all_results = [r for r in source_results if isinstance(r, SourceResult)]
    
    merged = AggregatedResult(mpn_queried=mpn)
    merged.sources = all_results
    
    if not hits:
        merged.is_available = False
        merged.match_status = "not_found"
        return merged
    
    merged.is_available = True
    merged.total_stock = max(r.total_stock for r in hits)
    merged.supplier_count = sum(1 for r in hits if r.total_stock > 0)
    merged.unit_price = min(r.unit_price for r in hits if r.unit_price is not None)
    merged.lead_time_days = min(r.lead_time_days for r in hits if r.lead_time_days is not None)
    merged.lifecycle_status = self._best_lifecycle(hits)
    merged.currency = self._resolve_currency(hits, merged.unit_price)
    merged.raw_summary = " ".join(f"{r.source}:{r.raw_summary or r.match_status}" for r in hits)
    return merged
```

### 5.3 原有行为保持不变

- `apply_to_bom_item()` 逻辑不变
- 失败不清空旧字段
- 单独刷新不改 `risk_level`/`risk_score`/`risk_reason`
- LCSC 单源回退：当只有 LCSC 可用时，行为与 v3.9 一致

## 6. API 层不变

v3.9 的 4 个端点保持不变：
- `GET /api/supply/query`
- `POST /api/supply/items/{id}/refresh`
- `POST /api/supply/projects/{id}/refresh`
- `GET /api/supply/projects/{id}/status`

`_result_payload()` 额外新增 `sources` 数组以展示各源明细：
```python
"sources": [
    {"name": "lcsc", "match_status": "hit", "total_stock": 120, ...},
    {"name": "mouser", "match_status": "hit", "lead_time_days": 14, ...},
]
```

## 7. 配置项

```python
# backend/app/config.py 新增
digikey_client_id: str = ""      # 已有，填充
digikey_client_secret: str = ""  # 已有，填充
digikey_enabled: bool = True     # 已有
mouser_api_key: str = ""         # 已有，填充
mouser_enabled: bool = True      # 已有
guanxintai_enabled: bool = True  # 新增，默认开启
nexar_enabled: bool = False      # 新增，默认关闭（待开通）
```

## 8. 文件变更清单

| 文件 | 操作 | 说明 |
|------|------|------|
| `backend/app/services/sources/digikey.py` | 新增 | DigiKey OAuth2 + 搜索 |
| `backend/app/services/sources/mouser.py` | 修改 | 状态化返回 + Header 认证 |
| `backend/app/services/sources/guanxintai.py` | 新增 | 观芯台 HTML 解析 |
| `backend/app/services/sources/__init__.py` | 修改 | 导出新增 source |
| `backend/app/services/supply_data.py` | 修改 | 多源并行 + 最优合并 |
| `backend/app/api/supply.py` | 修改 | payload 新增 sources 数组 |
| `backend/app/config.py` | 修改 | 新增 guanxintai_enabled/nexar_enabled |
| `tests/test_multi_source_supply.py` | 新增 | 多源合并策略测试 |
| `tests/test_supply_api.py` | 修改 | 补充多源场景测试 |
| `deploy-v3.2-mvp.ps1` | 修改 | 新增 digikey.py/guanxintai.py 到部署 |

## 9. 全局约束

- 只实现 v3.10：多源供应数据聚合
- Nexar/Octopart 待开通后作为 v3.11 增量接入
- 不新增数据库字段
- 不改变 v3.8 市场趋势/事件逻辑
- 不改变 v3.9 失败不清空旧字段的行为
- 真实数据验证必须报告真实状态，不伪造命中结果
- LCSC 单源回退兼容：当只有 LCSC 可用时行为与 v3.9 一致
