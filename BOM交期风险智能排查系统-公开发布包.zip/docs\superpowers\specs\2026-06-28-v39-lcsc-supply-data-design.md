# v3.9 LCSC 真实供应数据接入设计

创建日期：2026-06-28

## 需求识别

| 维度 | 判断 |
|---|---|
| 需求类型 | 小型功能迭代，新外部数据接入 |
| 复杂度 | 中等 |
| 主要读者 | 工程、测试、产品验收 |
| 行业场景 | 电子料 BOM 交期、库存、价格和生命周期风险管理 |
| 风险等级 | 中高，涉及外部接口、真实数据、失败兜底和风险字段写入 |

v3.8 已完成趋势预警和预测验证，系统现在可以从行情事件、复核信号和 BOM 命中结果中判断市场风险。D 项进入真实供应商数据接入，本阶段先用 LCSC/JLCSearch 打通真实供应数据链路，补足库存、交期、价格和生命周期维度。Mouser、DigiKey 等需要 API Key 或更复杂授权的来源先不启用。

## 目标

v3.9 建立 LCSC 单源真实供应数据接入能力，让系统可以对单个物料和 BOM 项目批量查询真实供应信息，并把可用结果写入 `BomItem` 已有供应链字段。供应数据用于补充生产和交付风险，不替代现有市场事件风险。

本阶段重点是“真实可查、失败可解释、旧数据不被误清空”。外部接口失败、限流、网络不可用或物料未命中时，系统应保留原有 BOM 风险结果，并返回清晰状态。

## 范围边界

包含内容：

- LCSC 单源供应数据 provider：按 MPN 查询库存、价格、生命周期、交期或可替代的可得性字段。
- 单物料查询接口：验证外部真实查询结果，不写数据库。
- 单 BOM 物料刷新接口：查询 LCSC 并写入 `BomItem` 已有供应字段。
- BOM 项目批量刷新接口：按项目物料批量查询供应数据，控制并发和处理上限。
- BOM 项目供应数据状态接口：展示覆盖率、命中数、失败数和已写入字段概况。
- BOM 明细返回供应数据字段，前端可以展示库存、供应商数、交期、单价、生命周期和来源状态。
- 前端增加供应数据展示和刷新入口。
- 部署脚本、后端测试、前端测试、真实数据验证和 bundle 同步更新。

不包含内容：

- 不启用 Mouser、DigiKey 或其他需要 API Key 的供应商。
- 不新增供应数据快照表，不新增数据库字段；使用现有 `BomItem` 供应链字段。
- 不自动禁选物料，不自动变更采购状态，不自动替换型号。
- 不改变 v3.8 市场趋势、事件复核和行动队列逻辑。
- 不把外部供应数据当作行情事件写入 `MarketEvent`。
- 不伪造真实数据；真实接口不可用时只报告不可用原因。

## 数据来源和字段口径

v3.9 只写入现有 `BomItem` 字段：

| 字段 | 含义 | 写入规则 |
|---|---|---|
| `total_stock` | LCSC 可得库存或可销售库存 | 命中时写入；未命中或失败时不清空旧值 |
| `supplier_count` | 有效来源数量 | LCSC 单源命中且有库存时为 1；无库存可为 0 |
| `lead_time_days` | 交期天数 | LCSC 返回可解析交期时写入；无字段时保持空 |
| `unit_price` | 最低单价 | 优先取价格阶梯中的最低可用单价 |
| `lifecycle_status` | 生命周期状态 | 归一为 `Active`、`NRND`、`EOL`、`Obsolete`、`Unknown` |
| `commonality_score` | 通用性评分 | 根据是否有库存、是否基础料、是否常见封装等规则估算 |
| `production_risk_level` | 供应链风险等级 | 由 `supply_risk` 根据真实数据和启发式规则评估 |
| `production_risk_score` | 供应链风险分 | 0–100 |
| `lead_time_risk_weeks` | 交期风险周数 | 由 `lead_time_days` 换算或启发式补充 |
| `eol_status` | EOL 状态 | 生命周期异常时置为 confirmed/suspected |
| `supply_risk_tags` | 风险标签 | 如零库存、单一货源、长交期、EOL |
| `supply_risk_reason` | 风险说明 | 给采购和项目负责人阅读 |
| `procurement_suggestion` | 采购建议 | 如锁单、找替代料、确认原厂生命周期 |

为避免新增字段，接口响应中可以临时返回 `source_name`、`source_status`、`error_reason`、`raw_summary` 等运行态信息，但这些信息不写入数据库。后续如果需要审计历史，再单独设计供应数据快照表。

## 后端能力

新增或重构供应数据模块，建议保持三层边界：

1. `services/sources/lcsc.py`：只负责请求 LCSC、解析响应、处理网络和限流错误。
2. `services/supply_data.py`：统一 provider 输出，聚合单源结果，提供 `query_one`、`query_batch`、`apply_to_bom_item`。
3. `api/supply.py`：面向前端和测试提供查询、刷新和状态接口。

### Provider 统一返回

LCSC provider 返回统一结构：

| 字段 | 含义 |
|---|---|
| `mpn_queried` | 查询的物料号 |
| `source_name` | 固定为 `LCSC` |
| `is_available` | 是否拿到可用供应数据 |
| `match_status` | `hit`、`not_found`、`request_failed`、`parse_failed`、`rate_limited`、`timeout` |
| `total_stock` | 库存数量 |
| `supplier_count` | 单源场景下为 0 或 1 |
| `lead_time_days` | 交期天数，可为空 |
| `unit_price` | 最低单价，可为空 |
| `currency` | 币种，无法判断时为 `CNY` 或 `USD` 中的实际来源币种 |
| `lifecycle_status` | 生命周期状态 |
| `raw_summary` | 面向人看的来源摘要，不保存完整原文 |
| `error_reason` | 失败原因，可为空 |

`is_available=false` 不等于接口调用失败。物料未命中、库存为 0、缺少价格等都应有各自状态，便于前端解释。

### 单物料真实查询

`GET /api/supply/query?mpn=STM32F103C8T6`

用途：

- 验证 LCSC 真实查询链路。
- 不写数据库。
- 供开发、测试和页面单物料刷新前预览使用。

规则：

- `mpn` 为空时返回 400。
- 查询超时应返回 200 + `match_status=timeout` 或明确业务状态，不让页面崩溃。
- 外部响应结构变化导致解析失败时，返回 `parse_failed` 和简短原因。

### 单 BOM 物料刷新

`POST /api/supply/items/{item_id}/refresh`

用途：

- 对已有 BOM 行查询 LCSC。
- 命中时写入 `BomItem` 供应链字段。
- 返回刷新后的字段和风险说明。

规则：

- 找不到物料时返回 404。
- `raw_part_number` 为空时不请求外部接口，返回 `not_found` 或 `missing_mpn`。
- 命中并成功解析时，写入实时数据字段，并重新计算供应链风险字段。
- 未命中、超时、请求失败或解析失败时，不清空旧字段。
- 不修改 `risk_level`、`risk_score`、`risk_reason`，避免单次供应刷新改变市场事件主风险。综合风险刷新仍由 BOM 分析流程负责。

### BOM 项目批量刷新

`POST /api/supply/projects/{project_id}/refresh`

用途：

- 对项目下多个物料批量刷新 LCSC 供应数据。
- 适合用户在 BOM 分析后补充真实供应数据。

规则：

- 找不到项目时返回 404。
- 默认最多处理前 50 个有 MPN 的物料，避免误触发大量外部请求。
- 支持参数 `limit`，允许值 1–100，默认 50。
- 并发数默认 3，不超过 5。
- 每个物料独立记录状态；单个失败不影响其他物料。
- 返回 `processed_count`、`updated_count`、`not_found_count`、`failed_count` 和 item 级结果。

### 项目供应数据状态

`GET /api/supply/projects/{project_id}/status`

返回项目供应数据覆盖情况：

| 字段 | 含义 |
|---|---|
| `project_id` | BOM 项目 ID |
| `total_items` | 项目物料数 |
| `items_with_mpn` | 有 MPN 的物料数 |
| `items_with_supply_data` | 至少有库存、交期、价格或生命周期字段的物料数 |
| `zero_stock_count` | 库存为 0 的物料数 |
| `long_lead_count` | 交期超过 56 天的物料数 |
| `eol_count` | 生命周期异常或 EOL 风险物料数 |
| `coverage_rate` | `items_with_supply_data / items_with_mpn` |

## 前端页面和交互

v3.9 不新增独立顶层页面，先把供应数据嵌入 BOM 分析和项目明细，减少导航复杂度。

### BOM 分析结果

在 `RiskDetailTable` 或 BOM 明细区域展示供应字段：

- 库存：`total_stock`
- 供应来源数：`supplier_count`
- 交期：`lead_time_days`
- 单价：`unit_price`
- 生命周期：`lifecycle_status`
- 供应链风险：`production_risk_level`、`supply_risk_reason`
- 采购建议：`procurement_suggestion`

用户可以点击单行“刷新供应数据”。刷新时该行显示 loading，成功后更新当前行字段，失败时显示原因并保留旧值。

### BOM 项目级刷新

在项目明细页或分析完成区提供“刷新供应数据”按钮：

- 点击后调用项目批量刷新接口。
- 页面显示已处理数量、成功数量和失败数量。
- 刷新完成后重新拉取项目明细或更新当前表格数据。
- 如果外部接口不可用，页面显示“供应数据暂不可用”，不影响用户查看原风险结果。

### 空状态和错误状态

- 没有 MPN：显示“该物料缺少可查询型号”。
- LCSC 未命中：显示“LCSC 暂未命中”。
- 网络失败或超时：显示“供应数据暂不可用，可稍后重试”。
- 解析失败：显示“供应数据格式变化，需检查解析规则”。

## 风险合并口径

v3.9 保持市场事件风险和供应链风险分轨展示。

- `risk_level` 仍由 BOM 分析流程综合市场事件和供应链风险决定。
- 单独刷新供应数据时，只更新供应链字段，不直接改 `risk_level`。
- 用户如需让供应数据参与综合风险，需要重新分析 BOM。
- 自动禁选、替代料推荐、采购审批等治理动作不在本阶段实现。

这种口径避免外部接口偶发失败或一次低质量命中直接改变主风险结论。

## 失败处理

外部接口接入必须按“失败可解释”设计：

| 场景 | 系统行为 |
|---|---|
| 网络失败 | 返回 `request_failed`，保留旧字段 |
| 超时 | 返回 `timeout`，保留旧字段 |
| 限流 | 返回 `rate_limited`，提示稍后重试 |
| 物料未命中 | 返回 `not_found`，不写入空值覆盖旧数据 |
| 响应结构变化 | 返回 `parse_failed`，测试应覆盖解析异常 |
| 批量刷新部分失败 | 失败项单独记录，其他项继续处理 |

所有失败状态都不应影响 MarketEvent、MarketTrends、MarketInbox 的既有能力。

## 测试要求

后端新增或扩展测试，覆盖：

- LCSC provider 能把模拟响应解析为统一结构。
- 单物料查询接口不写库。
- 单 BOM 物料刷新命中后写入供应字段。
- 未命中、超时、请求失败、解析失败时不清空旧字段。
- 项目批量刷新能限制 `limit` 和并发，并返回逐项状态。
- 项目供应数据状态能计算覆盖率、零库存、长交期和 EOL 数量。
- 单次供应刷新不修改 `risk_level`、`risk_score`、`risk_reason`。

前端测试覆盖：

- BOM 明细展示供应字段。
- 单行刷新调用供应接口并更新显示。
- 项目级刷新显示成功和失败数量。
- 失败时显示错误提示且保留旧数据显示。

真实数据验证：

- 至少使用 3 个真实物料号。
- 一个常见料应尽量查到库存或价格。
- 一个缺货或难命中料用于验证 `not_found` 或低可得性状态。
- 一个不存在型号用于验证失败兜底。
- 如果外网或 LCSC 接口不可用，只记录真实失败原因，不伪造命中结果。

## 部署与交付

`deploy-v3.2-mvp.ps1` 需要同步复制：

- 新增 `backend/app/api/supply.py`。
- 修改后的 `backend/app/services/supply_data.py`。
- 修改后的 `backend/app/services/sources/lcsc.py`。
- 必要时复制 `backend/app/services/sources/base.py`。
- 新增或修改后的供应数据测试。
- 修改后的前端 API client、BOM 明细组件或页面测试。

部署脚本应在目标项目中运行后端测试、前端相关测试和前端 build。真实数据验证应在目标项目运行，输出单物料查询和项目刷新接口的状态。

## 验收口径

代码验收：

- 后端供应数据相关测试通过。
- 既有 MarketEvents、MarketTrends、BOM 分析相关测试不回退。
- 前端供应数据展示和刷新测试通过。
- 部署脚本在目标项目执行通过。
- bundle 更新并验证通过。

真实数据验收：

- `GET /api/supply/query?mpn=<真实型号>` 返回可解释状态。
- `POST /api/supply/items/{item_id}/refresh` 对真实 BOM 行返回可解释状态。
- `POST /api/supply/projects/{project_id}/refresh` 能批量处理项目物料，失败项不阻断其他物料。
- `GET /api/supply/projects/{project_id}/status` 能显示覆盖率。
- 外部接口失败时，不清空旧供应字段，不修改市场事件主风险。

## 设计自检

- 范围一致：本阶段只做 LCSC 单源真实供应数据接入，不启用 Mouser/DigiKey。
- 数据边界一致：不新增数据库字段，不新增供应快照表，只写入已有 `BomItem` 供应字段。
- 风险边界一致：供应刷新不直接改 `risk_level`，综合风险仍由 BOM 分析流程处理。
- 失败处理明确：未命中、超时、限流、解析失败都有业务状态，不伪造数据。
- 验收可验证：包含模拟测试、目标项目部署测试和真实物料号验证。
