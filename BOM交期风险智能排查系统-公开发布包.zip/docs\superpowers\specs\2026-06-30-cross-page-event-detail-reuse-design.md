# 跨页面复用市场事件详情设计

## 目标

把统一市场事件详情组件继续接入趋势预警、行情收件箱和 BOM 项目详情，让用户在当前页面即可查看事件本体、来源、风险等级、触发条件、影响项目和复核来源。市场事件页的 `/events?eventId=xx` 自动打开能力继续保留，作为跨页面跳转的补充入口。

## 范围

- 新增 `useMarketEventDetail()` 组合逻辑，统一事件详情加载、影响项目加载、复核来源加载和分段容错。
- 市场事件页改用组合逻辑，避免重复加载函数。
- 趋势预警页接入 `MarketEventDetailDrawer`，点击行动队列“查看事件”在当前页打开事件详情，并保留前往事件列表的入口。
- 行情收件箱溯源抽屉接入 `MarketEventDetailDrawer`，有生成事件时可在当前页打开详情，并保留前往市场事件页入口。
- BOM 项目详情风险报告中的行情证据增加“查看详情”，在当前页打开统一事件详情。
- 更新系统功能说明书。

## 非目标

- 不改后端事件接口。
- 不改主导航。
- 不合并趋势预警、行情收件箱、情报监控页面。
- 不继续开发风险仪表盘。

## 组合逻辑接口

`useMarketEventDetail()` 返回：

- `detailVisible`
- `selectedEvent`
- `eventImpact`
- `sourceSignal`
- `detailLoading`
- `openEventDetail(eventId)`
- `closeEventDetail()`

`openEventDetail(eventId)` 行为：

- 清空旧详情。
- 调用 `getEvent(eventId)`，成功后立即打开抽屉。
- 继续调用 `getEventImpact(eventId)` 和 `getEventSourceSignal(eventId)`。
- 影响项目或复核来源失败时置空，不阻断事件本体展示。
- 事件本体失败时显示“事件详情加载失败”。

## 页面接入策略

- 市场事件页只负责列表、筛选和状态更新，详情加载交给 composable。
- 趋势预警页内“查看事件”打开抽屉；新增“前往事件库”用于跳转。
- 行情收件箱“查看市场事件”打开抽屉；新增“前往事件库”用于跳转。
- BOM 项目详情 `market_evidence` 每条证据增加“查看详情”。若证据 id 存在则打开详情。

## 测试要求

- composable 测试覆盖成功加载和附加接口失败容错。
- 市场事件页原测试继续通过。
- 趋势预警测试覆盖当前页打开详情。
- 行情收件箱测试覆盖当前页打开生成事件详情。
- BOM 项目详情测试覆盖行情证据查看详情。
- 前端构建通过。
