# 统一市场事件详情组件设计

## 目标

把市场事件详情从 `MarketEvents.vue` 中抽出为可复用组件，并让 `/events?eventId=xx` 能自动打开对应事件详情。趋势预警、行情收件箱等页面跳转到市场事件后，用户不需要再手动查找事件。

## 范围

- 新增 `MarketEventDetailDrawer.vue` 组件。
- 组件负责展示事件本体、来源链接、风险等级、触发条件、影响项目、复核来源和启用/停用操作。
- 市场事件页面接入组件，删除页面内重复详情模板。
- 市场事件页面监听 `route.query.eventId`，进入页面后自动打开事件详情。
- 趋势预警和行情收件箱现有跳转保持使用 `eventId`，用于验证自动打开链路。
- 更新系统功能说明书。

## 非目标

- 不改后端事件接口。
- 不调整主导航。
- 不继续开发风险仪表盘。
- 不把情报监控、行情收件箱和趋势预警合并成统一页面。

## 组件接口

`MarketEventDetailDrawer` 属性：

- `modelValue: boolean` 控制抽屉显示。
- `event: object | null` 事件本体。
- `impact: object | null` 事件影响项目。
- `sourceSignal: object | null` 行情收件箱复核来源。
- `operatingStatus: boolean` 启用/停用按钮 loading。

组件事件：

- `update:modelValue` 关闭或打开抽屉。
- `status-change` 参数为 `'enable' | 'disable'`，由父页面执行接口调用。

## eventId 自动打开策略

市场事件页面加载事件列表后检查 `route.query.eventId`：

- 如果存在 `eventId`，直接调用 `openDetailById(eventId)`。
- `openDetailById` 不依赖当前列表是否包含该事件，直接调用 `getEvent(eventId)`。
- 影响项目和复核来源继续分段容错加载。
- 如果事件本体接口失败，显示“事件详情加载失败”。

## 测试要求

- 组件测试覆盖基本信息、来源、触发条件、影响项目、复核来源、启用/停用按钮。
- 市场事件页面测试覆盖 `eventId` query 自动打开详情。
- 市场事件页面原有详情测试继续通过。
- 趋势预警与行情收件箱现有跳转测试继续通过。
- 前端构建通过。
