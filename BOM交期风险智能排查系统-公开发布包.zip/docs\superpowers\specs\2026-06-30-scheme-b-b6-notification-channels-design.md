# 方案 B B6 通知渠道配置与发送适配设计

## 背景

方案 B 已完成 B1-B5：风险仪表盘、HTML/Excel 报告导出、风险变化摘要、通知预览、手动通知准备、通知执行记录、历史查询和重复通知抑制。

B6 的目标是在 B5 的通知记录和幂等基础上，补齐“正式通知渠道配置与发送适配”的安全边界。当前阶段不直接接入真实邮件、飞书或企业微信外发，而是先建立可测试、可审计、默认安全阻断的通道框架。

## 目标

1. 后端提供通知通道状态查询能力。
2. 通知发送流程支持安全通道适配。
3. 未配置真实外发通道时必须阻断发送，不能误发外部消息。
4. 提供测试通道，验证发送成功、记录落库、历史展示和前端交互链路。
5. 通知历史展示更多执行信息，包括失败原因、重试次数、发送时间和收件人摘要。
6. 保留 B5 的 `idempotency_key` 重复抑制能力。

## 非目标

1. 不在 B6 直接配置真实 SMTP、飞书机器人或企业微信机器人密钥。
2. 不新增复杂权限系统。
3. 不改变现有风险评分、风险变化摘要和报告导出逻辑。
4. 不引入异步队列或后台调度器。
5. 不实现自动定时发送；B6 仍以人工点击触发为主。

## 推荐方案

采用“安全通道框架 + 测试发送通道 + 真实通道默认阻断”的方案。

通道分三类：

- `manual`：人工通知准备，不外发，保持 B5 行为。
- `mock`：测试发送通道，用于验证正式外发流程，返回已发送但不接触外部系统。
- `email`、`feishu`、`wecom`：真实通道占位，默认未配置、未启用，触发时返回 `blocked`，并写入执行记录。

## 后端设计

### 通知记录模型扩展

扩展 `DashboardNotificationRecord`：

- `provider`: 发送适配器名称，例如 `manual`、`mock`、`email`。
- `recipient_summary`: 收件人摘要，例如 `测试收件人` 或 `未配置收件人`。
- `failure_reason`: 失败或阻断原因。
- `retry_count`: 当前重试次数，B6 初始为 0。
- `last_attempt_at`: 最近一次发送尝试时间。
- `delivered_at`: 实际发送成功时间。

### 通道状态

新增服务函数：

```python
def list_notification_channels() -> dict:
    ...
```

返回结构：

```python
{
    "channels": [
        {"channel": "manual", "label": "人工通知", "enabled": True, "configured": True, "external_delivery": False, "status": "available"},
        {"channel": "mock", "label": "测试通道", "enabled": True, "configured": True, "external_delivery": True, "status": "available"},
        {"channel": "email", "label": "邮件", "enabled": False, "configured": False, "external_delivery": True, "status": "not_configured"},
        {"channel": "feishu", "label": "飞书", "enabled": False, "configured": False, "external_delivery": True, "status": "not_configured"},
        {"channel": "wecom", "label": "企业微信", "enabled": False, "configured": False, "external_delivery": True, "status": "not_configured"},
    ]
}
```

### 发送适配器

新增内部函数：

```python
def _send_with_channel(channel: str, preview: dict) -> dict:
    ...
```

B6 中只实现：

- `manual`: `status=prepared`，`delivered=False`，`external_delivery=False`。
- `mock`: `status=sent`，`delivered=True`，`external_delivery=True`。
- 未配置真实通道: `status=blocked`，`delivered=False`，`external_delivery=False`，写入 `failure_reason`。

### API

新增：

- `GET /api/dashboard/notification/channels`

扩展：

- `POST /api/dashboard/notification/dispatch`
- `GET /api/dashboard/notification/history`

## 前端设计

在 `RiskDashboard.vue` 的风险变化摘要区域增加：

1. 通道状态列表：显示通道名称、状态、是否外发。
2. “发送测试通知”按钮：调用 `dispatchDashboardNotification({ channel: 'mock' })`。
3. 未配置真实通道展示为禁用或“未配置”。
4. 通知历史增加失败原因、重试次数和发送时间。

## 测试策略

### 后端

1. 未配置真实通道发送被阻断：`email` 返回 `blocked`，不标记 `delivered`。
2. 测试通道发送成功：`mock` 返回 `sent`，标记 `delivered=True`。
3. 通道状态 API 返回 `manual`、`mock` 和真实通道占位。
4. 历史记录包含新增字段。
5. 原有 B5 幂等抑制继续有效。

### 前端

1. 页面加载时请求通道状态。
2. 页面展示“测试通道”和“未配置”。
3. 点击“发送测试通知”调用 `dispatchDashboardNotification({ channel: 'mock' })`。
4. 历史列表展示失败原因或发送状态。

## 验收标准

1. 后端目标测试通过。
2. 前端目标测试通过。
3. 前端构建成功。
4. B6 交付说明更新为 B1-B6。
5. 真实通道未配置时不会外发任何消息。
