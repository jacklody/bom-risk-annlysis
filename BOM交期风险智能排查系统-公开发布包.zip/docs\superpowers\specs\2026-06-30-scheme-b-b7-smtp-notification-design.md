# 方案 B B7 SMTP 邮件通知通道设计

## 背景

方案 B B6 已完成通知通道状态、安全发送适配和测试通道。当前 `email` 通道仍是未配置阻断状态。B7 选择 SMTP 邮件作为第一个真实通知通道，在 B6 适配器边界上实现真实邮件发送、配置校验和安全审计。

## 目标

1. 通过环境变量或 `.env` 配置 SMTP 邮件通道。
2. 邮件通道未启用或配置不完整时继续安全阻断，不外发。
3. 邮件通道配置完整且启用时，`GET /api/dashboard/notification/channels` 返回 `email` 可用。
4. `POST /api/dashboard/notification/dispatch` 支持 `channel=email` 真实发送邮件。
5. SMTP 发送成功时记录 `sent`、`delivered=True`、`external_delivery=True`、`provider=email` 和发送时间。
6. SMTP 发送失败时记录 `failed` 和 `failure_reason`，便于排查。
7. 前端展示邮件通道配置状态，并在可用时提供“发送邮件通知”入口。
8. 不在前端展示 SMTP 密码或完整敏感配置。

## 非目标

1. 不实现前端录入 SMTP 密码。
2. 不实现多套邮件配置管理。
3. 不引入后台队列或定时任务。
4. 不实现附件、HTML 富文本邮件或邮件模板编辑器。
5. 不改变 B1-B6 的仪表盘、风险摘要、报告导出和测试通道能力。

## 配置项

在 `backend/app/config.py` 的 `Settings` 中新增：

- `notification_email_enabled: bool = False`
- `notification_email_smtp_host: str = ""`
- `notification_email_smtp_port: int = 587`
- `notification_email_username: str = ""`
- `notification_email_password: str = ""`
- `notification_email_sender: str = ""`
- `notification_email_recipients: str = ""`
- `notification_email_use_tls: bool = True`
- `notification_email_timeout: float = 10.0`

示例 `.env`：

```env
notification_email_enabled=true
notification_email_smtp_host=smtp.example.com
notification_email_smtp_port=587
notification_email_username=notice@example.com
notification_email_password=app-password
notification_email_sender=notice@example.com
notification_email_recipients=buyer@example.com,pm@example.com
notification_email_use_tls=true
notification_email_timeout=10
```

## 后端设计

### 配置校验

新增函数：

```python
def _email_config_status() -> dict:
    ...
```

判断条件：

- `notification_email_enabled` 必须为 `True`
- `notification_email_smtp_host` 必填
- `notification_email_smtp_port` 必须为正整数
- `notification_email_sender` 必填
- `notification_email_recipients` 至少解析出一个有效非空地址
- 如果需要登录，`username` 和 `password` 同时使用；B7 不强制 username/password 必填，以支持内网匿名 SMTP

### 收件人摘要

新增函数：

```python
def _email_recipient_summary(recipients: list[str]) -> str:
    ...
```

返回示例：

- `1 个收件人`
- `3 个收件人`

B7 不在 API 响应中暴露完整收件人列表。

### SMTP 发送

新增函数：

```python
def _send_email_notification(preview: dict) -> dict:
    ...
```

使用 Python 标准库：

- `smtplib.SMTP`
- `email.message.EmailMessage`

发送内容：

- `Subject`: 预览中的 `subject`
- `From`: `notification_email_sender`
- `To`: 逗号拼接的收件人
- body: 预览中的 `body`

发送成功返回：

```python
{
    "status": "sent",
    "delivered": True,
    "external_delivery": True,
    "provider": "email",
    "recipient_summary": "2 个收件人",
    "failure_reason": None,
    "message": "邮件通知已发送。",
    "last_attempt_at": attempted_at,
    "delivered_at": attempted_at,
}
```

发送失败返回：

```python
{
    "status": "failed",
    "delivered": False,
    "external_delivery": True,
    "provider": "email",
    "recipient_summary": "2 个收件人",
    "failure_reason": "SMTP发送失败：...",
    "message": "SMTP发送失败：...",
    "last_attempt_at": attempted_at,
    "delivered_at": None,
}
```

### 安全阻断

如果配置不完整或未启用，`email` 通道继续返回：

```python
{
    "status": "blocked",
    "delivered": False,
    "external_delivery": False,
    "provider": "email",
    "recipient_summary": "未配置收件人",
    "failure_reason": "email 通道尚未配置，已阻断外发。",
}
```

## 前端设计

在 `RiskDashboard.vue` 中：

1. 通知通道列表继续展示邮件通道配置状态。
2. 如果邮件通道 `channel=email` 且 `configured=true` 且 `enabled=true`，显示“发送邮件通知”按钮。
3. 点击按钮调用 `dispatchDashboardNotification({ channel: 'email' })`。
4. 发送成功或失败后刷新通知历史。
5. 不展示 SMTP 密码、用户名或完整收件人列表。

## 测试策略

### 后端

1. 未配置 SMTP 时，邮件通道状态仍为 `not_configured`。
2. 配置完整且启用时，邮件通道状态为 `available`。
3. 配置完整且 SMTP 发送成功时，dispatch 返回 `sent` 并写入历史。
4. SMTP 发送失败时，dispatch 返回 `failed`，写入 `failure_reason`。
5. 原有 manual、mock 和未配置真实通道行为保持不变。

### 前端

1. 邮件通道已配置时展示“发送邮件通知”。
2. 点击按钮调用 `dispatchDashboardNotification({ channel: 'email' })`。
3. 邮件通道未配置时不显示发送邮件按钮或保持禁用。

## 验收标准

1. 后端目标测试通过。
2. 前端目标测试通过。
3. 前端构建成功。
4. B1-B7 交付说明更新。
5. 未配置 SMTP 时不会发送邮件。
6. SMTP 密码不会出现在 API 响应、前端页面或通知历史中。
